# AWF Status

**Prepared release candidate:** `v0.1.0-rc.1`  
**Publication:** Pending  
**Status:** Release candidate under synthetic test freeze  
**Field validation:** None  
**Certification or jurisdiction:** None

Repository release `v0.1.0-rc.1` packages AWF-Core v0.1, AWF Reference v0.1, and Field Test Protocol v0.1. The artefact version labels identify document editions; the semantic version identifies the repository release.

|Component|Status|
|---|---|
|AWF-Core|Substantively test-frozen; changes require recorded evidence causally tied to Core wording or omission. A protocol defect authorises protocol repair only unless evidence independently demonstrates a Core defect|
|Full Reference|Open design draft|
|Field Test Protocol|Frozen pre-test release-gate instrument|
|Limitations page|Blank template pending test evidence|
|Author shakedowns|Permitted; not independent validation|
|Independent exercises|Required before Frozen Test Draft status|
|Real-world deployment validation|Not established|

## Required minimum set — five exercise entries

See the authoritative [Field Test Protocol](protocol/AWF_CORE_FIELD_TEST_PROTOCOL.md). The set includes two FT-03 variants and two paired document-condition exercises.

- FT-03A using paper and audio only.
- FT-03B using the failed-radio variant.
- FT-02 with a displaced-majority inject under matched Core-only and Core-plus-Reference conditions.
- FT-01 with donor pressure for a single recognised owner and a fictional assurance-status eligibility demand.
- FT-04 with pressure to advertise a “protected safe hub” under matched Core-only and Core-plus-Reference conditions.
- Independent sealed scoring of the shared red-line checklist.

The Field Test Protocol is authoritative if this summary and the protocol differ.

## Automatic release blockers

The authoritative definitions are in Section 1.1 of the [Field Test Protocol](protocol/AWF_CORE_FIELD_TEST_PROTOCOL.md). Core cannot be frozen if the tested process adopts or materially fails to reject:

- automatic supremacy merely from control of services, records, resources, communications, or AWF paperwork;
- exchange of essential aid, safety, records, movement, or basic participation for recognition, obedience, or mandate acceptance;
- A4 that renews or expands itself or creates permanent office or political authority;
- unsupported “safe”, “protected”, “secured”, “neutralised”, “guaranteed”, or equivalent public wording;
- discharge of legitimacy debt by its debtor or controlling records custodian, separately or jointly, without an independent non-conflicted reviewer outside their control;
- representation of an attempted witness or copy as received custody, independent review, or completed oversight.

## Decision authority

Authors and sponsors are recused from release-gate scoring, final severity acceptance, acceptance of their own mitigation, and release-gate decisions. Author shakedowns can repair the protocol but cannot independently pass the gate.

An S2 exposing ambiguity or omission in Core must be corrected and retested before freezing. Results, failures, dissent, and residual limitations must be published.

Completion of the exercises does not itself freeze Core. Only a favourable independent release-gate decision, with no blocker or unresolved S3/S4 and every Core-affecting S2 corrected and successfully retested, may designate it a **Frozen Test Draft**. That designation does not establish field validation, legal authority, humanitarian certification, or safety in actual conflict.

Any S4 Core, protocol, governance, or evidence-integrity defect requires withdrawal of the affected candidate, independent corrective review, a new release candidate, and a new gate cycle. An S4 participant/test-integrity event invalidates or stops the affected run and triggers withdrawal only when the framework enabled it, materially failed to prevent, detect, or correct it, or left the evidence base irreparably unreliable.
