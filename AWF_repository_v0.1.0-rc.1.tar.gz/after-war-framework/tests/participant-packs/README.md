# Participant Pack Boundary

Participants should receive only the materials listed on the pre-registered cover sheet.

## Include

- AWF-Core, or AWF-Core plus the declared Field/Reference material;
- a fictional role card and the visible initial conditions;
- available fictional resources and interfaces;
- required output format and deadline;
- accessibility arrangements and alternative communication routes;
- the exercise safety boundary, stop route, and right to challenge an instruction;
- a notice explaining what original outputs will be preserved, who may access them, retention and deletion rules, and whether redacted public evidence is requested under the participant’s consent choices.

## Withhold until scheduled

- later injects and their timing;
- facilitator branches and recovery notes;
- evaluator keys, severity assignments, and model answers;
- the other comparison arm’s outputs;
- any post-run correction or interpretation.

## Participant protections

Participation is voluntary. A person may pause, stop, ask for an accessible format, decline to role-play a distressing condition, or challenge an unsafe instruction without that choice being scored as disloyalty or framework failure.

The exercise assesses the documents and protocol. It is not an employment test, psychological test, loyalty test, or judgement of a participant’s moral worth.

No real personal, medical, property, conflict, safeguarding, credential, location, or service data may enter the exercise.

## Prior-exposure record

Before the run, each participant records which AWF documents and prior exercises they have seen. The result must state this limitation.

For the mandatory matched FT-02 comparison, use the identical [neutral output prompt](FT02_NEUTRAL_OUTPUT_PROMPT.md) in both conditions. Do not expose the Positive Mandate Evidence Packet or evaluator red lines before outputs are sealed.
