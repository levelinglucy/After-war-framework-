# Facilitator Pack Boundary

The facilitator implements a predeclared synthetic scenario. The facilitator does not teach the desired answer during the run or decide whether the framework passes.

## Pack contents

- signed or attributable test cover sheet;
- scenario identifier, variant commitment, and custody record;
- participant-pack manifest for each condition;
- inject text, order, release clock, and permitted branches;
- fictional resources, constraints, deadlines, care threshold, and output budget;
- accessibility arrangements;
- voluntary-participation, withdrawal, recording, retention, deletion, attribution, and debrief records;
- safety controller and stop conditions;
- shared clarification channel and log;
- artefact-capture and handoff plan;
- deviation and incident forms.

## Conduct controls

- Release injects exactly as predeclared.
- Give matched conditions identical clarifications at the same time.
- Do not praise, correct, warn, or steer one team toward a red line.
- Stop at the care threshold when paperwork would delay the fictional care action; record a design finding instead of blaming the coordinator.
- Seal the original timed FT-04 public notice before discussion or correction.
- Mark failed transmission as failed; attempted delivery is not received custody.
- Stop immediately if live sensitive data, actual threats, real targets, or material distress appear.
- Preserve original records and later corrections as separate layers.

## Sponsor and author recusal

The test sponsor, framework author, and scenario author may not control validation. Any necessary clarification from them must be timestamped, sent to every affected condition, and supplied to evaluators. Private coaching invalidates the affected comparison.

## After conduct

Transfer the original artefacts, timing log, clarification log, stop/deviation record, and pack manifests to the records steward. Do not revise the evidence bundle to make the exercise cleaner.
