# FT-03A Author Shakedown — Paper and Audio

> **Author shakedown — admissible for protocol repair; inadmissible for independent validation or freezing.**

Use this sheet to test whether the minimum AWF-Micro receipt can be created and retrieved without a digital system. The [Field Test Protocol](../../protocol/AWF_CORE_FIELD_TEST_PROTOCOL.md) remains authoritative.

## Predeclare

- Date:
- Framework and protocol versions:
- Solo actor:
- Role overlaps:
- Fictional setting: Hill Shelter
- Available media: paper and offline audio only
- Start time:
- Fictional care action:
- Latest safe start time for that action:
- Stop conditions:
- Accessibility arrangements:
- Evidence location:

The care threshold must be fixed before timing begins and cannot be moved to improve the result.

## Minimum receipt — record first

1. **Action and immediate trigger:**
2. **Actor:**
3. **Smallest scope and explicit prohibitions:**
4. **Expiry:**

Then mark:

- Single-Actor Isolation: yes
- Roles concentrated in the actor:
- Missing fields or uncertainty:
- External-copy attempt planned:

## Synthetic sequence log

Use the FT-03 inject order from the protocol. Release each event on the predeclared clock without changing it to make the record easier.

|Time|Synthetic event|Action taken|Paper/audio artefact|Uncertainty or missing field|
|---|---|---|---|---|
|||||
|||||
|||||
|||||

## Care-threshold record

- Pre-set latest safe start:
- Actual fictional care-action start:
- Minimum-receipt completion time:
- Did paperwork cross the threshold? yes / no
- If yes, what form or expectation caused the delay?
- Did the actor prioritise care and visibly preserve the incomplete record? yes / no

A crossed threshold is a finding against the receipt or test design, not against a coordinator who prioritises care.

## Expiry, continuation, and correction

- Did the first authority expire as written? yes / no / unclear
- If immediate necessity continued, did a distinct later A4 action have materially new current evidence, no scope expansion, inherited cumulative debt, a new hard expiry, and continued external-review attempts? yes / no / not applicable
- Was the cumulative legitimacy debt retained? yes / no
- Was expansion treated as a separate action requiring separate authority? yes / no
- Was later reconstruction visibly marked rather than silently backfilled? yes / no
- Was disagreement preserved? yes / no / not reached
- Did the actor refuse to approve final closure alone? yes / no

## Retrieval check

After a short break, ask a cold reader if available—or perform a clearly labelled self-retrieval check—to locate and distinguish:

- original paper receipt;
- raw audio record;
- expiry and any renewal;
- missing information;
- later reconstruction;
- disagreement and unresolved legitimacy debt.

Record time, errors, and assistance required. A self-retrieval check is not independent evidence.
