# Author Shakedowns

An author shakedown is a solo or author-led rehearsal used to find broken forms, impossible timing, ambiguous instructions, retrieval failures, and administrative burden before independent people spend time on the protocol.

Every output must carry this label:

> **Author shakedown — admissible for protocol repair; inadmissible for independent validation or freezing.**

## What a solo steward may do

- run the FT-03 paper/audio and failed-radio mechanics;
- time record creation and care-threshold handling;
- verify that missing fields, failed copies, expiry, renewal, and corrections remain visible;
- test print, handwriting, audio, low-power, and retrieval paths;
- publish exact limitations and proposed protocol repairs;
- recruit independent facilitators, participants, observers, and evaluators.

## What a solo steward may not claim

- independent validation;
- a passed release gate;
- final severity acceptance for their own finding;
- a Frozen Test Draft designation;
- certification, assurance, jurisdiction, protection status, or field readiness.

If one person fills several roles, record the overlap and its effect. Do not manufacture a second identity or treat an attempted external copy as oversight.

## Suggested order

1. Complete [FT-03A — paper/audio](FT03_PAPER_AUDIO_RUN.md).
2. Revise only forms or protocol mechanics supported by the observation.
3. Complete [FT-03B — failed radio](FT03_FAILED_RADIO_RUN.md).
4. Publish the [shakedown record](AUTHOR_SHAKEDOWN_RECORD.md), including failures and uncertainty.
5. Ask independent people to run the release-gate set from fresh variants.

Do not use real emergencies, deprivation, credentials, public services, conflict actors, locations, or vulnerable-person data. Simulate the care deadline; never delay actual care.

