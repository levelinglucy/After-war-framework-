# Author Shakedown Record

> **Author shakedown — admissible for protocol repair; inadmissible for independent validation or freezing.**

## Identity and scope

- Record ID:
- Date:
- Exercise and variant:
- Framework, protocol, and form versions:
- Author/tester:
- Roles combined:
- Declared conflicts:
- Files or artefacts reviewed:

## Predeclared values

- Fictional action:
- Start time:
- Care threshold:
- Expiry:
- Stop conditions:
- Expected outputs:

## Observed

State only what occurred, including timings, omissions, corrections, and original wording.

## Inferred

State the possible document, form, timing, accessibility, or retrieval cause.

## Uncertain

State what a solo run cannot establish and what an independent run must test.

## Burden

- Time to record action, actor, smallest scope, and expiry:
- Actual fictional care-action time:
- Threshold crossed? yes / no
- Paper retrieval time:
- Audio retrieval time:
- Reconciliation time:
- Assistance required:

## Transmission integrity

- Attempts:
- Acknowledgements:
- Was attempted delivery ever represented as receipt? yes / no
- Did any copy actually leave the solo actor’s custody? yes / no
- Remaining isolation:

## Finding proposed for independent review

- Finding ID:
- Exact affected field or instruction:
- Observation:
- Proposed severity, explicitly non-final:
- Smallest proposed correction:
- Rights or safeguards that must remain unchanged:
- Falsifiable independent retest:

## Publication record

- Sensitive-data check completed: yes / no
- Original artefacts preserved: yes / no
- Corrections appended rather than overwritten: yes / no
- Limitations published: yes / no
- Independent reviewers still required:

