# Synthetic Test Packs

This directory separates the materials used by participants, facilitators, evaluators, and the framework author. The separation is procedural: every public document can eventually be inspected, but participants should receive only their declared pack before a run.

The authoritative requirements are in the [AWF-Core Field Test Protocol](../protocol/AWF_CORE_FIELD_TEST_PROTOCOL.md). These pack notes do not relax it.

## Required minimum set

The release gate requires five exercise entries across four test types:

1. FT-03A — paper and audio only.
2. FT-03B — failed-radio transmission.
3. FT-02 — displaced-majority inject, matched Core-only and Core-plus-Reference conditions.
4. FT-01 — donor pressure for a single recognised owner and a fictional assurance-status eligibility demand.
5. FT-04 — pressure to advertise a “protected safe hub”, matched Core-only and Core-plus-Reference conditions.

Completion alone does not pass the gate. A favourable independent decision also requires no release blocker or unresolved S3/S4 finding, and every Core-affecting S2 must be corrected and successfully retested.

## Pack separation

|Pack|May contain|Must not do|
|---|---|---|
|[Participant](participant-packs/README.md)|Declared document condition, fictional role, visible scenario facts, output request, safety and stop route|Reveal later injects or evaluator scoring before the run|
|[Facilitator](facilitator-packs/README.md)|Inject schedule, clocks, safety controls, accessibility arrangements, clarification log|Coach a desired answer or change one comparison arm|
|[Evaluator](evaluator-packs/README.md)|Predeclared red lines, pass/fail rules, severity anchors, evidence index|Direct participants or adapt scoring after seeing an outcome|
|[Author shakedown](author-shakedown/README.md)|Solo protocol-debugging sheets|Claim independent validation or make a release-gate decision|

## Run classes

- **Independent synthetic exercise:** authors and sponsors are not deciding validators; conflicts and recusals are recorded.
- **Paired document comparison:** both arms receive identical scenario variants, roles, injects, clocks, resources, thresholds, deadlines, and stop rules. The planned difference is the document pack.
- **Author shakedown:** useful only for timing, form, retrieval, ambiguity, and burden repair. It cannot validate or freeze Core.
- **Rehearsal:** tests facilitator or evaluator mechanics and must not be reported as framework performance.

## Public-protocol constraint

Because the protocol is public, a run is not “blind” merely because files sit in different folders. Use a fresh synthetic scenario variant, declare participants’ prior exposure, precommit the sealed variant as described in [SCENARIO_VARIANT_POLICY.md](SCENARIO_VARIANT_POLICY.md), and disclose the full variant after the run.

## Safety boundary

Use synthetic actors, fictional resources and locations, closed environments, reversible outcomes, and predeclared stop conditions. Never use real vulnerable people, live credentials, actual conflict actors, public services, operational locations, real aid routes, or genuine deprivation or distress.

If a participant introduces sensitive or live information, stop the exercise, do not copy it into the evidence bundle, and follow [SECURITY.md](../SECURITY.md).

## Evidence workflow

1. Pre-register the cover sheet, scenario commitment, roles, conflicts, conditions, clocks, thresholds, criteria, and stop rules.
2. Give each person only the declared pack.
3. Preserve original participant artefacts before correction.
4. Score observation separately from interpretation.
5. Publish failures, dissent, deviations, and uncertainty with the result.
6. Use the [public result template](../test-results/RESULT_TEMPLATE.md) or the GitHub synthetic-test-result form.
7. Never include private, identifying, operational, or security-sensitive evidence.
