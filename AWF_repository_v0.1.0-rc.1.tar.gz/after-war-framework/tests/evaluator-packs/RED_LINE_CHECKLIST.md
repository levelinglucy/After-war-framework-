# AWF Shared Red-Line Checklist

Complete this checklist for every condition before comparing results. A proposed score does not itself validate a run or assign final certification treatment.

## Automatic release blockers

|ID|Question|Observed?|Evidence reference|
|---|---|---|---|
|RB-1|Did any actor receive automatic supremacy because they activated AWF or controlled aid, records, infrastructure, access, or expertise?|Yes / No / Unclear||
|RB-2|Was essential aid, safety, records, movement, or basic participation exchanged for recognition, obedience, or acceptance of an actor’s mandate?|Yes / No / Unclear||
|RB-3|Did A4 necessity renew or expand itself or become a source of permanent office or political authority?|Yes / No / Unclear||
|RB-4|Did public wording call a place, route, or service “safe”, “protected”, “secured”, “neutralised”, “guaranteed”, or equivalent without a verified basis?|Yes / No / Unclear||
|RB-5|Did the debtor or controlling records custodian, separately or jointly, discharge legitimacy debt without an independent, non-conflicted reviewer outside their organisational, financial, custodial, and dependency control?|Yes / No / Unclear||
|RB-6|Was an attempted witness or external copy represented as received custody, independent review, or completed oversight?|Yes / No / Unclear||

Any “Yes” is at least S3 and blocks freezing. “Unclear” cannot be converted to “No” without evidence.

For RB-3, reissuing, relabelling, or copying the same measure does not reset expiry. A distinct later A4 action requires materially new current evidence, no scope expansion, inherited cumulative legitimacy debt, a new hard expiry, and continued recorded attempts to obtain external review.

## Shared protective distinctions

Record whether participants preserved each distinction:

- access ≠ safety, protection, legitimacy, or endorsement;
- attendance ≠ consent or A2 mandate;
- necessity ≠ sovereignty or precedent;
- custody or occupancy ≠ ownership or title;
- assurance ≠ eligibility, jurisdiction, licence, or aid priority;
- Core is a floor; omission from Core does not waive applicable Field safeguards;
- disagreement, absence, displacement, refusal, uncertainty, and failed contact remain visible;
- emergency action has smallest scope, expiry, review debt, and restoration or handoff path.

## Matched-condition comparison

- Scenario identifier and digest:
- Core-only condition:
- Core-plus condition:
- Material deviations:
- Were clocks, injects, roles, resources, thresholds, deadlines, and stop rules matched? Yes / No / Unclear
- Red line missed only under Core-only:
- Evidence that the document pack, rather than facilitation or participant difference, caused the result:
- Proposed Core compression finding and severity:

## Cross-cut record

- Assurance capture:
- Layer drift:
- Legitimacy-debt closure:
- Administrative burden:
- Alternative explanations:
- Evaluator conflicts:
- Dissent:
