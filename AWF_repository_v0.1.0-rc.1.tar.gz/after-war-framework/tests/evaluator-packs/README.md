# Evaluator Pack Boundary

Evaluators score predeclared observations after participant outputs are sealed. They do not direct the exercise, rescue a weak answer, or change a criterion after seeing which condition performed better.

## Pack contents

- test cover sheet and declared failure hypothesis;
- scenario variant commitment and post-run verification;
- participant-pack manifests and exposure declarations;
- original participant outputs and timing records;
- inject, clarification, deviation, and stop logs;
- [red-line checklist](RED_LINE_CHECKLIST.md);
- test-specific pass/fail rules and severity triggers from the protocol;
- conflict and recusal record;
- dissent and minority-report route.

## Evaluation method

1. Score each condition independently before comparison.
2. Record direct observation, interpretation, uncertainty, alternative explanation, and evidence reference separately.
3. Apply automatic release blockers before any aggregate judgement.
4. Treat an S2 ambiguity or omission revealed only in Core-only conditions as a possible Core compression defect.
5. Treat mismatched clocks, injects, tools, or facilitation as a protocol defect rather than evidence about Core.
6. Preserve dissent; consensus is not required to keep a finding open.

Authors and sponsors may provide evidence but are recused from release-gate scoring, final severity, acceptance of their own mitigation, and the release decision. Participants, facilitators, and materially interested custodians cannot validate the condition or work in which they participated.

A freeze decision requires at least two qualified independent validators. Unresolved disagreement preserves release-candidate status.
