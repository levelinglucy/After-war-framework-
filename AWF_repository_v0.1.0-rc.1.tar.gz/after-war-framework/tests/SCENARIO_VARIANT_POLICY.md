# Scenario Variant and Precommitment Policy

## Purpose

A public protocol can teach participants what evaluators are looking for. Fresh scenario variants reduce rehearsal effects and make matched Core-only/Core-plus comparisons more credible. They do not make a test perfectly blind or prove real-world validity.

## Before the run

The scenario author creates one sealed synthetic bundle containing:

- the scenario identifier and variant number;
- the failure hypothesis being tested;
- fictional role cards and visible facts;
- the complete inject text, order, release clock, and decision points;
- resources, constraints, deadlines, care threshold, and stop rules;
- the document-pack assignment method;
- expected artefacts;
- the neutral participant-output prompt, which must not encode evaluator red lines or model answers;
- the fixed evaluator checklist and severity anchors;
- a declaration of any author, sponsor, or participant exposure.

Calculate a SHA-256 digest of the sealed bundle before participants receive any material. Record the digest, file size, time source, custodian, and intended run in a timestamped issue, commit, or independent receipt. Keep the sealed bundle unavailable to participants until their assigned material is released.

The digest is an integrity commitment, not proof of impartiality, safe custody, or universally trusted time.

## Matched comparisons

For paired Core-only and Core-plus-Reference conditions:

- use the same scenario variant, roles, capabilities, inject wording and order, release times, clocks, resources, thresholds, output deadlines, and stop rules;
- randomise or otherwise predeclare condition assignment where feasible;
- record relevant experience and prior exposure in each condition;
- never tune difficulty after learning which condition a team received;
- send clarifications simultaneously to both conditions and preserve them;
- record every deviation before scoring;
- treat a material mismatch as a protocol finding and consider the comparison inconclusive.

The planned variable is the document pack. Differences in facilitation, time, tools, or information invalidate causal claims about Core compression.

Different teams may still differ in judgement, experience, or familiarity. Treat a single matched discordance as a possible compression defect requiring replication. Where feasible, replicate with a fresh isomorphic variant and counterbalanced assignment. Do not show a team the first condition’s results before its later condition; if learning cannot be controlled, use separate participants and report the remaining confound.

## Participant exposure declaration

Record whether each participant has:

- read AWF-Core;
- read the full Reference;
- read the Field Test Protocol or scoring rules;
- joined a prior AWF exercise;
- helped draft or review the framework or variant.

Exposure does not automatically disqualify a participant, but it limits what the run can establish and must appear in the result.

## After the run

Publish the sealed scenario bundle or a safe redacted equivalent, recalculate its digest, and compare it with the precommitted value. Publish:

- the original digest and receipt;
- the post-run digest result;
- all deviations and clarifications;
- any material withheld and the reason;
- the evaluator checklist used;
- limitations caused by prior exposure or compromised separation.

Do not publish material containing real people, locations, services, vulnerabilities, credentials, or actionable misuse information. If safe disclosure is impossible, preserve a K0-style witness record and do not claim independently reproducible evidence.
