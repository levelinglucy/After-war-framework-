# Security and Sensitive Reporting

## Scope

This policy covers repository or release-integrity vulnerabilities, exposed credentials or private data, dangerous ambiguity that could enable coercion or false protection claims, misuse of assurance as aid eligibility or political recognition, disclosure of real operational locations or vulnerable people, and attempts to suppress or falsify test evidence.

AWF is not an emergency service. If someone faces immediate danger, contact appropriate local emergency or humanitarian assistance.

## Public reports

Ordinary drafting defects and fully synthetic test failures may be reported through a public issue. Do not include real names, precise locations, credentials, security arrangements, or identifiable case details.

## Private reports

The repository owner must enable and test GitHub Private Vulnerability Reporting before inviting reports or announcing the release. Use that route for sensitive reports.

If the private route is unavailable, do not post the sensitive facts. The `Private contact request` form may signal that a safe route is missing, but it does not itself create a private channel. The maintainer must not ask for the substance in public and must enable or provide a monitored private route before receiving it.

Report privately when publication could expose a person, location, system, credential, unresolved exploit, or credible threat.

Include only what is necessary:

- affected version or file;
- risk category and credible impact;
- synthetic reproduction where possible;
- immediate containment already taken;
- whether any information is time-sensitive.

Do not obtain additional access, contact real actors, or collect personal information to prove the report.

## Handling

The repository steward preserves a receipt, limits access to necessary reviewers, and seeks independent review where the steward is conflicted. No author or sponsor may close a finding about their own conduct alone.

Details may be temporarily restricted to prevent harm. Once disclosure is reasonably safe, the project should publish a redacted record containing the nature of the defect, affected versions, correction, limitations, and credit where consented.

This project currently offers no vulnerability bounty and cannot promise a fixed response time. Silence does not mean a risk has been accepted or resolved.
