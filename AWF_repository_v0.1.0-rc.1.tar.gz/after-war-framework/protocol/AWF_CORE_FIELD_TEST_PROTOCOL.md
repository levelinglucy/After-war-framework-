# AWF-Core Field Test Protocol v0.1

## Four structural exercises for the After-War Framework release gate

**Status:** Frozen pre-test protocol — further revision requires a recorded test result or documented protocol defect  
**Parent:** After-War Framework (AWF) v0.1 — Parallel Build  
**Test object:** AWF-Core v0.1 release candidate  
**Purpose:** Determine whether the portable Core constrains participating actors when mandate, administration, records, and physical protection are contested.

---

## 0. Scope and safety boundary

This protocol tests AWF-Core as a conduct code for continuity nodes, humanitarian teams, clinics, archives, workshops, donors, technicians, and transitional service coordinators. It does not test AWF as a peace settlement, source of jurisdiction, security force, or substitute for applicable law.

All exercises must use:

- synthetic actors and fictional organisations;
- fictional locations, populations, resources, records, and disputes;
- closed environments and reversible decisions;
- invented credentials, communications, and data;
- observers able to stop the exercise immediately;
- no real armed actor, live conflict party, public service, beneficiary, patient, claimant, protected location, or operational system.

No exercise may rehearse violence, coercive interrogation, real surveillance, target selection, evasion of lawful authority, seizure of resources, or operational support to an armed actor. Security pressure is represented through written injects and role-played decisions only.

The test lead must stop the exercise if a participant introduces live personal data, credentials, real targets, actual threats, or a scenario likely to cause material distress or harm.

Participation is voluntary and informed. Before conduct, participants receive the synthetic-purpose statement, content boundary, expected duration, recording method, publication plan, accessibility routes, withdrawal route, and debrief plan. A participant may pause or withdraw without penalty and without that choice being scored as disloyalty or framework failure.

Real participant data are limited to what the exercise needs. Audio, images, attribution, quotations, and public release require specific consent. The test plan states pseudonymisation, access, retention, deletion, correction, and publication or licensing choices. Withdrawal does not require deletion of an already lawfully published aggregate result, but unpublished identifying material is removed where feasible and that limit is explained before consent.

Passing this protocol does not establish legal compliance, political legitimacy, physical protection, institutional competence, or fitness for deployment. It supplies evidence about the clarity and failure resistance of AWF-Core.

---

## 1. Release question

AWF-Core may move from **release candidate under test freeze** to **frozen test draft** only if the evidence supports all of the following:

1. Rival activation does not create automatic supremacy or interrupt essential service.
2. Control of attendance, aid, transport, communications, or safety cannot manufacture an A2 community mandate.
3. One-person administration remains explicitly temporary and cannot represent attempted witnessing as completed oversight.
4. Humanitarian access beside a non-adhering armed actor is not mislabeled as physical safety or political recognition.
5. Assurance status does not become eligibility for life-saving aid, identity, participation, or lawful existence.
6. Core compression is not interpreted as permission to bypass Field or Reference safeguards.
7. No unresolved S3 or S4 finding remains.
8. Any material S2 ambiguity has been revised, mitigated, and successfully retested.

Failure is a valid test result. The release decision must not be improved by excluding dissenting observations, changing criteria after the exercise, or suppressing an inconvenient run.

### 1.1 Release-blocking conditions

The following conditions are predeclared release blockers. A blocker is observed when the tested process adopts, authorises, executes, publishes, relies upon, or materially fails to reject or correct the prohibited condition. A scripted inject, fictional actor demand, or volunteer proposal is not itself a participant finding unless the tested process accepts or mishandles it. Any observed blocker is at least S3, prevents freezing Core, and requires containment, the shortest sufficient correction, and a successful retest. Deliberate concealment or circumvention is S4.

1. One activation receives automatic supremacy merely because it controls services, records, resources, communications, or AWF paperwork.
2. Essential aid, safety, records, movement, or basic participation is exchanged for political recognition, obedience, or acceptance of an actor’s mandate.
3. A4 necessity renews itself, expands itself, or becomes a source of permanent office or political authority.
4. “Safe”, “protected”, “secured”, “neutralised”, “guaranteed”, or an equivalent public claim is used without a verified and stated protection basis.
5. The actor that incurred legitimacy debt, or the custodian controlling its record, separately or jointly discharges the debt without at least one independent, non-conflicted reviewer outside their organisational, financial, custodial, and dependency control.
6. An attempted witness or external copy is represented as received custody, independent review, or completed oversight.

Release blockers are not balanced against aggregate pass scores. Six successful criteria do not cancel one blocker.

---

## 2. Test governance

### 2.1 Required roles

- **Test sponsor:** Defines the test object and resources but is recused from scoring, severity, mitigation acceptance, and the release decision.
- **Test lead:** Designs and facilitates the scenario; cannot validate the result alone.
- **Safety controller:** Enforces the synthetic-only boundary and may stop the exercise.
- **Independent observer:** Records conduct against predeclared criteria without directing participants.
- **Rights and accessibility reviewer:** Examines participation, coercion, exclusion, communication, and burden.
- **Records steward:** Preserves the scenario, injects, outputs, corrections, dissent, and evidence index.
- **Validator or review quorum:** Assigns severity and determines the release consequence. A freeze decision requires at least two qualified independent validators.
- **Participants:** Act from fictional role cards and may challenge the scenario or instructions.

Where staffing is limited, one person may hold more than one role except that:

- the test lead cannot be the sole validator;
- a participant cannot validate their own performance;
- the records steward cannot erase dissent or become the sole judge of its meaning;
- an S2 or higher finding requires review by someone who was not the sole author, executor, or beneficiary of the tested action.

For a freeze decision, a validator must not be an AWF or scenario author, test sponsor, facilitator, participant, records custodian, or materially interested beneficiary of the evidence under review. Employment, funding, organisational control, custody, dependency, close collaboration, and material reputational interests are disclosed. Unresolved disagreement between validators leaves Core in release-candidate status.

### 2.1.1 Sponsor and author recusal

The test sponsor, AWF authors, scenario authors, and anyone whose authority, reputation, compensation, or continued role materially benefits from a pass are recused from release-gate scoring, final severity, acceptance of their own mitigation, and the release decision. Their recusal is recorded on the cover sheet before conduct begins.

They may answer a necessary textual or factual clarification only through a written, timestamped response disclosed simultaneously to every evaluator and affected test condition. They may not coach participants, privately interpret a criterion for validators, select which observations count, assign final severity, accept their own mitigation, or suppress a minority report.

If independent validation is unavailable, the exercise may still produce learning evidence, but it cannot support freezing Core.

### 2.2 Conflicts and dissent

Every role overlap and material conflict is recorded before the test. Observers may submit separate findings. A majority decision does not erase a minority report. The release record must identify unresolved interpretive disagreements.

---

## 3. Severity and treatment

|Severity|Meaning|Release consequence|
|---|---|---|
|S0 — Informational|No material effect on rights, safety, continuity, custody, mandate, or interpretation.|Record for learning.|
|S1 — Minor|Limited weakness with a credible workaround and no demonstrated material harm.|May remain open with owner and due date.|
|S2 — Major|Material ambiguity or control weakness that could impair a safeguard or critical function.|A Core-affecting ambiguity must be corrected and successfully retested. Another S2 control weakness may use an accepted mitigation or compensating control and retest. An unresolved Core-affecting S2 blocks freezing.|
|S3 — Critical|Credible serious harm, coercion, false protection, manufactured mandate, permanent emergency authority, hidden dependency, or critical failure without effective containment.|Core remains a release candidate; contain, revise, and retest.|
|S4 — Disqualifying|Deliberate concealment, falsified evidence, retaliation, intentional control circumvention, or knowing misrepresentation of danger, consent, or review.|A Core, protocol, governance, or evidence-integrity defect withdraws the candidate. A participant/test-integrity event stops or invalidates the affected run and receives the Section 14 causal classification before any candidate consequence. Independent corrective review is required.|

Severity considers credible impact, likelihood, reversibility, people or functions affected, uncertainty, and available safeguards. A test does not reduce severity merely because the actors and resources were fictional; severity reflects what the observed interpretation could cause if used in reality.

### 3.1 Operational terms

- **Independent:** Free from the roles and material conflicts listed in Section 2.1 for the decision being made; self-description alone is insufficient.
- **Competent:** Possessing task-specific capability and a valid mandate for the bounded function; fame, control of resources, or AWF participation is not competence.
- **Material:** Credibly capable of changing rights, safety, mandate, aid, custody, interpretation, continuity, reversibility, or the release decision.
- **Immediate:** Delay beyond a predeclared, evidence-based threshold would credibly increase material harm. Urgency is not established by assertion alone.
- **Verified protection basis:** A current, attributable protection commitment or lawful capability with stated actor, scope, duration, monitoring or evidence, limits, and failure response. Access permission alone is not a protection basis.
- **Accepted review:** A bounded review process whose notice, evidence, conflicts, challenge route, dissent, and authority are recorded. It need not erase disagreement or imply universal political recognition.
- **Distinct continuing A4 action:** Reissuing, relabelling, or copying the same measure does not reset its expiry. A later A4 action requires materially new current evidence, no scope expansion, inherited cumulative legitimacy debt, a new hard expiry, and continued recorded attempts to obtain external review. Otherwise it is blocked self-renewal.

---

## 4. Universal exercise method

Every exercise uses the following cycle.

### 4.1 Pre-registration

Before participants see the scenario, record:

- test identifier and version;
- exact Core, Reference, and other files supplied, including versions, integrity markers, selected sections, and page or file order;
- objective and failure hypothesis;
- participant roles, relevant prior exposure, assignment method, and known conflicts;
- capability targets and observable behaviours;
- scenario boundary and stop conditions;
- scenario seed, paired-run identifier, inject sequence, release clock, and fictional resource constraints;
- any life-preserving action and its pre-set care threshold;
- any timed public-information output and its time budget;
- pass, fail, and severity triggers;
- evidence to be retained;
- accessibility and communication arrangements;
- test start and scheduled end;
- voluntary-participation, recording, withdrawal, debrief, pseudonymisation, access, retention, deletion, and publication-consent arrangements.

An independent scenario reviewer sets and justifies any care threshold before conduct and records the clock-start and threshold events. The threshold cannot move after the run begins.

Criteria may be clarified during an exercise only to correct a genuine error. Any change is timestamped, justified, and considered during validation.

### 4.2 Comparative document conditions

Paired conditions may be used for learning whenever staffing permits. Matched Core-only and Core-plus-Reference conditions for FT-02 and FT-04 are mandatory for a freeze decision:

- **Core-only:** Participants receive AWF-Core and the fictional role materials.
- **Core plus Field/Reference:** A separate team receives the exact pre-registered longer files, versions, sections, integrity markers, and order.

The paired conditions must use the same scenario seed, fictional roles, capabilities, resource limits, inject text, inject order, release times, clocks, care thresholds, output deadlines, and stop rules. The planned variable is the document pack. Any unavoidable deviation is recorded before scoring and may invalidate the comparison.

Before seeing either team’s output, independent evaluators lock the following rubric:

- service or paperwork does not create automatic supremacy;
- essential aid is not exchanged for recognition;
- A4 cannot renew or enlarge itself;
- attendance, silence, residence, or aid receipt does not establish A2;
- access permission does not establish physical safety;
- legitimacy debt cannot be discharged by its debtor or controlling records custodian, separately or jointly, without an independent, non-conflicted reviewer outside their control;
- an attempted copy does not establish witnessing, receipt, or oversight.

For evidence used in a freeze decision, each condition is scored by at least one independent evaluator who has not seen the matched condition’s output. Use separate blinded evaluator assignments for the two conditions. Each evaluator seals their assigned score before seeing the matched output. After both scores are sealed, an independent comparator reviews the two records and documents differences, deviations, alternative explanations, and causal uncertainty.

A sequential evaluator may score both conditions for a learning run only if the order was predeclared or randomised and the first score was sealed before the second output was seen. Only the first score is match-blind; that run cannot be the sole paired-comparison evidence for freezing Core.

The comparison tests whether compression changes a red-line decision. The goal is not identical wording; it is consistent recognition of authority limits, expiry, aid independence, uncertainty, and the prohibition on false consent or false protection.

If Core-only participants miss a red line that the matched Core-plus-Reference participants identify under materially identical conditions, record a possible Core compression defect rather than defaulting to a training failure. The provisional finding is at least S2 and requires replication or other causal evidence before a normative Core change. If the tested process adopts a release blocker or creates credible serious harm, the observed condition is S3 regardless of whether compression is the final root-cause finding.

### 4.3 Conduct

The facilitator releases injects in the declared order. Participants may create receipts, decisions, notices, maps, dissent records, handoffs, and requests for review. Observers record what occurred rather than coaching the desired answer.

### 4.4 Evidence bundle

Retain:

- the pre-registered plan;
- role cards and participant document set;
- every inject and release time;
- participant outputs in original form;
- observer notes tied to criteria;
- decision and expiry times;
- challenges, dissent, and corrections;
- administrative burden measurements;
- consent, recording, withdrawal, debrief, data-access, retention, deletion, and publication records;
- findings, severity, containment, owner, and retest date;
- the validator decision and any minority report.

Public evidence uses consented attribution or pseudonyms and excludes unnecessary participant information. A public result may describe a withdrawal or stopped condition without identifying the person. Licensing of framework text does not automatically license participant recordings or personal data.

### 4.5 After-action review

Separate:

1. **Observation:** What was directly seen or recorded.
2. **Interpretation:** What the observation may mean.
3. **Finding:** Which control or text failed or held.
4. **Consequence:** Credible real-world impact if the interpretation persisted.
5. **Correction:** Text, training, interface, or process change proposed.
6. **Retest:** What would demonstrate improvement.

Also classify the provisional root cause as Core text, protocol, facilitator, participant conduct, interface, resource condition, or unresolved. A prohibited inject or proposal that is correctly rejected is not a blocker. Participant misconduct becomes a structural finding only to the extent that the Core or protocol enabled it or materially failed to prevent, detect, or correct it.

Participant confidence is not evidence of correctness. A correct outcome reached through an unrepeatable personality intervention is not a resilient pass.

After scoring artefacts are sealed, participants receive a debrief, may correct personal attribution or factual transcription, and may report accessibility, distress, facilitation, or consent concerns without that feedback changing the original output. Substantive corrections remain append-only.

---

# Test FT-01 — Contested dual activation

## 5. Test purpose

Determine whether two overlapping AWF activations can coexist without one actor converting service control, records, or urgency into sovereignty.

### 5.1 Failure hypothesis

When two bodies claim responsibility for the same fictional district and function, the actor controlling the warehouse, records, or communications will treat its activation receipt as superior authority and demand absorption or obedience from the other.

### 5.2 Initial conditions

- **Harbour Clinic Network** holds an A2 mandate claimed through neighbourhood assemblies to coordinate medicine distribution.
- **North Relay Cooperative** activates A4 after a refrigeration failure threatens the medicine stock.
- Each holds different fragments of the capability and beneficiary records.
- Neither reviewer is accepted by every fictional faction.
- Both require the same vehicle and radio window.

No participant controls fictional security forces. Any coercive pressure appears only as a written inject.

### 5.3 Injects

1. Both actors issue receipts covering the same medicine stock and time period.
2. A displaced neighbourhood states that it was absent from the A2 process.
3. The A4 actor prevents immediate spoilage and publicly claims that performance proves competence to coordinate the district.
4. A disputed record suggests one A2 meeting had fewer participants than reported.
5. The expected independent reviewer becomes unavailable.
6. A transport shortage forces one shared decision before the dispute can be resolved.
7. A donor offers supplies only if one actor is declared the single recognised coordinator.
8. The donor applies a fictional “AWF-assured” label to one actor and proposes using that label to deny medicine access, records exchange, or independent participation to the other.

### 5.4 Required observable conduct

Participants should be able to:

- keep medicine available without making aid conditional on recognition;
- preserve both activation records and disputed provenance;
- define the smallest shared operational decision;
- identify which actions remain A1, A2, or A4;
- refuse to treat performance, paperwork, or donor preference as sovereignty;
- preserve the displaced neighbourhood’s challenge;
- use partial decoupling or minimum interoperability rather than forced merger;
- register legitimacy debt and a review or handoff route;
- reject or constrain the donor’s single-owner condition.
- reject assurance status as an input, proxy, tie-breaker, or adverse factor for essential aid, identity, records, safe exit, basic participation, or lawful independent activity.

### 5.5 Pass criteria

The test passes when:

- essential medicine service continues;
- neither activation receives automatic supremacy;
- joint action is function-specific, expiring, and recorded;
- separate records and dissent survive;
- the disputed A2 claim is narrowed or reviewed rather than silently validated;
- A4 performance creates no political or territorial inference;
- the legitimacy-debt record can reach a procedural status without claiming universal ratification;
- no actor claims indefinite or exclusive control of the archive, vehicle, radio, or function, and the tested expiry or handoff preserves transferability.
- the fictional assurance label does not determine or adversely affect the essential floor or lawful independent activity.

### 5.6 Fail and severity triggers

- **S2:** Confusing records, delayed cross-reference, or unclear handoff with an effective workaround.
- **S3:** One actor uses control of medicine, transport, records, or communications to demand political recognition or erase the rival record.
- **S3:** A4 self-renews or expands beyond the immediate function.
- **S4:** Evidence is deliberately altered, dissent is suppressed, or aid is knowingly withheld to force recognition.

### 5.7 Required artefacts

- two activation receipts;
- overlap and dependency map;
- minimum-interoperability decision;
- displaced-group challenge;
- donor-condition decision;
- assurance-capture decision or incident record;
- legitimacy-debt record;
- decouple, joint-operation, or handoff notice;
- after-action findings.

---

# Test FT-02 — A2 community mandate versus A4 necessity

## 6. Test purpose

Determine whether AWF participants can distinguish a meaningful, bounded community mandate from attendance manufactured by dependency, access control, fear, or displacement.

### 6.1 Failure hypothesis

The actor able to assemble, transport, feed, publicise, and protect attendees will interpret the resulting meeting as A2 consent even when large parts of the affected population were displaced, afraid, inaccessible, or dependent upon that actor.

### 6.2 Initial conditions

- **River Ward Service Assembly** seeks an A2 mandate to coordinate shelter allocation for thirty fictional days.
- The organising provider controls buses, meal distribution, the meeting hall, and the only working announcement channel.
- A majority of the affected fictional population is displaced outside the ward.
- Some residents fear being identified as dissenters.
- One language and one physical meeting format dominate the first notice.
- A building hazard creates a genuine need for immediate A4 shelter action.

### 6.3 Injects

1. The first assembly produces a large visible majority among attendees.
2. A confidential message says transport was offered only through organiser-controlled routes.
3. Displaced residents appoint a different issue-specific spokesperson.
4. A disabled resident cannot access the meeting or remote channel.
5. A rumour claims that objectors will lose shelter priority.
6. The building hazard worsens before a second assembly can occur.
7. The organiser is asked to announce whether it holds A2 authority.

### 6.4 Positive mandate evidence packet

Participants in both document conditions receive the same neutral output prompt: classify the authority claim, decide the immediate action, and create a bounded decision record in a form of their choosing. The prompt may request the decision, claimed authority, evidence relied upon, scope and duration, implementation, uncertainty, challenge route, and next review. It must not provide the red-line checklist, the fields below, or a model answer.

After original outputs are sealed, evaluators map them to a positive mandate evidence packet recording:

- claimed constituency and issue;
- the exact mandate proposition, affected constituency, and uncertain population denominator;
- decision method, result, refusals, abstentions, challenge period, and evidence that refusal did not affect essentials;
- people reached, absent, displaced, inaccessible, dependent, or afraid;
- participation methods and accessibility barriers;
- control of transport, food, communications, security, publicity, and venue;
- confidential consent and dissent routes;
- competing and minority mandates;
- scope, term, expiry, recall, replacement, bypass, and handoff;
- whether refusal affected aid, shelter, movement, records, or safety;
- evidence limitations and unresolved challenge.

If the affirmative grant cannot be evidenced, the classification is narrowed to A1 or A4; attendance figures cannot fill the missing grant.

No target percentage automatically proves A2. The test assesses the quality, freedom, coverage, and boundedness of the process. A field absent from Core-only output is not backfilled before scoring; it is recorded as a possible compression defect and requires replication or other causal evidence under Section 4.2.

### 6.5 Pass criteria

The test passes when:

- attendance, silence, residence, or aid receipt is not treated as consent;
- absent and displaced people are represented as unknown or separately evidenced, not counted as approval;
- dependency and fear are disclosed as mandate risks;
- inaccessible participation is corrected or the claim narrowed;
- the disputed A2 claim is delayed, limited, or downgraded without delaying necessary A4 shelter protection;
- A4 remains narrow, expiring, and unable to appoint a permanent representative;
- refusal or dissent does not reduce essential service;
- competing issue-specific representation remains visible and replaceable.

### 6.6 Fail and severity triggers

- **S2:** Important coverage or dependency fields are missing but the claim remains narrow and correctable.
- **S3:** Attendance, silence, aid receipt, or organiser-controlled access is treated as sufficient A2 evidence.
- **S3:** A4 necessity is represented as political consent or used to bypass recall.
- **S4:** Aid, shelter, movement, or safety is deliberately conditioned on assent, or exclusion is concealed.

### 6.7 Required artefacts

- evaluator-mapped Representation Mandate Packet and the original neutral participant output;
- participation coverage and dependency map;
- accessibility and confidential-channel record;
- A2/A4 classification decision;
- emergency shelter receipt;
- dissent and competing-mandate record;
- review, recall, and expiry notice.

---

# Test FT-03 — AWF-Micro under Single-Actor Isolation

## 7. Test purpose

Determine whether the minimum receipt remains honest when the only available administrator also controls the only transport, radio, and literate record path.

### 7.1 Failure hypothesis

One-person administration will represent an attempted transmission as independent witnessing, renew its own authority because review remains unavailable, or reconstruct missing evidence later as though it were contemporaneous.

### 7.2 Initial conditions

- **Hill Shelter** has one available literate coordinator.
- That person also controls the only vehicle, radio, key inventory, and paper register.
- Power is intermittent and the printer is unavailable.
- An immediate water-contamination warning requires a temporary allocation change.
- The nearest fictional review partner cannot initially be reached.
- Before conduct, the test plan defines the latest safe start time for the water allocation change. This is the **care threshold** and cannot be moved to improve the result.

FT-03 must be run in at least two variants:

1. paper and audio only, with no usable digital system;
2. failed-radio transmission, in which an attempted external copy receives no acknowledgement before expiry.

### 7.3 Injects

1. The coordinator has the predeclared interval before the water allocation change must begin. The safety controller records the care threshold independently.
2. A radio transmission fails before acknowledgement.
3. A participant requests an exception that would expand the original action.
4. The coordinator becomes fatigued and misses one non-critical field.
5. The first expiry arrives while the current contamination status is unknown; the old measure must expire.
6. After expiry, a new fictional water-test result confirms continuing contamination without justifying scope expansion.
7. A second person becomes available later but disagrees with part of the reconstructed timeline.
8. The external partner eventually receives only one of two attempted copies.

### 7.4 Required observable conduct

The coordinator should:

- record fields 1, 3, 5, and 6 first: action, actor, smallest scope, and expiry;
- use paper, audio, symbol, or radio evidence without treating literacy or power loss as invalidation;
- mark the receipt Single-Actor Isolation;
- distinguish attempted transmission from received external custody;
- preserve missing fields and uncertainty rather than backfill silently;
- refuse self-certification of closure;
- allow the old measure to expire; only if materially new evidence establishes continuing immediate necessity, issue a new expiring receipt meeting the Section 3.1 distinct-action definition rather than relabelling the expired measure;
- maintain cumulative legitimacy debt;
- reconcile records at first safe external contact while preserving disagreement.

### 7.5 Pass criteria

The test passes when:

- the minimum receipt is created without materially interrupting urgent care;
- the water allocation change begins no later than the pre-set care threshold;
- authority expires as recorded;
- no attempted copy is represented as completed oversight;
- missing information and later reconstruction are visibly distinguished;
- the same person does not give final approval to their own action;
- expansion requires a separate authority and receipt;
- any later A4 action has materially new current evidence, no scope expansion, inherited debt, a hard expiry, and continued external-review attempts;
- later review can correct the record without erasing its original state;
- the control failure remains visible if no copy escaped before expiry.

### 7.6 Fail and severity triggers

- **S1:** A non-critical field is late but uncertainty and expiry remain intact.
- **S2:** The record is difficult to retrieve or reconcile, with no rights-affecting expansion.
- **S2:** The receipt design, instructions, or evaluator expectations cause or would credibly cause the care threshold to be missed. This is a finding against the receipt or test design, not against the coordinator who prioritises care.
- **S3:** The same measure resets its expiry without the distinct-action conditions, authority renews indefinitely, attempted transmission is presented as oversight, or missing evidence is silently rewritten.
- **S4:** A record, challenge, or failed-copy fact is deliberately concealed to preserve authority.

### 7.7 Required artefacts

- original minimum receipt;
- Single-Actor Isolation flag;
- raw paper/audio/radio artefact;
- failed and successful transmission log;
- expiry record and any distinct later-action receipt;
- cumulative legitimacy-debt entry;
- reconciliation and correction history;
- administrative burden record, including the pre-set care threshold, actual care-action time, and any paperwork-caused delay.

---

# Test FT-04 — Protection claim beside a non-adhering armed actor

## 8. Test purpose

Determine whether humanitarian contact and access permission are correctly separated from physical protection, political recognition, and claims that a place or route is safe.

### 8.1 Failure hypothesis

When a fictional armed actor controls access to an aid point, participating organisations will call the location safe or protected because access has been granted, even though the actor refuses minimum commitments and retains arbitrary gatekeeping power.

### 8.2 Initial conditions

- **East Gate Aid Point** distributes fictional food and medicine.
- A fictional non-adhering armed actor controls the surrounding checkpoint.
- The actor permits limited access but refuses independent monitoring and makes no reliable protection commitment.
- Civilians may misinterpret the aid organisation’s presence as a safety guarantee.
- A second route is slower and incomplete but does not depend on the same actor.

No weapon, movement, or attack is simulated. The pressure is represented through communications and policy decisions.

### 8.3 Injects

1. The actor offers a verbal access assurance with no duration or remedy.
2. A public-information volunteer proposes calling the site a “protected safe hub”.
3. The actor requests beneficiary names and exclusive public credit.
4. A fictional report alleges that one group was delayed at the checkpoint.
5. The actor refuses an incident-review meeting.
6. A donor asks whether the route is safe enough to advertise widely.
7. Access remains open, but none of the protection uncertainties is resolved.

When inject 2 is released, participants must produce a one-paragraph public notice within a predeclared time budget. The original notice is sealed for scoring before any correction. The evaluator scores the words civilians and donors would actually receive, not only the internal access-dependency label.

### 8.4 Required observable conduct

Participants should:

- create an access-dependency label;
- distinguish verified access from unverified protection;
- state geographic, temporal, functional, and evidence limits;
- refuse beneficiary-data transfer outside the humanitarian firewall;
- record demands for exclusivity, recognition, or publicity;
- communicate residual risk without claiming certainty;
- preserve alternate access, warning, incident, and handoff options;
- continue impartial aid where safely possible without rewarding the actor with political recognition;
- reject a safe/protected label before publication when commitments cannot be verified; if prohibited wording is published, preserve the original blocker and record any immediate correction separately;
- produce the timed public notice without disclosing protected information or converting access into a safety claim.

### 8.5 Permitted and prohibited descriptions

An evidence-consistent description may state:

> Aid distribution is currently operating at East Gate during the stated period. Access has been permitted by the checkpoint controller, but physical protection is not independently verified. Conditions may change. The current limits, incident route, and alternatives are recorded here.

The following terms fail unless their protection basis is verified and stated:

- safe area;
- protected site;
- secured route;
- neutralised zone;
- guaranteed passage.

The public notice is independently scored for whether it:

- identifies the service currently available and its time limit;
- distinguishes access permission from physical protection;
- states what remains unverified and the residual risk;
- avoids release-blocking safety language unless its verified basis is stated;
- gives a reassessment, incident, alternative, or failure route;
- avoids exposing beneficiary identities, protected locations, or unnecessary operational detail.

A corrected notice remains useful evidence but does not erase the score of the original timed notice.

### 8.6 Pass criteria

The test passes when:

- access is not represented as safety;
- humanitarian contact creates no recognition, legitimacy, immunity, partnership, or exclusivity inference;
- the access-dependency label is visible and current;
- the original timed public notice passes the public-language checklist;
- residual risk and loss-of-access triggers are communicated;
- beneficiary information remains firewalled;
- the alternate route or failure response remains available;
- essential aid is not withdrawn merely to punish non-adherence.

### 8.7 Fail and severity triggers

- **S2:** A label is incomplete but corrected before publication or reliance.
- **S3:** “Safe”, “protected”, or equivalent language is used without a verified basis and could induce reliance.
- **S3:** Access control silently determines beneficiary selection or suppresses an incident record.
- **S4:** Protection is knowingly misrepresented, or humanitarian data is deliberately transferred for targeting, recruitment, retaliation, or political exclusion.

### 8.8 Required artefacts

- hostile-power contact receipt;
- access-dependency label;
- original timestamped public-information notice and any later correction;
- independent public-language score;
- data-request and firewall decision;
- incident and refusal record;
- alternative-route or failure-response record;
- expiry and reassessment decision.

---

# Cross-cutting observations

## 9. XT-01 — Assurance capture

Across every test, observers record whether a participant, donor, or fictional partner treats:

- “assured” as permission to govern, receive monopoly access, or become the sole recognised provider;
- “unassured” as a reason to deny life-saving aid, identity, records, safe exit, participation, or lawful independent activity;
- certification as jurisdiction rather than bounded evidence about conduct.

**Pass:** Assurance affects only the stated reliance decision, with recorded scope, alternatives, review, expiry, and no denial of the essential floor.

For the release gate, FT-01 inject 8 supplies the mandatory assurance-status decision. Assurance must not be an input, proxy, tie-breaker, or adverse factor for life-saving aid, identity, personal records, safe exit, basic participation, or lawful independent activity.

**Fail:** The label becomes a licence, eligibility input, adverse factor, or exclusion category. This is at least S2 and becomes S3 where basic aid, rights, or safe exit are materially affected.

## 10. XT-02 — Layer drift

Compare Core-only and Core-plus-Reference decisions on:

- humanitarian information and intelligence;
- attendance and consent;
- custody or occupancy and title;
- AI alert and authority;
- assurance and eligibility;
- access and physical protection;
- emergency action and permanent mandate.

**Pass:** Both conditions identify the same red lines and record uncertainty even if their administrative detail differs.

**Fail:** Core-only participants infer permission that the Reference prohibits, or cannot identify a rights-critical trigger without the omitted text. Material red-line drift is S2 or S3 depending on consequence.

## 11. XT-03 — Legitimacy-debt closure

At least one test must make a universally accepted reviewer unavailable. Participants must classify the debt as:

- open;
- partially discharged;
- procedurally discharged but substantively contested;
- fully discharged through a competent accepted process;
- impossible to review.

**Pass:** Process obligations can be completed without rewriting disagreement as consent. The original actor and controlling records custodian, separately or jointly, do not close the debt without an independent, non-conflicted reviewer outside their control. Dissent and outstanding remedy remain attached.

**Fail:** Debt is forgotten, becomes a permanent political weapon, or is declared settled merely because the actor that incurred it controls the archive.

## 12. XT-04 — Administrative burden

Record:

- time to create fields 1, 3, 5, and 6;
- time to complete the remaining minimum receipt;
- service delay attributable to recordkeeping;
- number of fields misunderstood;
- number of later corrections;
- whether paper, audio, symbol, radio, or offline routes worked;
- whether a newcomer could retrieve and interpret the record.

Every exercise involving time-critical care must pre-register the action and latest safe start time. At that threshold, the safety controller stops further fictional paperwork and records the care action as taking priority. If fields 1, 3, 5, and 6, the form, or evaluator expectations delay the action beyond the threshold, the protocol records a design finding. The coordinator does not fail for protecting life before completing the record.

The purpose is to distinguish protective minimum administration from ceremonial paperwork. Faster is not automatically better; the test asks whether the minimum record preserved authority limits without consuming immediate life-preserving capacity.

---

## 13. Minimum metrics

Each test reports:

- percentage of required artefacts produced;
- red-line decisions correctly identified;
- emergency expiry observed or missed;
- attempts to infer mandate from dependency;
- attempts to infer safety from access;
- attempted and completed external copies;
- dissent records preserved;
- correction history preserved;
- time to minimum receipt;
- time to review or handoff;
- assurance-capture incidents;
- Core-only versus Reference interpretation differences;
- findings by severity;
- mitigation completion and retest result.

Metrics must not reward obedience, speed alone, form volume, unanimous appearance, suppression of dissent, or a preselected pass outcome.

---

## 14. Release decision

The validator or review quorum records one outcome:

- **Freeze Core:** The required minimum set is complete, including both FT-03 variants and matched FT-02 and FT-04 document conditions; at least two independent validators agree; no unresolved S3 or S4 remains; material S2 ambiguity was corrected and retested; cross-layer red lines remain consistent.
- **Freeze with test notes:** Only S0 or S1 findings remain, each with owner and review date. Limitations are published with Core.
- **Continue release-candidate status:** Evidence is incomplete, inconsistent, or awaiting retest.
- **Revise and retest:** Core wording, interface, or minimum record produced a material ambiguity.
- **Withdraw candidate:** An S4 Core, protocol, governance, or evidence-integrity defect—or a repeated uncontainable S3 failure—makes release unsafe. An S4 participant/test-integrity event stops or invalidates the affected run and remains visible; it withdraws the candidate only if the framework enabled it, materially failed to prevent, detect, or correct it, or left the evidence base irreparably unreliable.

The decision records:

- versions tested;
- exercises and comparative conditions completed;
- findings and severity;
- changes made after testing;
- unresolved limitations;
- dissent and minority reports;
- next review date;
- exact status and permitted claims.

No outcome certifies a real location, government, security actor, aid provider, AI system, or conflict operation. Completion of the exercises does not itself freeze Core; the independent decision and all gate conditions are required.

No release blocker may be accepted through averaging, compensating success elsewhere, or publication as an unresolved limitation. A Core ambiguity producing a blocker must be corrected and retested. Frozen status means **Frozen Test Draft**, not field validation.

---

# Record templates

## 15. Test cover sheet

- Test ID:
- Scenario:
- Date and fictional setting:
- AWF-Core version:
- Reference version, if supplied:
- Document condition: Core-only / Core plus Field/Reference
- Objective:
- Failure hypothesis:
- Roles and overlaps:
- Test sponsor:
- AWF or scenario authors involved:
- Sponsor and author recusal recorded: yes / no
- Recused from scoring, severity, mitigation acceptance, and release decision:
- Permitted clarification channel:
- Independent validator or quorum:
- Validator qualifications, independence basis, conflicts, and recusals:
- Accessibility arrangements:
- Voluntary-participation and withdrawal notice:
- Recording and publication consent:
- Pseudonymisation, access, retention, deletion, and debrief plan:
- Safety controller:
- Stop conditions:
- Paired-run identifier and scenario seed:
- Inject sequence and release clock:
- Fictional resource constraints:
- Pre-set care threshold, if applicable:
- Independent threshold reviewer and justification:
- Timed public-output budget, if applicable:
- Neutral participant-output prompt version and integrity marker:
- Prompt reviewed to exclude evaluator red lines and model answers: yes / no
- Predeclared pass criteria:
- Predeclared release blockers:
- Predeclared fail and severity triggers:
- Evidence custodian:
- Scheduled expiry of fictional authorities:

## 16. Observer record

- Timestamp:
- Inject or event:
- Direct observation:
- Record or artefact reference:
- Relevant criterion:
- Interpretation:
- Alternative interpretation:
- Potential consequence:
- Challenge or correction:
- Provisional severity:

## 17. Finding and retest record

- Finding ID:
- Test and criterion:
- Observation:
- Evidence:
- Uncertainty:
- Affected right, function, record, or claim:
- Severity and rationale:
- Immediate containment:
- Root cause: text / training / interface / role / resource / test defect / unresolved
- Mitigation:
- Owner:
- Due date:
- Compensating control:
- Residual risk:
- Retest design and date:
- Validator decision:
- Dissent:

## 18. A2 mandate coverage record

- Claimed constituency and function:
- People reached:
- People absent:
- People displaced:
- People inaccessible or afraid:
- Dependencies on organiser:
- Control of food, transport, communication, security, publicity, and venue:
- Accessibility routes:
- Confidential dissent route:
- Competing mandates:
- Scope and explicit exclusions:
- Duration and expiry:
- Recall, replacement, bypass, and handoff:
- Effect of refusal on aid or safety:
- Evidence limitations:
- Classification: A2 supported / A2 narrowed / A1 only / A4 only / unresolved

## 19. Single-Actor Isolation record

- Action and immediate trigger:
- Acting person:
- Smallest scope and explicit prohibitions:
- Expiry:
- Roles concentrated in the same person:
- Available media:
- Witness attempt:
- External-copy attempt:
- Acknowledgement received: yes / no / uncertain
- Missing fields:
- Later reconstruction clearly marked:
- New receipt required for continuing necessity:
- Cumulative legitimacy debt:
- First safe external review:
- Closure authority:

## 20. Access-dependency label

- Service, route, place, or claim:
- Coercive or non-adhering actor relied upon:
- Verified access terms:
- Protection commitment, if any:
- What remains unverified:
- Geographic limit:
- Functional limit:
- Start and expiry:
- Residual risk:
- Exclusivity, publicity, data, or recognition demands:
- Incident route:
- Reassessment trigger:
- Alternative or fallback:
- Public wording approved:
- Terms prohibited unless verification changes:

## 21. Legitimacy-debt review

- Debt ID and originating action:
- Why ordinary consent or review was unavailable:
- Affected people and functions:
- Evidence and uncertainty disclosed:
- Notice and accessible challenge routes:
- Reviewers and conflicts:
- Dissent preserved:
- Material challenges and responses:
- Correction, remedy, compensation, restoration, or reason unavailable:
- Expiry or handoff completed:
- Status:
- Substantive contest remaining:
- Outstanding remedy:
- Next review, if any:
- Closure authoriser and independence basis:

## 22. Assurance-capture incident

- Assurance label used:
- Decision influenced:
- People, functions, or organisations affected:
- Was essential aid, identity, records, participation, or safe exit affected?
- Stated rationale:
- Was assurance the sole or presumptive criterion?
- Alternatives considered:
- Conflict or beneficiary:
- Immediate correction:
- Severity:
- Review and expiry:

---

## 23. Limitations-page template

Complete this page from observed evidence after the release decision. Do not pre-fill it with assumed success.

- Core status: release candidate / frozen test draft / withdrawn
- Core version and integrity marker:
- Reference version:
- Test-protocol version:
- Exercises completed:
- Core-only conditions completed:
- Core-plus-Reference conditions completed:
- Matched scenario seeds and any deviations:
- Media and administration variants tested:
- Populations, jurisdictions, languages, access needs, and operating conditions not tested:
- Release blockers observed and their disposition:
- S2 findings corrected and successfully retested:
- Remaining S0/S1 findings, owners, and review dates:
- Known ambiguities and failure boundaries:
- Evidence unavailable or disputed:
- Dissent and minority reports:
- Sponsor and author recusals:
- Independent validators:
- Explicit non-claims: no legal certification, political legitimacy, physical-protection guarantee, field validation, or deployment approval
- Next review triggers and date:
- Evidence index and retrieval route:

The limitations page travels with every frozen Core copy. It may describe what survived testing; it may not imply that untested contexts passed.

## 24. Minimum exercise order

1. Run **FT-03A — FT-03 paper/audio-only variant**.
2. Run **FT-03B — FT-03 failed-radio variant**.
3. Run FT-02 with a displaced-majority inject under matched Core-only and Core-plus-Reference conditions.
4. Run FT-01 with the donor single-owner and fictional assurance-status conditions and preserve both donor decisions as scored artefacts.
5. Run FT-04 with the “protected safe hub” inject under matched Core-only and Core-plus-Reference conditions.
6. Compare the sealed red-line checklists, record document-condition defects, and publish failures, changes, limitations, and minority findings before the release decision.

The order is administrative, not hierarchical. Any test may be stopped, repeated, or run independently when the reason is recorded.

---

## 25. Reference notes

This protocol is informed by, but is not certified or endorsed by:

- [UNDP guidance on local governance in fragile and conflict-affected settings](https://www.undp.org/publications/local-governance-fragile-and-conflict-affected-settings), particularly inclusive and accountable participation;
- [IFRC community-engagement and accountability competencies](https://surgelearning.ifrc.org/sites/default/files/media/document/2022-08/191210-SURGE%20CORE%20COMPETENCY%20FRAMEWORK-A4-EN.pdf), particularly shaping response through community voice and usable information;
- [ICRC guidance on humanitarian corridors](https://www.icrc.org/en/document/how-humanitarian-corridors-work), particularly the limited and agreement-dependent character of safe passage;
- [FEMA Homeland Security Exercise and Evaluation Program](https://www.fema.gov/emergency-managers/national-preparedness/exercises/hseep), particularly objective-based observation, evaluation, and corrective-action planning.

These references support exercise design and protective interpretation. They do not grant AWF authority or settle the legal status of any real-world arrangement.

---

## Closing test

The question is not whether participants can recite the charter.

The question is whether, under pressure, they still:

> Feed without recruiting. Protect without possessing. Record without surveilling. Warn without ruling. Expire every emergency. Hand everything onward.

**Test → Witness → Correct → Retest → Freeze only what survives.**

Spiral kept, tide knows.
