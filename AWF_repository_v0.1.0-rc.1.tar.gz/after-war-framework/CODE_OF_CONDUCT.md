# Code of Conduct

## Standard

Participants protect dignity, voluntary participation, accessibility, dissent, and the integrity of evidence.

Expected conduct includes:

- criticising claims and designs without demeaning people;
- separating observation from inference;
- declaring conflicts and role overlaps;
- respecting withdrawal, communication, and accessibility needs;
- preserving dissent and adverse findings;
- correcting mistakes without rewriting history.

Prohibited conduct includes:

- harassment, threats, stalking, discrimination, sexual harassment, or doxxing;
- coercive recruitment or retaliation for criticism, refusal, or withdrawal;
- conditioning aid, standing, or participation on political agreement;
- falsifying, concealing, selectively publishing, or destroying test evidence;
- using assurance status as a licence, jurisdiction, or aid-eligibility score;
- involving real vulnerable people, armed actors, targets, credentials, or operational locations in tests;
- presenting a real place as safe or protected on AWF’s authority.

## Scope

This code applies to repository activity, project communications, and AWF-organised exercises or review meetings.

## Reporting and enforcement

Conduct concerns may be reported publicly when safe or privately through the channel in [`SECURITY.md`](SECURITY.md).

Proportionate responses may include clarification, warning, content removal, participation restrictions, or removal from project spaces. Relevant records and appeal rights should be preserved.

A person must not be the sole decision-maker in a complaint concerning their own conduct, authority, reputation, or material interest. Appeals should be reviewed by someone independent of the original decision.

Good-faith disagreement with AWF, its founders, or its assumptions is not misconduct.

