# Acknowledgements and Development Disclosure

## Initiation and curation

The After-War Framework was initiated and curated by **Dylan James Smith** as part of the wider Mycelial Continuity Thesis and its continuity-node work.

## Development method

The documents were developed through iterative human-led drafting, adversarial review, synthetic scenario design, and AI-assisted analysis.

ChatGPT assisted with drafting, structure, evidence objects, red-team conversion, repository preparation, and editorial consistency. Grok supplied AI-generated adversarial drafting critiques that helped identify activation, hostile-power, administrative-burden, representation, release-gate, and compression risks.

These acknowledgements describe assistance and provenance. AI critique is drafting input, not independent validation. The acknowledgements do not make any person or system a validator, confer legal authorship where the law does not recognise it, or imply endorsement by the developers of the named systems.

## Future contributors

Substantive human contributors, test participants, evaluators, translators, and reviewers should be credited with their consent and with their role accurately stated. Participation does not imply agreement with every part of AWF.

Test evidence and independent review—not attribution—determine release status.
