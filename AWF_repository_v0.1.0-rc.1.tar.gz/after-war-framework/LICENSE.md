# Licence

Except where otherwise stated, and to the extent copyright or related rights subsist and are controlled by the licensor, the original textual materials and forms in this repository are © 2026 Dylan James Smith and are licensed under the **Creative Commons Attribution-ShareAlike 4.0 International licence (CC BY-SA 4.0)**.

Canonical licence terms: <https://creativecommons.org/licenses/by-sa/4.0/legalcode>

Human-readable summary: <https://creativecommons.org/licenses/by-sa/4.0/>

Under that licence, you may share and adapt the licensed material, including commercially. The licence itself states the binding conditions, including attribution and ShareAlike. In summary, reusers should:

- give appropriate attribution;
- provide a link to the licence;
- indicate whether changes were made;
- distribute adaptations under the same or a compatible licence;
- avoid implying endorsement, validation, assurance, certification, or political authority.

## Suggested attribution

> After-War Framework (AWF), initiated and curated by Dylan James Smith, v0.1.0-rc.1, licensed CC BY-SA 4.0. Adapted material should identify its changes. No endorsement, assurance, or certification implied.

## Exclusions

Unless separately and explicitly licensed, this notice does not grant rights in:

- third-party material, quotations, standards, or linked sources;
- personal data, test-participant data, or sensitive records;
- names, logos, certification marks, or other source-identifying marks;
- software added later under a separate licence;
- material that the contributor had no authority to license.

The project guidance and non-claims do not add a copyright restriction beyond CC BY-SA 4.0. The licence governs copyright permissions; it does not itself grant jurisdiction, legal authority, access to protected information, permission to endanger people, or exemption from applicable law and professional duties.

Creative Commons licences are not legal advice. Contributors and reusers remain responsible for determining which rights they hold and which obligations apply.
