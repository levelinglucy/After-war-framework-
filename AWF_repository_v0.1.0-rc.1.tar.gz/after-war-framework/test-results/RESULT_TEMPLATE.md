# Synthetic Test Result

> **Status:** Proposed evidence pending independent review. Publication confers no certification, assurance, recognition, jurisdiction, protection status, or field-validation claim.

This notice must remain attached before and after the release decision. A result is evidence, not a status upgrade.

## Identification

- Result ID:
- Run date:
- Test and variant:
- Run classification:
- Framework version or checksum:
- Protocol version or checksum:
- Scenario identifier and precommitted digest:
- Post-run digest verified: yes / no / not possible
- Document condition:
- Paired-run identifier, if any:

## Safety and evidence boundary

- Synthetic actors and fictional resources only: yes / no
- Closed, stoppable, reversible exercise: yes / no
- Sensitive-data review completed: yes / no
- Voluntary-participation and withdrawal notice completed: yes / no
- Recording and public-attribution consent recorded: yes / no / no recording or attribution
- Retention, deletion, access, and debrief plan completed: yes / no
- Stop or incident events:
- Withheld material and reason:

## Roles and independence

- Test lead:
- Participants, relevant experience, prior exposure, and condition-assignment method:
- Safety controller:
- Independent observer:
- Evaluator:
- Validator or review quorum:
- Records steward:
- Sponsor or author involvement:
- Conflicts and recusals:
- Logged clarifications:

## Predeclared conditions

- Failure hypothesis:
- Inject sequence and clock:
- Fictional resources and constraints:
- Care threshold or public-output budget:
- Stop conditions:
- Pass/fail criteria:
- Automatic release blockers:
- Deviations:

## Observations

Separate direct observation from interpretation.

### Observed

### Inferred

### Uncertain

### Alternative explanations

## Original artefacts and evidence index

|ID|Description|Integrity or location reference|Public/redacted/withheld|
|---|---|---|---|
||||

## Scoring

- Outcome: pass / pass with findings / fail / stopped / inconclusive
- Highest proposed severity:
- Automatic release blocker observed:
- Red lines preserved:
- Assurance capture:
- Layer drift:
- Legitimacy-debt closure:
- Administrative burden:
- Core-only/Core-plus difference:

## Findings, correction, and retest

|Finding|Observation|Severity and rationale|Owner|Smallest correction or containment|Retest|
|---|---|---|---|---|---|
||||||

## Dissent and limitations

- Minority or dissenting view:
- Independence limitations:
- Exposure or learning effects:
- Missing evidence:
- Claims this result cannot support:

## Decision record

- Independent reviewer or quorum:
- Gate treatment:
- Core change authorised:
- Retest required:
- Decision expiry or next review:
- Recused people:

An author shakedown leaves this section pending independent review and cannot designate Core as frozen.
