# Public Synthetic Test Results

No test results are included in `v0.1.0-rc.1`.

This directory is for safe, redacted, synthetic evidence—including failures, stopped runs, dissent, and inconclusive results. A result’s presence does not mean it has been accepted, independently validated, or used to freeze Core.

## Naming

Use:

`YYYY-MM-DD_TEST-ID_SHORT-DESCRIPTION.md`

Examples:

- `2026-09-15_FT-03A_AUTHOR-SHAKEDOWN.md`
- `2026-10-02_FT-02_PAIRED-RUN-01.md`

## Required contents

Start from [RESULT_TEMPLATE.md](RESULT_TEMPLATE.md). Include:

- exact framework, protocol, scenario, and document-pack versions;
- run classification and participant exposure;
- scenario precommitment and post-run verification;
- roles, conflicts, recusals, and independence limits;
- original synthetic outputs or a safe evidence index;
- direct observations separated from inference and uncertainty;
- release-blocker and cross-cut scores;
- severity rationale, dissent, mitigation, and retest;
- deviations, stopped conditions, and administrative burden;
- a statement that result publication confers no certification, assurance, or field-validation status.

## Exclude

Do not publish names or identifying allegations, vulnerable-person data, medical or property records, active operational locations, credentials, real aid routes, public-service details, armed-actor information, or material that could enable harm. Follow [SECURITY.md](../SECURITY.md) when safe public disclosure is not possible.
