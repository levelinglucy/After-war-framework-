# AWF Quick Start

## Read the status first

AWF is a release candidate for synthetic testing. It is not field validated and gives nobody authority over people, territory, aid, records, or infrastructure.

## If you are reading

Start with:

1. [`core/AWF_CORE.md`](../core/AWF_CORE.md)
2. [`STATUS.md`](../STATUS.md)
3. [`KNOWN_LIMITATIONS.md`](../KNOWN_LIMITATIONS.md)

Use the [Full Reference](../reference/AFTER_WAR_FRAMEWORK.md) to interpret and challenge Core. Silence in Core is not permission to override a Reference prohibition.

## If you are a solo steward

1. Choose an exercise from the [Field Test Protocol](../protocol/AWF_CORE_FIELD_TEST_PROTOCOL.md). FT-03 paper/audio is the suggested first shakedown.
2. Label the run **Author shakedown**.
3. Use only fictional actors, locations, resources, and harms.
4. Predeclare the clock, stop conditions, accessibility needs, and—where applicable—the latest safe care time.
5. Keep the scenario fixed during the run. Log any clarification.
6. Preserve raw synthetic artefacts, timing, uncertainty, and failures.
7. Do not approve your own S2-or-higher mitigation or claim that the run passes the independent gate.
8. Publish the result in `test-results/`.

Do not simulate pressure through real deprivation or distress. Use queued fictional tasks and time-bounded injects.

## If you are organising an independent exercise

- Separate sponsor, facilitator, evaluator, records custodian, and validator where feasible.
- Record conflicts and temporary role overlap.
- Fully recuse authors and sponsors from release-gate scoring, final severity, acceptance of their own mitigation, and the release decision.
- For paired testing, give Core-only and Core-plus teams identical injects, clocks, resources, roles, thresholds, and decision points.
- Score the red-line checklist independently before group discussion.
- In FT-04, score the original timed public notice.
- In FT-03, stop paperwork at the predeclared care threshold and record documentation burden as a design finding.

## Report the result

Every result identifies the test and protocol version, document pack, participant and evaluator roles, scenario hash or identifier, timings and stop conditions, observed decisions and artefacts, red-line results, findings and severity, dissent and uncertainty, proposed shortest corrective change, and retest requirement.

Remove unnecessary personal information. Never submit live credentials, vulnerable-person data, operational locations, or real security details.

**A clean-looking form is not the objective. The objective is to discover whether the rule survives pressure.**

## Publish the release candidate

Use the authoritative [repository upload guide](REPOSITORY_UPLOAD.md) and complete the [publication checklist](PUBLICATION_CHECKLIST.md). Finalise all release metadata, regenerate and verify `MANIFEST.sha256`, commit the exact bundle, push it, create immutable tag `v0.1.0-rc.1`, and then publish the GitHub prerelease. Do not move or overwrite the tag; corrections become `v0.1.0-rc.2`.

Attach the [Known Limitations](../KNOWN_LIMITATIONS.md) to the release description or link it prominently. The blank [Limitations template](../templates/LIMITATIONS_PAGE_TEMPLATE.md) is for a future Frozen Test Draft after evidence exists.
