# Publication Checklist — v0.1.0-rc.1

Complete this checklist in order. Phase 1 is local and must pass before the first push. Phase 2 requires the pushed repository and must pass before tagging. Phase 3 covers the immutable tag and prerelease. A box in a later phase cannot be treated as complete in advance.

## Phase 1 — Local pre-push

### Safety and privacy

- [ ] No real vulnerable-person, medical, property, safeguarding, or identity data is present.
- [ ] No live credentials, operational locations, aid routes, security arrangements, or armed-actor details are present.
- [ ] Every exercise and example is visibly synthetic.
- [ ] No participant recording, quotation, attribution, or personal data is published outside recorded consent and data-handling terms.
- [ ] Public safety language does not imply that an actual person, route, service, or place is safe or protected.
- [ ] `SECURITY.md` explains that GitHub is not an emergency-response channel.

### Status integrity

- [ ] README states release-candidate and not-field-validated status.
- [ ] `STATUS.md` has the actual publication date and no longer says `Publication: Pending`.
- [ ] `CITATION.cff` has the matching `date-released` value.
- [ ] `CITATION.cff` has the actual repository, landing-page, and version-tag URLs.
- [ ] README, Status, Changelog, release notes, Manifest, and citation notes contain no “prepared”, “pending”, “unreleased”, or draft-file status in the tagged commit.
- [ ] The release-notes file contains no draft banner in the tagged commit. The GitHub Release may remain a private draft in the GitHub interface until it is published from that tag.
- [ ] Repository publication is not described as certification, assurance, recognition, jurisdiction, authority, or protection status.
- [ ] Solo runs are labelled author shakedowns and excluded from independent validation.

### Release gate

- [ ] All six automatic release blockers appear consistently in Core-facing summaries, issue forms, and evaluator materials.
- [ ] FT-03 care-threshold failure is assigned to receipt/test design rather than a person who prioritises care.
- [ ] FT-04 requires scoring the original timed public sentence.
- [ ] FT-02 and FT-04 matched comparisons vary only the document pack.
- [ ] Author and sponsor recusal is visible.
- [ ] Completion is not represented as a passed independent gate.

### Repository integrity

- [ ] Every internal Markdown link resolves.
- [ ] Every issue form and `CITATION.cff` parses as YAML.
- [ ] Issue-form field identifiers are unique within each file.
- [ ] No unset owner, URL, email, DOI, date, or contact field remains.
- [ ] `VERSION`, README, Status, Changelog, release notes, and citation metadata agree.
- [ ] `MANIFEST.sha256` was regenerated after the last content change.
- [ ] `sha256sum -c MANIFEST.sha256` passes from the repository root.
- [ ] The exact release bundle is committed locally and ready to push.

## Phase 2 — Post-push, before tag

### GitHub settings and rendered checks

- [ ] All six issue forms render correctly after upload.
- [ ] Every initial label from [`LABELS.md`](LABELS.md) exists; GitHub silently omits automatic labels that do not exist.
- [ ] Private vulnerability reporting is enabled, monitored, and tested before reports are invited or the prerelease is announced.
- [ ] Default branch protection or a ruleset requires pull-request review when independent maintainers become available.
- [ ] Discussions are optional and must not become an emergency, incident, or sensitive-data channel.
- [ ] README links, status warnings, and the limitations link render correctly on GitHub.
- [ ] The pushed release commit matches the locally verified bundle. Any content change has been committed, pushed, and followed by a regenerated and reverified `MANIFEST.sha256`.

## Phase 3 — Tag and prerelease

- [ ] Tag `v0.1.0-rc.1` points to the reviewed release commit.
- [ ] The tag will not be moved or overwritten.
- [ ] GitHub Release is marked as a prerelease.
- [ ] Release notes link Core, Reference, Protocol, Status, Known Limitations, and Quick Start.
- [ ] The limitations page remains attached or prominently linked.
- [ ] Corrections will use `v0.1.0-rc.2` or a later version.
- [ ] The published tag, archive, citation URL, release date, and displayed release notes have been checked after publication.
