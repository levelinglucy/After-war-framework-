# Uploading the Repository

The archive is a complete repository working tree. Do not copy and paste every document into one GitHub page, and do not put the `after-war-framework` folder itself inside another folder of the same name.

## Before upload

1. Unzip the archive and open the resulting `after-war-framework` folder.
2. Choose the destination account and repository name so the exact GitHub URL is known.
3. Open **Phase 1 — Local pre-push** in [`PUBLICATION_CHECKLIST.md`](PUBLICATION_CHECKLIST.md). The following metadata steps are part of that phase; do not mark it complete until they and the remaining local checks pass. Leave the post-push and tag phases open until those events occur.
4. In `README.md`, remove “prepared” from the status and change the repository table’s “Draft release notes” description to “Release notes”.
5. In `STATUS.md`, change “Prepared release candidate” to “Current prerelease” and replace `Publication: Pending` with the actual date.
6. In `CHANGELOG.md`, replace `Unreleased` with that date.
7. In `releases/v0.1.0-rc.1.md`, remove the draft banner and change “prepared first public release candidate” to “first public release candidate”.
8. In `MANIFEST.md`, replace `Publication: Pending` with the date.
9. In `CITATION.cff`, add `date-released`, the actual repository and landing-page URLs, and the actual tag URL under `preferred-citation`; change its note from “Prepared” to “Published prerelease candidate”.
10. Regenerate `MANIFEST.sha256` after every final metadata edit.

At the CFF root, add fields shaped like these, substituting the actual account and date:

```yaml
date-released: "YYYY-MM-DD"
repository: "https://github.com/ACCOUNT/after-war-framework"
url: "https://github.com/ACCOUNT/after-war-framework"
```

Inside the existing `preferred-citation` mapping, add its URL at the same indentation as `type`, `year`, and `version`:

```yaml
  url: "https://github.com/ACCOUNT/after-war-framework/releases/tag/v0.1.0-rc.1"
```

On GNU/Linux, regenerate the manifest from the repository root with:

```sh
find . -type f ! -name MANIFEST.sha256 ! -path './.git/*' -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > MANIFEST.sha256
```

On macOS, use:

```sh
find . -type f ! -name MANIFEST.sha256 ! -path './.git/*' -print | LC_ALL=C sort | while IFS= read -r f; do shasum -a 256 "$f"; done > MANIFEST.sha256
```

On Windows PowerShell, use:

```powershell
Get-ChildItem -Recurse -File |
  Where-Object { $_.Name -ne 'MANIFEST.sha256' -and $_.FullName -notmatch '[\\/]\.git[\\/]' } |
  Sort-Object FullName |
  ForEach-Object {
    $hash = (Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLower()
    $path = (Resolve-Path -Relative $_.FullName) -replace '\\','/'
    "$hash  $path"
  } | Set-Content -Encoding ascii MANIFEST.sha256
```

These commands assume the supplied filenames have not been changed and none contains a newline.

## Option A — GitHub Desktop

1. In GitHub Desktop, choose **File → Add Local Repository** and select the unzipped folder.
2. If prompted, create a repository in that folder without changing or nesting the files.
3. Review the complete file list, including `.github/ISSUE_TEMPLATE/`.
4. Commit with a message such as `Prepare AWF v0.1.0-rc.1`.
5. Choose **Publish repository**, use the name `after-war-framework`, and make it public only after the safety check.
6. On GitHub, complete **Phase 2 — Post-push, before tag** in the publication checklist, including Private Vulnerability Reporting, labels, README links, and issue forms.
7. Only after Phase 2 passes, create the immutable tag and prerelease and complete Phase 3.

## Option B — GitHub CLI

From inside the unzipped folder, after installing and authenticating GitHub CLI:

```sh
git init
git add .
git commit -m "Prepare AWF v0.1.0-rc.1"
gh repo create after-war-framework --public --source=. --remote=origin --push
```

Stop here and complete **Phase 2 — Post-push, before tag** in the publication checklist. If any repository file changes, regenerate and verify `MANIFEST.sha256`, commit, and push the correction before tagging. Then run:

```sh
git tag -a v0.1.0-rc.1 -m "AWF v0.1.0-rc.1"
git push origin v0.1.0-rc.1
```

Then create a GitHub prerelease from the tag and paste the contents of [`releases/v0.1.0-rc.1.md`](../releases/v0.1.0-rc.1.md).

Before announcing the repository or inviting reports, enable and test GitHub Private Vulnerability Reporting.

Do not run these commands from a parent folder containing unrelated files. Confirm that the current directory contains this README, `core/`, `protocol/`, and `.github/` first.

## Option C — GitHub web upload

Create an empty public repository named `after-war-framework`, choose **uploading an existing file**, and drag the contents of the unzipped folder into the uploader. Confirm that nested paths and the hidden `.github` directory are present before committing. Complete Phase 2 of the publication checklist before creating a tag or prerelease.

The web route is easiest to mis-nest or incompletely upload. If `.github/`, nested test folders, or hidden files are missing, use GitHub Desktop or the CLI instead.

## After upload and before tagging

- Open every link in the repository-content table in `README.md`.
- Open **New issue** and confirm all six issue forms render.
- Verify the manifest locally with `sha256sum -c MANIFEST.sha256` where available.
- Complete Phase 2 of the publication checklist.

## After tagging

- Mark the GitHub Release as a prerelease.
- Do not claim field validation, certification, assurance, jurisdiction, authority, or protection status.
- Use a new tag for every correction; never move the published tag.
- Complete Phase 3 of the publication checklist and verify the published metadata and links.
