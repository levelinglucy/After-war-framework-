# Suggested GitHub Labels

Create these labels before relying on automatic labels in the issue forms. Labels are indexing aids only. They cannot assign final severity, accept risk, discharge legitimacy debt, validate a test, certify a node, or freeze Core.

## Initial labels

|Label|Colour|Purpose|
|---|---|---|
|`type:test-result`|`0E8A16`|Synthetic exercise result|
|`type:core-defect`|`B60205`|Evidence-backed Core defect|
|`type:protocol-defect`|`D93F0B`|Test-instrument defect|
|`type:accessibility`|`5319E7`|Functional-access barrier|
|`type:safety-privacy`|`B60205`|Safety, exposure, or misuse concern|
|`status:needs-triage`|`EDEDED`|Initial review incomplete|
|`evidence:synthetic`|`0E8A16`|Closed fictional exercise evidence|
|`area:core`|`0052CC`|Portable Core|
|`area:protocol`|`1D76DB`|Field Test Protocol|

## Add as the evidence base grows

- Severity: `severity:S0` through `severity:S4`.
- Gate: `gate:release-blocker`, `gate:conditional`, `gate:nonblocking`.
- Workflow: `status:needs-evidence`, `status:needs-independent-review`, `status:needs-retest`, `status:blocked`, `status:ready-for-decision`.
- Tests: `test:FT-01`, `test:FT-02`, `test:FT-03`, `test:FT-04`, `test:paired-documents`, `test:author-shakedown`.
- Evidence: `evidence:independent`, `evidence:author-produced`, `evidence:literature`.
- Risks: `risk:assurance-capture`, `risk:layer-drift`, `risk:legitimacy-debt`, `risk:administrative-burden`, `risk:false-safety-language`, `risk:single-actor-isolation`, `risk:mandate-integrity`.

When a label and the underlying record conflict, the record controls. Changing a label never changes the evidence or decision history.

