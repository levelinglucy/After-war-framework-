# Contributing

AWF welcomes evidence-backed criticism, synthetic test results, accessibility findings, translations, protocol repairs, and tightly scoped drafting corrections.

## Safety boundary

Do not use this project to test or coordinate activity involving:

- real armed actors, factions, targets, checkpoints, or public services;
- real vulnerable people or identifiable personal data;
- live credentials, unauthorised systems, or non-public infrastructure;
- real operational locations, evacuation routes, shelters, or resource stores;
- weapons, coercion, recruitment, surveillance, retaliation, or resource seizure;
- unsupported claims that a real place is safe, protected, secured, or AWF-certified.

Exercises use synthetic actors, fictional resources, closed environments, voluntary participation, reversible outcomes, and explicit stop conditions.

If a report requires sensitive details, follow [`SECURITY.md`](SECURITY.md) instead of opening a public issue.

## Before submitting

Search existing issues and identify whether the proposal concerns a Core defect, protocol defect, test result, accessibility finding, Reference clarification, or safety/misuse risk.

## Evidence requirements

Core-change proposals should include:

- affected version and section;
- exact language at issue;
- test identifier or reproducible synthetic scenario;
- what was observed;
- what was inferred and remains uncertain;
- credible effect on rights, safety, continuity, custody, or interpretation;
- proposed severity, subject to independent review;
- the shortest adequate amendment;
- retest criteria.

A preference or hypothetical concern may be recorded for investigation, but it does not by itself justify changing test-frozen Core.

## Pull requests

Pull requests must use a focused scope, preserve attribution and correction history, update the changelog where material, identify affected tests/templates/translations, avoid silently weakening a Core safeguard, disclose material AI assistance or copied source material, and include a retest plan when changing operational language.

Do not rewrite or delete an existing release tag. Corrections belong in a new version.

By submitting a contribution, you represent that you have the right to submit it and agree that accepted original text and forms may be distributed under the repository’s stated CC BY-SA 4.0 licence unless explicitly agreed otherwise.

## Publishing test results

Publish failures, ambiguities, near misses, and administrative burden—not only successes. Reports distinguish participant error, facilitator error, protocol defect, Core compression defect, and contextual limitation.

Remove personal and sensitive information before publication. An attempted external transmission must not be reported as received oversight unless receipt is independently confirmed.

## Review

Maintainers may request clarification, synthetic reproduction, independent review, or narrower wording. Contributors may appeal a closure or severity decision through a reviewer not solely responsible for the original decision.

Participation never creates entitlement to authority, certification, aid, compensation, or control over another contributor.

