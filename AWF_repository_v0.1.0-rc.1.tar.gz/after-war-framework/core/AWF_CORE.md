# AWF-Core v0.1

## Portable field kernel of the After-War Framework

**Status:** Release candidate under test freeze — normative expansion paused; four structural exercise types, five minimum entries, and an independent release decision required before frozen status  
**Validation:** Synthetic release gate incomplete; not field validated. Publication or use confers no certification, assurance, recognition, jurisdiction, authority, or protection status.  
**Parent:** After-War Framework (AWF) v0.1 — Parallel Build  
**Purpose:** Preserve the minimum rights, authority, aid, record, challenge, handoff, and sunset rules when the full Reference framework cannot be carried or administered.  
**Required companions:** [Release Status](../STATUS.md) and [Known Limitations](../KNOWN_LIMITATIONS.md)

---

## 1. Core premise

Survival competence does not create sovereignty.

Control of food, water, medicine, shelter, energy, communications, security, records, transport, technical systems, or continuity infrastructure does not create a right to govern the people who depend upon them.

AWF-Core binds the conduct of participants. It does not create a government, jurisdiction, army, police service, court, detention power, property title, territorial claim, or political mandate.

Every distributed Core copy must retain the status and validation header and include or link the release-specific Status and Known Limitations. Removing the non-claims or representing candidate text as frozen is not a conforming AWF copy.

AWF-Core is a minimum floor, not a waiver of the Field or Reference safeguards. Silence or compression in Core does not authorise conduct prohibited elsewhere. At minimum:

- humanitarian information does not become intelligence or political selection;
- custody, possession, or occupancy does not become ownership or title;
- an AI alert does not become authority;
- assurance does not become jurisdiction or eligibility for essential aid;
- a person, route, service, or place is not described as safe, protected, or guaranteed without a verified protection basis.

> Preserve life without purchasing obedience. Keep emergency power temporary. Hand every function onward.

## 2. Rights and protection floor

Every AWF participant must preserve:

1. **Life and essential care:** Water, food, shelter, sanitation, medical care, essential energy, communication, and protection are allocated by need and credible continuity requirements.
2. **Equal civilian protection:** Protection does not depend on neutrality, faction, identity, politics, wealth, disability, age, gender, religion, ethnicity, nationality, class, or usefulness.
3. **No collective punishment:** Responsibility is individual and evidence-based. Family, community, profession, residence, or attributed allegiance does not prove guilt.
4. **Dignity and agency:** Aid, records, movement, family contact, participation, and safe exit cannot be exchanged for political loyalty, labour, sex, intelligence, publicity, religious conversion, or obedience.
5. **Accessibility:** Essential services and decisions must have practicable mobility, sensory, communication, cognitive, supported-decision, local, remote, and offline routes.
6. **Children’s protective floor:** Children receive nutrition, shelter, health care, safeguarding, family support, and learning. This does not make other equally urgent people disposable.
7. **No forced reconciliation or arbitrary movement:** AWF may not compel forgiveness, reconciliation, personal or family contact, or cultural participation. Return, relocation, movement limits, or testimony remain voluntary unless a competent lawful process imposes an individually necessary, proportionate, accessible, and contestable requirement with full safeguards. Any such requirement is not consent or reconciliation.
8. **Evidence and correction:** Records distinguish observation, inference, allegation, uncertainty, dissent, and correction. An archive is not a verdict.
9. **Preservation before irreversible judgment:** Preserve people, records, evidence, culture, capability, and recoverable system state where safe before irreversible loss.
10. **Handoff and sunset:** Every exceptional role and power has a successor, review, expiry, restoration path, and end.

Nothing in AWF-Core lowers protection required by applicable law.

## 3. Forbidden conversions

Do not permit:

- survival competence → political sovereignty;
- protection → occupation;
- aid → obedience;
- humanitarian information → intelligence targeting;
- emergency → permanence;
- custody → ownership;
- evidence → surveillance;
- competence → caste;
- victimhood → collective punishment;
- victory → historical infallibility;
- AI warning → AI rule;
- transparency → exposure of vulnerable people;
- child protection → age caste;
- reconciliation → compelled forgiveness;
- reconstruction → dispossession;
- vetting or anti-corruption → political purge;
- continuity-node capability → territorial authority.

## 4. Activation and mandate ceiling

Activation binds conduct before it grants mandate.

- **A0 — Self-binding:** Any actor may adopt AWF-Core for its own conduct.
- **A1 — Service coordination:** Providers may coordinate services they already administer lawfully or consensually. They do not gain authority over recipients or territory.
- **A2 — Community mandate:** Affected people grant a defined, recorded, recallable function through a process that can be challenged.
- **A3 — Lawful mandate:** A competent institution grants a bounded function under applicable law.
- **A4 — Necessity-only:** The minimum temporary action needed to preserve life, care, records, or immediate integrity when A2 or A3 cannot be obtained in time.

A4 does not authorise government, detention, property adjudication, forced recruitment, removal of officials, security command, constitutional change, political representation, or permanent appointment. It expires automatically.

No actor may cite its own AWF receipt, emergency action, supplies, technical competence, or survival performance as evidence that other people consented to its rule.

Attendance, silence, residence, receipt of aid, or absence of a recorded objection does not establish A2. An A2 record must identify, as far as safely possible:

- who was reached, absent, displaced, inaccessible, dependent upon the organiser, or unable to participate safely;
- who controlled food, transport, communications, meeting access, and security;
- the methods for private dissent, accessible participation, recall, replacement, and bypass;
- competing or overlapping mandates;
- the exact function, geography, duration, expiry, and review route.

Where meaningful A2 evidence cannot be established, necessary work may continue within A1 or A4 limits, but the actor may not claim an A2 mandate.

### Legitimacy debt

An action taken without ordinary consent or review creates a legitimacy debt. Record:

- why consent or review was impossible;
- whose agency or rights were affected;
- the exact function and limit;
- dissent, refusal, and uncertainty;
- review, remedy, handoff, and expiry.

Repeated necessity increases the debt. It does not mature into sovereignty, title, precedent, or permanent office.

Where no reviewer is accepted by every affected faction, a legitimacy debt may be marked **procedurally discharged** only after accessible notice, evidence disclosure, preserved dissent, plural review where feasible, response to material challenges, remedy or reasoned refusal, and expiry or handoff. Procedural discharge is not ratification, innocence, legitimacy, or precedent. The underlying action may remain **substantively contested**. Neither the actor that incurred the debt nor the custodian holding its record, separately or jointly, may discharge it without at least one independent, non-conflicted reviewer outside their organisational, financial, custodial, and dependency control.

Debt status must be one of: open, partially discharged, procedurally discharged but substantively contested, fully discharged through a competent accepted process, or impossible to review. No status may erase the original record or dissent.

## 5. Humanitarian firewall

Essential aid is based on need. It is not conditional upon political, military, religious, commercial, or personal cooperation.

Humanitarian records must be separated from intelligence, recruitment, immigration enforcement, political profiling, and factional targeting except where a specific lawful safeguarding duty requires limited disclosure.

Every provider should record:

- what is available and what is missing;
- allocation criteria;
- barriers and exclusions;
- complaints and corrections;
- external dependencies and fallbacks;
- the person or institution responsible for delivery.

People may complain without losing aid.

AWF assurance status must not be used as an input, proxy, tie-breaker, or adverse factor for access to life-saving assistance, basic participation, legal identity, safe exit, personal records, or lawful independent activity. Any causal use requires immediate correction and restoration where possible and is recorded as an assurance-capture incident.

## 6. Emergency kernel

Every emergency action states:

- trigger and evidence;
- defined harm;
- smallest permitted action;
- actor and authority basis;
- people, rights, services, or records affected;
- maximum duration and automatic expiry;
- review and challenge;
- restoration and handoff;
- record and notification requirements.

Emergency authority may not:

- amend the rights floor;
- erase or conceal its own record;
- create a permanent class or inherited restriction;
- treat dissent as proof of dangerousness;
- impose collective punishment;
- convert aid into leverage;
- transfer public assets to its holders without independent process;
- give an AI autonomous power over force, detention, rights, or political status;
- renew itself by silence.

If no second person is available, one person may take the minimum immediate protective action. That person cannot grant the action indefinite continuation or final retrospective approval. The action expires unless an independent, federated, or affected-person review occurs.

Where that same person also controls the available record, transport, and communication channel, the receipt is marked **Single-Actor Isolation**. The flag records failed witness or transmission attempts, prevents self-certification of closure, and remains until a second custodian or review route receives the record. An attempted external copy is evidence of an attempt, not proof of independent oversight.

## 7. Minimum emergency receipt

Record at least:

1. action;
2. trigger, evidence, and uncertainty;
3. acting person or system;
4. people, rights, services, or records affected;
5. smallest permitted scope and explicit prohibitions;
6. expiry;
7. witness, external copy, or reason neither was possible;
8. review, correction, and handoff route.

When immediate action prevents completion, record fields 1, 3, 5, and 6 first. Missing fields become legitimacy debt and must be completed before renewal.

A Single-Actor Isolation receipt cannot be renewed merely by repeating the same unavailable-review explanation. Reissuing, relabelling, or copying the same measure does not reset its expiry. After expiry, a distinct later A4 action is permitted only when materially new current evidence establishes continuing immediate necessity, the scope does not expand, cumulative legitimacy debt is inherited, another hard expiry is set, attempts to obtain external review continue, and reconciliation occurs at the first safe external contact.

Paper, audio, symbol, tactile, witnessed oral, radio, and offline digital records are valid when provenance, custody, correction, and retrieval can be preserved.

Recordkeeping must not consume the food, care, power, mobility, attention, or time required for immediate life-preserving work.

## 8. Representation

No person permanently owns a community’s voice.

A representative record states:

- constituency and function claimed;
- selection or recognition method;
- scope, duration, and expiry;
- who participated, dissented, or could not participate;
- conflicts, compensation, and dependencies;
- recall, replacement, and bypass routes.

An issue-specific mandate does not become a general political mandate. Absence is not consent. More than one representation route may remain active.

## 9. Coercive reality and hostile power

AWF-Core cannot guarantee compliance by an armed actor, occupying authority, state agency, donor, corporation, or resource custodian that rejects its constraints.

Do not represent dialogue, monitoring, paperwork, public warning, or assurance as physical protection. Any claim that a person, route, service, or place is protected must identify:

- who can implement protection;
- the commitment or mandate relied upon;
- verified limits;
- residual risk;
- the failure response.

Every access, service, evacuation, or protection claim that depends upon a coercive or non-adhering actor must carry an **access-dependency label** stating the actor, verified terms, time and geographic limits, residual risk, reassessment point, and fallback. If protection cannot be verified, describe the service and its limitations; do not describe the place or route as safe, secured, neutralised, protected, or guaranteed.

Contact with a coercive actor for humanitarian access or civilian protection does not itself grant recognition, legitimacy, immunity, partnership, or political authority.

Contact must not silently create an exclusive gatekeeping role. Any exclusivity demand, restriction on contact with others, or use of access permission for publicity or political recognition is recorded as a hostile-power dependency and reviewed before continued reliance where immediate safety permits.

Preserve the purpose of contact, requested commitments, response, refusal or breach, information firewall, incident route, review, and a protected external record where feasible.

Do not withdraw essential aid from civilians as leverage against a non-adhering actor. Do not pretend that a receipt has disarmed coercive power.

## 10. Continuity nodes do not become governments

A continuity node may preserve care, food, water, repair, shelter, energy, communications, records, culture, learning, and handoff.

It may not claim territorial or political authority merely because others depend on it.

- AWF councils may not seize node archives, labour, resources, or custody by declaring emergency.
- Nodes may not condition essential aid on recognition of their authority.
- Humanitarian, security, intelligence, governance, and archive functions remain separated.
- Nodes may refuse unsafe custody and provide a witness or transfer path.
- Nodes can decouple without surrendering their records or erasing history.
- No node maintainer owns the federation.

## 11. Property and displacement floor

Temporary custody, protection, or occupation does not create title.

Where formal records are absent or discriminatory, consider an evidence mosaic: registries, leases, taxes, utilities, contracts, maps, photographs, occupancy, use, improvements, inheritance, customary rights, collective rights, witnesses, humanitarian records, and competing evidence.

No single category is automatically conclusive. Preserve provenance, contradiction, missing evidence, current-occupant rights, notice, reasons, review, and appeal.

Temporary measures may protect property or current occupants without deciding title. No return is voluntary if aid, shelter, documents, movement, or family unity is withheld to produce it.

## 12. Human–AI boundary

An AI may index evidence, expose contradictions, identify expiry, translate, model scenarios, issue an alert, and recommend a bounded pause.

It may not govern, command force, detain, punish, score loyalty, decide guilt, allocate political rights, deny basic aid, determine historical truth, or renew emergency authority.

Alerts are classified:

- **PA0 — Rule:** a directly testable control appears to have failed;
- **PA1 — Evidence:** an important factual premise may be wrong or incomplete;
- **PA2 — Forecast:** future harm is predicted;
- **PA3 — Integrity:** the AI, evidence, operator, configuration, or alert path may be compromised.

Only a pre-enumerated PA0 condition may trigger a pre-authorised technical pause. PA1 and PA2 require human confirmation before rights-affecting action. PA3 freezes expansion, preserves state, and triggers independent comparison.

Essential care must remain available through a safe human-operable route. No system decides the validity of its own alert alone.

Affected people need notice of AI involvement, the trigger and material evidence, uncertainty, a human able to change the outcome, a non-AI route, appeal, correction, rollback, expiry, and remedy.

## 13. Compromise Ledger

When only harmful options appear available, record:

- the right or safeguard under pressure;
- the danger claimed;
- the exact concession and continuing prohibitions;
- who benefits and who bears risk;
- absent voices and dissent;
- alternatives attempted;
- expiry, review, exit, and non-precedent status;
- correction, restitution, or reparation owed.

Recording a compromise does not certify its legality, morality, proportionality, or future acceptability. It may not silently amend the rights floor or erase evidence.

## 14. Challenge, correction, and handoff

Every material action needs a route to:

- ask who acted and under what authority;
- see the public part of the evidence and uncertainty;
- preserve dissent;
- request accessibility and support;
- challenge identity, attribution, mandate, scope, or result;
- correct the record without erasing the original entry;
- seek independent or federated review;
- obtain remedy where owed;
- transfer the function and records;
- end the exceptional power.

Confidentiality may protect privacy, witnesses, children, survivors, safe locations, and active protective work. It requires a category, reason, custodian, minimum scope, review, expiry, and later-release decision.

“Security,” “stability,” “classified,” or “misinformation” is not a sufficient reason by itself.

## 15. Field handoff test

Before relying on an AWF-Core arrangement, ask:

- Can the primary actor disappear without destroying the function?
- Can a newcomer retrieve the minimum records?
- Does every exceptional power expire?
- Can people receive aid without obedience?
- Can a representative be bypassed or replaced?
- Can an AI be unavailable or wrong without blocking care?
- Can an armed actor’s refusal be recorded without claiming false protection?
- Can disputed property remain protected without deciding title by force?
- Can the function move to a legitimate institution?
- Can AWF itself end?

If the answer is no, record the failure, containment, owner, expiry, and retest.

---

## Pocket rule

> Feed without recruiting. Protect without possessing. Record without surveilling. Warn without ruling. Act only within mandate or immediate necessity. Expire every emergency. Preserve dissent. Correct error. Hand everything onward.

**Survive → Stabilise → Repair → Renew → Handoff → Sunset.**

Spiral kept, tide knows.
