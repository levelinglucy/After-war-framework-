# Release Manifest

**Prepared bundle:** `v0.1.0-rc.1`  
**Publication:** Pending  
**Validation status:** Synthetic release gate not yet completed; no field validation

## Normative and explanatory layers

- `core/AWF_CORE.md` — portable Core v0.1, under synthetic test freeze.
- `reference/AFTER_WAR_FRAMEWORK.md` — full AWF v0.1 design reference, open to revision.
- `protocol/AWF_CORE_FIELD_TEST_PROTOCOL.md` — Field Test Protocol v0.1 and release-gate rules.
- `templates/LIMITATIONS_PAGE_TEMPLATE.md` — template for a future evidence-backed Frozen Test Draft.

## Test and evidence layer

- `tests/` — pack boundaries, scenario-variant policy, evaluator checklist, and author-shakedown forms.
- `test-results/` — result requirements and blank public result template; no results included.

## Governance and publication layer

- `README.md`, `STATUS.md`, `KNOWN_LIMITATIONS.md`, and `CHANGELOG.md`.
- `GOVERNANCE.md`, `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, and `SECURITY.md`.
- `LICENSE.md`, `ACKNOWLEDGEMENTS.md`, and `CITATION.cff`.
- `.github/` issue forms and pull-request template.
- `docs/` quick-start, labels, publication checklist, and upload guide.
- `releases/v0.1.0-rc.1.md` draft release notes.

## Integrity

`MANIFEST.sha256` records a digest for every release file except itself. Regenerate it after any change and before tagging. A matching digest confirms file equality with the prepared manifest; it does not establish truth, safety, independent validation, or trusted custody.
