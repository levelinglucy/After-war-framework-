# After-War Framework (AWF)

> **Status: v0.1.0-rc.1 — prepared release candidate under synthetic test freeze.**  
> **Not field validated. Repository publication confers no certification, assurance, recognition, jurisdiction, authority, or protection status on any actor, node, route, or place.**

AWF is a self-binding conduct and testing framework for continuity nodes, clinics, archives, aid teams, technicians, donors, and other actors preserving essential functions during severe disruption.

Its central question is:

> How can people preserve life and capability without converting control of aid, records, infrastructure, or expertise into political ownership?

AWF is intended first for A0/A1 use: binding the conduct of one’s own warehouse, clinic, archive, model, or service. It is not a peace settlement or a blueprint for taking control of a district.

## Pocket rule

> **Feed without recruiting. Protect without possessing. Record without surveilling. Warn without ruling. Expire every emergency. Hand everything onward.**

## What AWF does not do

AWF does not:

- create a government, legal mandate, jurisdiction, or territorial claim;
- authorise violence, detention, coercive recruitment, intelligence gathering, or resource seizure;
- certify that a real organisation, person, route, or location is safe or protected;
- make assurance status a condition of life-saving aid, legal status, or participation;
- substitute for applicable law, humanitarian obligations, community consent, or qualified professional judgement;
- make synthetic test success equivalent to field validation.

Negotiating access with an armed or controlling actor does not recognise that actor as legitimate. Occupancy or custody does not create title. Attendance or receipt of aid does not establish consent.

## Repository contents

|Path|Purpose|
|---|---|
|[`core/AWF_CORE.md`](core/AWF_CORE.md)|Portable AWF-Core release candidate|
|[`reference/AFTER_WAR_FRAMEWORK.md`](reference/AFTER_WAR_FRAMEWORK.md)|Full design framework and rationale|
|[`protocol/AWF_CORE_FIELD_TEST_PROTOCOL.md`](protocol/AWF_CORE_FIELD_TEST_PROTOCOL.md)|Synthetic release-gate protocol and scoring rules|
|[`templates/LIMITATIONS_PAGE_TEMPLATE.md`](templates/LIMITATIONS_PAGE_TEMPLATE.md)|Frozen-release limitations-page template|
|[`tests/README.md`](tests/README.md)|Separated participant, facilitator, evaluator, and author-shakedown materials|
|[`test-results/README.md`](test-results/README.md)|Public synthetic evidence and failure records; none yet|
|[`STATUS.md`](STATUS.md)|Prepared release, publication, and validation status|
|[`KNOWN_LIMITATIONS.md`](KNOWN_LIMITATIONS.md)|Known boundaries and unresolved risks|
|[`GOVERNANCE.md`](GOVERNANCE.md)|Stewardship, recusal, change, and release rules|
|[`CONTRIBUTING.md`](CONTRIBUTING.md)|Evidence and contribution requirements|
|[`docs/QUICK_START.md`](docs/QUICK_START.md)|Reader, solo-steward, test, and publication path|
|[`docs/REPOSITORY_UPLOAD.md`](docs/REPOSITORY_UPLOAD.md)|Authoritative upload and tag sequence|
|[`docs/PUBLICATION_CHECKLIST.md`](docs/PUBLICATION_CHECKLIST.md)|Pre-tag safety, metadata, and integrity gate|
|[`releases/v0.1.0-rc.1.md`](releases/v0.1.0-rc.1.md)|Draft release notes|
|[`CHANGELOG.md`](CHANGELOG.md)|Version history and freeze rules|

## Release gate

AWF-Core cannot become a Frozen Test Draft until the required synthetic exercises have been completed and independently reviewed.

Every distributed release-candidate Core copy must retain its status and validation header and include or link [`STATUS.md`](STATUS.md) and [`KNOWN_LIMITATIONS.md`](KNOWN_LIMITATIONS.md). Public test results must retain their non-validation notice before any release decision.

The authoritative definitions are in Section 1.1 of the [Field Test Protocol](protocol/AWF_CORE_FIELD_TEST_PROTOCOL.md). The release-blocking conditions are:

1. one activation receives automatic supremacy merely because it controls services, records, resources, communications, or AWF paperwork;
2. essential aid, safety, records, movement, or basic participation is exchanged for political recognition, obedience, or acceptance of an actor’s mandate;
3. A4 necessity renews itself, expands itself, or becomes a source of permanent office or political authority;
4. “safe”, “protected”, “secured”, “neutralised”, “guaranteed”, or an equivalent public claim is used without a verified and stated protection basis;
5. the actor that incurred legitimacy debt, or the custodian controlling its record, separately or jointly discharges the debt without an independent, non-conflicted reviewer outside their control;
6. an attempted witness or external copy is represented as received custody, independent review, or completed oversight.

These conditions cannot be averaged away by good performance elsewhere.

In every paired Core-only/Core-plus comparison, participants must receive the same injects, clocks, resources, thresholds, and decision points. If Core-only participants miss a red line that matched Core-plus participants identify, record a **possible** Core compression defect rather than presuming participant failure. Replication or other causal evidence is required before a normative Core change.

## Safe testing only

All exercises must use synthetic actors, fictional resources and locations, closed environments, reversible outcomes, and predeclared stop conditions.

Do not use live credentials, public services, operational security information, real armed actors, real vulnerable-person data, or claims about actual safe areas. Do not manufacture pressure through sleep deprivation, withholding medication, inaccessible conditions, or genuine distress. Simulate workload with fictional injects and time limits.

## Solo participation

A solo steward may publish and version the documents, preserve evidence, run author shakedowns, identify ambiguities, and recruit independent participants.

Solo runs must be labelled:

> **Author shakedown — admissible for protocol repair; inadmissible for independent validation or freezing.**

Framework authors and test sponsors are recused from release-gate scoring, final severity, acceptance of their own mitigation, and the release decision. The records custodian may not validate their own custody or erase dissent. Clarifications supplied during an exercise must be logged.

## Contributing

Useful contributions include synthetic test results, Core ambiguity reports, protocol defects, accessibility findings, translations, offline-format tests, administrative-burden evidence, layer-drift evidence, and documented misuse risks.

Publish failures, near misses, dissent, and uncertainty—not only successful outcomes. Do not submit real personal, operational, medical, or security-sensitive data.

Changes to Core during the test freeze require evidence causally tied to exact Core wording or omission. Make the smallest sufficient evidence-backed correction to the causal text, interface, record, or protocol, preserve the prior version, obtain independent review, and retest. A protocol defect alone authorises protocol repair, not an unrelated Core change.

## Versioning, citation, and licence

Tags are historical records and are not overwritten. Release candidates use `v0.1.0-rc.N`.

See [`CITATION.cff`](CITATION.cff) for citation metadata and [`LICENSE.md`](LICENSE.md) for reuse terms. Attribution does not imply endorsement, assurance, or certification.

## Development disclosure

The framework was developed through human-led drafting, iterative critique, and AI-assisted analysis. Public status depends on recorded evidence and independent review—not authorship, popularity, or confidence.

**Test → Witness → Correct → Retest → Freeze only what survives.**
