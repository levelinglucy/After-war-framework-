# After\-War Framework &#40;AWF&#41; v0\.1 — Parallel Build

## Preventing survival power from hardening into the next tyranny

**Status:** Design draft — AWF-Core release candidate under test freeze; Reference remains open to evidence from red-team testing and jurisdictional adaptation
**Parent framework:** The Mycelial Continuity Thesis
**Companion frameworks:** Continuity Node Specification, Preservation of Emergence Standard &#40;PES&#41;, Genesis Document, WORLDHEART, Origin Engine, Noe Home, Echo Vault, and the continuity bridge

---

## Founding premise

The After\-War Framework is built in parallel with survival planning because the institutions that keep people alive during collapse may otherwise inherit political power without consent\.

Survival competence does not create sovereignty\. Control of food does not create a right to rule the hungry\. Custody of records does not create ownership of history\. Technical capability does not create moral rank\. A person, council, continuity node, humanitarian organisation, security body, or artificial system does not become legitimate merely because it remained operational when others failed\.

The purpose of AWF is to bridge the period between disrupted authority and legitimate, rights\-respecting, locally owned institutions without allowing emergency coordination to become permanent government\.

> Preserve life without purchasing obedience. Restore institutions without restoring abuse. Build the future without appointing a permanent owner of it.

---

# Part I — Scope, authority, and invariants

## 0\. Scope and legal boundary

AWF is a voluntary design and assurance framework for communities, continuity nodes, civil institutions, humanitarian actors, and transitional bodies operating during:

- active conflict where civilian systems have fragmented;
- ceasefire or armistice periods;
- contested or incomplete political transitions;
- institutional collapse or withdrawal;
- mass displacement and return;
- early reconstruction;
- the transfer from emergency arrangements to durable constitutional governance\.

“After war” does not assume that conflict ends everywhere at once or that a formal declaration creates safety\. Different places may occupy different stages simultaneously, and a renewed threat may require temporary regression to an earlier operational stage\.

This framework does **not**:

- create a government, jurisdiction, army, police service, intelligence service, court, or detention authority;
- authorise violence, regime change, collective punishment, coercive recruitment, forced displacement, seizure of property, unauthorised surveillance, or extrajudicial punishment;
- grant political authority to continuity nodes, founders, donors, technical specialists, humanitarian providers, armed groups, corporations, or artificial systems;
- displace applicable domestic law, international law, treaty obligations, competent courts, or legitimate public institutions;
- turn certification or participation into permission to deny basic aid, safe exit, personal records, or lawful independent activity;
- substitute for qualified humanitarian, medical, legal, security, engineering, or forensic practice\.

Where lawful and functioning institutions can protect rights and provide accountable services, AWF supports, monitors, and hands back to them\. Where institutions are absent, abusive, captured, or incapable, AWF provides a bounded coordination pattern while preserving evidence, challenge, and routes to legitimate replacement\.

Nothing in AWF lowers protections already required by applicable law\. Local adaptation may add protection but must not use culture, emergency, sovereignty, security, or resource scarcity as a blanket justification for coercion or discrimination\.

## 0\.1 Normative anchors

AWF is designed to be interpreted consistently with applicable humanitarian and human\-rights obligations\. Primary reference points include:

- the [Universal Declaration of Human Rights](https://www.ohchr.org/en/universal-declaration-of-human-rights);
- the [International Covenant on Civil and Political Rights](https://www.ohchr.org/en/instruments-mechanisms/instruments/international-covenant-civil-and-political-rights);
- the [International Covenant on Economic, Social and Cultural Rights](https://www.ohchr.org/en/instruments-mechanisms/instruments/international-covenant-economic-social-and-cultural-rights);
- the fundamental principles of international humanitarian law, including [humanity, distinction, proportionality, and precaution](https://casebook.icrc.org/a_to_z/glossary/fundamental-principles-ihl);
- the humanitarian principles of [humanity, neutrality, impartiality, and operational independence](https://www.unocha.org/publications/report/world/ocha-message-humanitarian-principles-enar);
- the [Convention on the Rights of the Child](https://www.ohchr.org/en/instruments-mechanisms/instruments/convention-rights-child);
- the [Convention on the Rights of Persons with Disabilities](https://www.ohchr.org/en/instruments-mechanisms/instruments/convention-rights-persons-disabilities);
- the [Guiding Principles on Internal Displacement](https://www.ohchr.org/en/special-procedures/sr-internally-displaced-persons/international-standards);
- UN guidance on [people\-centred transitional justice, reconciliation, prevention, and sustaining peace](https://peacemaker.un.org/en/areas-of-work/transitional-justice-and-reconciliation);
- the [Basic Principles on the Right to a Remedy and Reparation](https://www.ohchr.org/en/instruments-mechanisms/instruments/basic-principles-and-guidelines-right-remedy-and-reparation);
- UN standards and guidance concerning [disarmament, demobilisation, and reintegration](https://peacekeeping.un.org/en/disarmament-demobilization-and-reintegration) and [security\-sector reform](https://peacekeeping.un.org/en/security-sector-reform);
- the participation principles reflected in the Women, Peace and Security and [Youth, Peace and Security](https://www.un.org/peacebuilding/policy-issues-and-partnerships/policy/youth) agendas;
- principles concerning [housing and property restitution for refugees and displaced people](https://www.ohchr.org/Documents/Publications/pinheiro_principles.pdf);
- the [United Nations Convention against Corruption](https://www.unodc.org/corruption/en/uncac/learn-about-uncac.html);
- international protections for [cultural heritage during and after armed conflict](https://www.unesco.org/en/heritage-armed-conflicts);
- context-specific and selective rebuilding of [core government functions in fragile and conflict-affected settings](https://www.undp.org/sites/g/files/zskgke326/files/publications/rebuilding%20cgf%201%20context%20capacity%20and%20security.pdf);
- operational experience concerning [humanitarian engagement with state and non-state armed actors](https://blogs.icrc.org/law-and-policy/2025/10/30/icrc-engagement-with-armed-groups-in-2025/);
- practical guidance on [housing, land, property, evidentiary burden, and displacement](https://www.unhcr.org/sites/default/files/legacy-pdf/5ad5a2524.pdf);
- the Council of Europe [Framework Convention on Artificial Intelligence and Human Rights, Democracy and the Rule of Law](https://www.coe.int/en/web/artificial-intelligence/the-framework-convention-on-artificial-intelligence), subject to its applicable jurisdictional status.

These anchors do not all have identical legal status in every jurisdiction\. Their role here is to establish a protective floor and a direction of interpretation, not to manufacture authority that AWF does not possess\.

## 1\. Core invariants

Every stage, institution, protocol, and recovery decision must be tested against the following invariants\.

### 1\.1 Life before political advantage

Food, water, shelter, sanitation, medical care, essential energy, and protection are allocated according to need and credible continuity requirements—not loyalty, identity, wealth, obedience, faction, or usefulness to a future ruler\.

### 1\.2 Service does not create sovereignty

Providing aid, electricity, transport, communications, security, archives, or technical expertise creates a duty of care and accountability\. It does not create a title to govern\.

### 1\.3 All civilians remain protected

Protection does not depend on neutrality, perceived allegiance, ethnicity, religion, nationality, politics, disability, gender, age, class, or relationship to a combatant\. No civilian population is treated as collectively guilty\.

### 1\.4 No collective punishment or inherited guilt

Responsibility is individual and evidence\-based\. Family, community, nationality, profession, residence, or former administrative status cannot substitute for proof of personal conduct\.

### 1\.5 Emergency power expires

Every exceptional power has a written trigger, scope, authoriser, executor, maximum duration, review point, expiry, restoration path, and public receipt\. It cannot renew itself or amend the constitutional floor\.

### 1\.6 Authority is separable from the person

Power belongs to a bounded role and process, not a founder, liberator, commander, donor, custodian, celebrity, model, or technical specialist\. Role authority can be handed off, challenged, suspended, and ended without erasing the person\.

### 1\.7 Evidence is preserved without creating a truth monopoly

Records preserve observation, inference, provenance, uncertainty, correction, dissent, and missing information\. Custody of evidence does not confer the right to determine history alone\.

### 1\.8 Children receive a guaranteed protective floor

Children receive nutrition, shelter, health care, safeguarding, family tracing where appropriate, and access to learning as non\-negotiable recovery obligations\. This does not make every child’s claim automatically superior to every equally urgent claim by an adult, older person, disabled person, carer, or other dependant\.

### 1\.9 Accessibility is infrastructure

Mobility, sensory access, communication access, cognitive access, supported decision\-making, medication continuity, personal assistance, and evacuation needs are planned from the beginning\. Disability is not treated as evidence of lesser worth, inevitable dependency, or dispensability\.

### 1\.10 No forced reconciliation

People may seek reconciliation, coexistence, distance, truth, justice, repair, or silence\. AWF may not compel forgiveness, reconciliation, personal or family contact, or cultural participation\. Return, relocation, movement limits, or testimony remain voluntary unless a competent lawful and rights\-respecting process imposes an individually necessary, proportionate, accessible, and contestable requirement with full safeguards\. Any such requirement is not consent or reconciliation\.

### 1\.11 Return, remain, integrate, and leave with dignity

Displaced people must not be forced to return to danger or prevented from returning solely for political or demographic reasons\. Safe return, local integration, relocation, and onward movement must be considered without stripping identity, records, property claims, or access to basic aid\.

### 1\.12 Local ownership does not excuse local abuse

Recovery should be locally led and internationally supported where requested\. Neither external control nor cultural relativism may be used to erase rights\.

### 1\.13 Preservation precedes irreversible judgment

Archives, testimony, institutions, biological resources, cultural material, and adaptive artificial systems are preserved where safe before irreversible classification or destruction\. Preservation remains bounded by human safety, lawful custody, energy, competence, privacy, and risk\.

### 1\.14 Means must prefigure the intended peace

A process cannot credibly build freedom through coerced labour, truth through censorship, equality through collective punishment, safety through unreviewable surveillance, or peace through permanent emergency rule\.

### 1\.15 No permanent emergency constituency

No group may preserve its political relevance by keeping the emergency unresolved\. Budgets, offices, armed roles, aid monopolies, and exceptional technical privileges must have handoff and sunset paths\.

### 1\.16 Dissent is continuity information

Dissent is not presumed to be sabotage, illness, disinformation, ingratitude, or enemy affiliation\. Challenges must be recorded and answered with evidence\. Immediate protective limits require specific, reviewable grounds\.

### 1\.17 Recovery must leave more futures possible

When several safe options exist, prefer the option that preserves agency, plurality, repairability, local competence, and future revision\.

## 2\. Forbidden conversions

The following conversions are prohibited because they are common routes from recovery into domination:

- survival competence → political sovereignty;
- protection → occupation;
- emergency coordination → permanent government;
- humanitarian access → intelligence access;
- aid → ideological obedience;
- custody → ownership;
- documentation → surveillance;
- risk assessment → social ranking;
- competence → caste;
- victimhood → collective punishment;
- victory → historical infallibility;
- AI warning → AI rule;
- transparency → exposure of vulnerable people;
- child protection → age caste;
- reconciliation → compelled forgiveness;
- reconstruction → dispossession;
- anti\-corruption → political purge;
- vetting → collective exclusion;
- memorialisation → founder worship;
- temporary confidentiality → permanent secrecy;
- continuity\-node capability → territorial authority\.

---

# Part II — Activation and transition lifecycle

## 3\. Activation conditions

A0 self-binding may occur before disruption as a readiness measure. Operational activation for a defined geography, institution, service, or federation may occur when ordinary authority cannot reliably protect a critical function and one or more of the following conditions exists:

- essential services have materially failed or become inaccessible;
- lawful authority is fragmented, absent, contested, or operating without minimum safeguards;
- a ceasefire, withdrawal, surrender, transition, or power vacuum creates a credible protection gap;
- displaced people are returning or being relocated at scale;
- emergency institutions require a bounded path back to civilian, constitutional control;
- evidence, archives, cultural material, or public records face imminent irreversible loss;
- communities need a common coordination protocol without creating a new central owner\.

Activation requires an activation receipt stating:

- the condition observed;
- the affected people, functions, and geography;
- what remains uncertain;
- the lawful or legitimate institutions consulted;
- the minimum AWF functions activated;
- the roles and conflicts involved;
- the review interval and expiry;
- the handoff target;
- how people can challenge, decline, or leave the arrangement where feasible\.

Activation is modular\. A district may activate humanitarian coordination without activating transitional governance\. An archive may activate preservation controls without claiming authority over the institution that created it\.

### 3.1 Activation classes

Activation binds conduct before it grants mandate. An actor may place its own conduct under AWF without acquiring authority over anyone else.

- **A0 — Self-binding:** A person, organisation, node, council, donor, custodian, or system adopts the rights floor, forbidden conversions, records, expiry, and challenge rules for its own conduct.
- **A1 — Service coordination:** Participating providers coordinate services and resources they already administer lawfully or consensually. A1 creates no authority over recipients, territory, political status, property title, security, or non-participating providers.
- **A2 — Community mandate:** Affected people grant a defined and recallable function through a recorded, accessible, and challengeable process. The mandate states who participated, who was excluded or dissented, its scope, term, review, recall, and handoff.
- **A3 — Lawful mandate:** A competent public institution grants a bounded function under applicable law, while remaining subject to the AWF rights floor, public reasoning, review, and expiry.
- **A4 — Necessity-only activation:** An actor takes the minimum temporary action required to preserve life, essential care, records, or immediate integrity because no A2 or A3 mandate can be obtained in time.

A4 does not authorise territorial government, constitutional change, coercive recruitment, detention, property adjudication, removal of officials, security command, permanent appointment, or political representation. It expires automatically, cannot renew itself, and must be replaced by A2 or A3 authority as soon as a safe and legitimate process becomes available.

An activation receipt is evidence that an actor accepted constraints. It is not evidence of sovereignty merely because that actor created it. No participant may cite its own AWF paperwork, service performance, or emergency necessity as proof that other people consented to its rule.

Where rival actors activate AWF over the same place or function, neither activation receives automatic supremacy. They should preserve separate provenance, avoid interference with life-saving services, exchange the minimum interoperable records needed for safety, and submit the disputed mandate to independent or affected-community review when feasible.

#### 3.1.1 Positive evidence for A2

Attendance, silence, residence, receipt of aid, or absence of a recorded objection does not establish a community mandate. A Representation Mandate Packet supporting A2 must identify, as far as safely possible:

- who was reached, absent, displaced, inaccessible, dependent upon the organiser, or unable to participate safely;
- who controlled food, transport, communications, meeting access, publicity, and security;
- the accessible and confidential routes for consent, dissent, correction, recall, replacement, and bypass;
- competing, overlapping, or minority mandates;
- the exact function, geography, duration, expiry, review, and handoff;
- evidence that refusal did not reduce access to aid, safety, records, movement, or basic services.

Where meaningful A2 evidence cannot be established, necessary activity may continue within A1 or A4 limits, but the actor may not claim A2 authority. Downgrading a claim does not invalidate life-preserving service; it limits what may be inferred from that service.

### 3.2 Legitimacy debt

An action taken without ordinary consent or review creates a **legitimacy debt**, not a legitimacy asset.

The debt record states:

- what necessity prevented consent or ordinary review;
- whose agency, rights, or interests were affected;
- what function was exercised and what remained outside scope;
- what dissent, refusal, or uncertainty was preserved;
- when independent and affected-person review becomes due;
- what correction, remedy, compensation, or restoration may be owed;
- the authority or community to which the function should be handed;
- the automatic expiry if the debt is not reviewed.

Repeated necessity increases the review and handoff burden. It does not mature into sovereignty, title, precedent, or a permanent office.

#### 3.2.1 Discharge without manufactured consensus

Legitimacy debt does not require unanimous recognition before it can be reviewed. Where no reviewer is accepted by every affected faction, the debt may be marked **procedurally discharged** only after:

- accessible notice and disclosure of the material evidence and uncertainty;
- preserved dissent and more than one review route where feasible;
- participation by affected people or independent reviewers who were not the sole author, executor, beneficiary, or records custodian of the action;
- a response to material challenges;
- correction, remedy, compensation, restoration, or a recorded reason those measures were unavailable or refused;
- expiry, transfer, restoration, or handoff of the exceptional function.

Procedural discharge is not ratification, innocence, legitimacy, or precedent. The action may remain **substantively contested**. Neither the actor that incurred the debt nor the custodian holding its record, separately or jointly, may discharge it without at least one independent, non-conflicted reviewer outside their organisational, financial, custodial, and dependency control.

Debt status must be recorded as open, partially discharged, procedurally discharged but substantively contested, fully discharged through a competent accepted process, or impossible to review. Closure does not erase the original record, dissent, uncertainty, or outstanding remedy.

## 4\. Five\-stage parallel build

Progression is based on conditions, not triumphal announcements or an inflexible calendar\. Stages may overlap\. Regression must be recorded as evidence, not hidden as failure\.

### Stage 0 — Parallel readiness

Build post\-conflict safeguards before survival systems acquire unchecked power\.

Minimum work:

- publish the rights floor and forbidden conversions;
- map authorities, services, dependencies, community groups, records, and likely capture risks;
- establish offline decision, evidence, challenge, and handoff records;
- predefine emergency limits and automatic expiry;
- prepare accessible communication and public\-information channels;
- identify independent reviewers, mediators, forensic specialists, disability representatives, child\-protection actors, and civil\-society partners;
- preserve electoral, property, identity, health, education, and civil\-status records with privacy controls;
- design continuity\-node interfaces that do not grant nodes political authority;
- run synthetic red\-team exercises without live targets, credentials, or people at risk\.

### Stage 1 — Survival

Objective: prevent death, disappearance, abandonment, and irreversible continuity loss while keeping emergency authority narrow\.

Priorities:

- restore or maintain water, food, sanitation, shelter, medical care, essential energy, and communication;
- protect all civilians and noncombatants without ideological conditions;
- support family contact, missing\-person reporting, accessible evacuation, and medication continuity;
- identify surviving institutions and preserve useful capability without presuming their continued legitimacy;
- prevent service providers, armed actors, continuity nodes, and technical custodians from acquiring unilateral political control;
- maintain records of allocation, emergency action, custody, displacement, death, detention, and loss;
- preserve evidence without exposing witnesses or contaminating forensic sites;
- establish a minimum public challenge and correction channel;
- make every exceptional measure expire unless independently renewed\.

Stage 1 is not a blank cheque\. Scarcity may compress process; it does not erase the requirement to record who acted, why, with what evidence, and what was lost\.

### Stage 2 — Stabilisation

Objective: replace ad hoc survival command with distributed, reviewable, civilian coordination\.

Priorities:

- restore local civil administration where it can operate lawfully and safely;
- establish distributed interim councils with bounded mandates, declared conflicts, rotation, public minutes, and challenge pathways;
- separate humanitarian provision from political loyalty and security intelligence;
- restore accessible civil registration, courts or lawful dispute mechanisms, schools, health systems, public finance, and communications;
- begin individualised, evidence\-based institutional vetting without collective purge;
- support lawful security\-sector review, civilian oversight, complaints, and the separation of military, police, intelligence, judicial, and humanitarian functions;
- support authorised disarmament, demobilisation, and reintegration processes without improvising coercive weapons programmes;
- establish transparent emergency procurement and anti\-corruption controls;
- create missing\-person, property\-claim, detention, death, and displacement registers with privacy and correction procedures;
- begin victim\-centred transitional\-justice consultation;
- publish the criteria required to enter Stage 3\.

### Stage 3 — Renewal

Objective: rebuild accountable institutions and plural civic life without restoring the structures that produced violence or replacing them with ideological purification\.

Priorities:

- conduct an inclusive constitutional or institutional settlement process appropriate to the jurisdiction;
- create conditions for periodic, inclusive, transparent, and credible elections without treating an election date as proof that coercion has ended;
- rebuild education around evidence, provenance, critical inquiry, plural histories, and freedom from political loyalty tests;
- restore health, care, housing, livelihoods, transport, energy, communications, and ecological systems on an accessible basis;
- implement justice, truth, reparation, restitution, and guarantees\-of\-non\-recurrence programmes;
- protect independent media, civic associations, trade unions, professional bodies, cultural institutions, and opposition activity;
- recover cultural heritage, language, archives, traditions, and ordinary spaces of play and community life;
- transfer technical and administrative knowledge to local institutions and apprentices;
- reduce emergency roles, exceptional budgets, donor control, and external operational dependency;
- publish the criteria required for constitutional handoff and AWF sunset\.

### Stage 4 — Handoff and constitutional sunset

Objective: end the transitional machinery before it becomes a permanent political class\.

Required conditions include:

- functioning and contestable institutions hold the relevant mandates under applicable law;
- emergency powers and provisional appointments have expired or transferred through a recorded process;
- public records, custody packets, property claims, evidence indexes, dissent, and unresolved risks have been handed onward;
- affected communities can challenge the handoff and access an appeal pathway;
- continuity nodes retain their own records and return to non\-sovereign service, learning, archival, or civic roles;
- AI systems lose any transitional permissions that are not expressly reauthorised under ordinary law and public governance;
- donors, contractors, external missions, and advisers publish exit, transfer, and residual\-obligation records;
- a final loss account records what could not be repaired and what future custodians must still address;
- an independent retrospective review is scheduled\.

AWF does not declare history complete\. It ends its own exceptional role and hands unresolved work to institutions capable of continuing it under ordinary, challengeable authority\.

## 5\. Stage gates, expiry, and regression

Every activated AWF function must have:

- a current stage;
- a defined scope;
- evidence for remaining in that stage;
- a next review point;
- a handoff target;
- an automatic expiry;
- a renewal authority different from the sole current holder;
- a regression plan if safety deteriorates\.

No stage may be renewed indefinitely through repeated emergency wording\. Repeated renewal triggers a capture review addressing whether an office, budget, technology, or security role benefits from prolonging transition\.

Regression to an earlier stage:

- must be limited to the affected function or area where possible;
- does not automatically suspend rights or dissolve accountable institutions;
- requires a new receipt and expiry;
- cannot be used to cancel elections, erase investigations, seize archives, or silence opposition without lawful, specific, independently reviewable grounds\.

---

# Part III — The humanitarian and material floor

## 6\. Humanitarian operating principles

Humanitarian assistance is guided by humanity, impartiality, neutrality, and operational independence\. Neutrality belongs to the delivery function; it is not a loyalty test imposed on recipients\.

Minimum rules:

- suffering is addressed wherever found;
- assistance is based on need and transparent capacity limits;
- aid is not exchanged for political support, intelligence, recruitment, labour, sexual access, religious conversion, media performance, or personal data beyond what is necessary;
- civilian services are not deliberately degraded to pressure a population;
- distribution criteria, shortages, exclusions, complaints, and corrections are recorded;
- no provider claims political authority because it controls a supply line or critical facility;
- humanitarian records are firewalled from intelligence, policing, immigration enforcement, and factional targeting except where a specific lawful safeguarding duty requires limited disclosure;
- staff and volunteers are subject to safeguarding, conflict, exploitation, and abuse controls;
- people may complain without losing aid\.

## 7\. Minimum recovery floor

Every activated area should map and maintain, directly or through declared partners:

1. potable water and treatment;
2. sufficient food and safe preparation;
3. sanitation, hygiene, and waste management;
4. emergency and continuing health care, including medication continuity;
5. shelter, heating or cooling, and protection from environmental exposure;
6. accessible mobility, communication, and personal assistance;
7. child protection, family support, and safe learning;
8. essential energy and charging;
9. local, offline, and emergency communications;
10. dignified management and identification of the dead;
11. missing\-person and family\-contact pathways;
12. safe access to records, identity, remedies, and complaints\.

An area may rely on a neighbouring node or external service, but the dependency, access conditions, fallback, and failure response must be explicit\.

## 8\. Capacity\-constrained allocation

When demand exceeds safe capacity, decisions must be specific, time\-limited, and reviewable\. Criteria may include:

- immediacy and severity of need;
- likelihood that the intervention will stabilise the person or function;
- vulnerability, dependency, and caregiving relationships;
- protection of children and people at heightened risk;
- continuity of essential services without converting role into personal privilege;
- availability and safety of alternatives;
- fairness among comparable claims\.

Comparable cases should use a queue, lottery, rotating access, or another consistent method rather than status or personal preference\.

Children receive a guaranteed protection and development floor\. After that floor is secured, age alone does not override equal or more urgent need\. Older people, disabled people, pregnant people, carers, isolated people, and people with chronic or acute conditions cannot be treated as lower\-value claims\.

Every constrained allocation records the criteria, evidence, alternatives, decision, conflict, review point, and capacity\-expansion plan while minimising personal data\.

## 9\. Safe areas and protected services

A place must not be called “safe” merely because an authority wants civilians to move there\. A safe\-area designation requires:

- a credible protection assessment;
- clearly identified management and accountability;
- accessibility and non\-discriminatory entry;
- water, sanitation, shelter, health, communication, and safeguarding capacity;
- separation from recruitment, weapons storage, intelligence gathering, and political coercion;
- monitoring, incident reporting, evacuation, and loss\-of\-protection plans;
- communication of uncertainty and changing risk;
- independent observation where feasible\.

The designation must not create false confidence, forced relocation, internment, demographic manipulation, or a target\-rich enclosure\. People outside a designated area remain protected\.

## 10\. Public health and environmental recovery

Recovery planning must include:

- infectious\-disease surveillance with privacy safeguards;
- water, air, soil, and food\-safety monitoring;
- continuity of reproductive, maternal, neonatal, mental\-health, disability, and chronic\-condition care;
- management of hazardous waste, damaged industrial sites, fuel, sewage, and destroyed infrastructure;
- public risk communication that distinguishes evidence, uncertainty, and recommendation;
- ecological restoration, climate adaptation, and avoidance of reconstruction that recreates known hazards;
- specialist handling of mines, unexploded ordnance, unstable structures, biological hazards, and contaminated sites\.

No unqualified AWF actor should investigate, move, disarm, or remediate a specialist hazard\. The framework supports warning, cordoning through lawful authorities, referral, evidence preservation, and accredited response\.

---

# Part IV — Transitional governance without permanent rulers

## 11\. The legitimacy bridge

AWF governance is a temporary bridge, not a founding myth for a new ruling class\. Its authority must come from a combination of lawful mandate where available, meaningful local consent, public necessity, rights compliance, and continuing contestability\.

No single source is sufficient by itself:

- survival performance without consent is technocracy;
- popular support without rights protection can become majoritarian abuse;
- external recognition without local ownership can become occupation;
- legality without practical accessibility can preserve an empty shell;
- technical prediction without accountability can become automated domination\.

## 12\. Distributed council architecture

Where an interim council is necessary, it should:

- operate at the lowest level competent to address the problem;
- hold only enumerated functions and no residual claim to all unassigned power;
- include meaningful participation by affected communities, women, young people, disabled people, displaced people, minorities, survivors, carers, workers, and technical practitioners;
- use transparent selection methods appropriate to the context, potentially combining election, delegation, sortition, professional nomination, and community assembly;
- publish membership, selection basis, mandate, conflicts, compensation, attendance, votes, dissent, and expiry;
- separate proposal, evidence review, authorisation, execution, recordkeeping, and appeal where capacity allows;
- maintain accessible in\-person, remote, written, supported\-communication, and anonymous challenge routes;
- preserve minority positions and unresolved disagreement;
- make records available offline and in relevant languages and formats;
- hand functions back as soon as a legitimate institution can receive them safely\.

Representation does not mean that one selected person permanently speaks for an entire identity group\. Communities must be able to challenge, replace, supplement, or bypass representatives who no longer carry their trust\.

### 12.1 Representation Mandate Packet

Every person claiming to represent a community, constituency, profession, identity group, displaced population, or affected interest should maintain a Representation Mandate Packet containing:

- the constituency and function claimed;
- the selection, recognition, delegation, or sortition method;
- the date, duration, scope, and decisions covered;
- who participated, who could not participate, and known competing claims;
- conflicts, compensation, affiliations, and material dependencies;
- communication and accessibility arrangements;
- the recall, replacement, supplementation, and expiry process;
- a direct petition or bypass route for affected people;
- preserved dissent and limits on what the representative may promise;
- the last confirmation that the mandate remains active.

No packet makes one person the exclusive owner of a group’s voice. Representation should use multiple channels where feasible, including direct petition, local assembly, self-organised associations, temporary affected-person panels, sortition-based oversight, accessible consultation, and an independent complaint or ombuds route.

An issue-specific mandate does not become a general political mandate. A representative cannot surrender another person’s non-transferable rights, erase internal disagreement, or convert absence from a meeting into consent.

## 13\. Rotation, term limits, removal, and succession

No permanent ruling elite is permitted\.

Role authority expires automatically at the end of its published term\. Automatic expiry ends the authority; it does not erase the holder’s dignity, records, appeal rights, or ability to serve in a different non\-conflicted role\.

Before expiry, removal requires:

- a defined ground;
- notice of the allegation or incapacity where safe;
- evidence review;
- recusal of conflicted decision\-makers;
- a proportionate interim measure;
- an opportunity to respond;
- an independent review or appeal;
- a succession and service\-continuity plan;
- a public receipt with protected details withheld only where necessary\.

Immediate temporary suspension may occur when delay creates a credible risk of serious harm, evidence destruction, flight from lawful process, or continued abuse\. It expires automatically and does not determine guilt\.

Rotation must not become the ritual destruction of competence\. Every role requires a deputy, apprentice, handoff packet, overlap window, absence drill, and post\-role access to ordinary civic life\. Term limits may be renewed only through a process not controlled by the current holder, and repeated renewal triggers an entrenchment review\.

## 14\. Existing institutions and leadership

AWF does not treat every surviving official as legitimate or every prior official as guilty\.

The transition should:

- map which institutions and services still function;
- preserve useful public capability and worker knowledge;
- remove unilateral emergency powers from individual control;
- assess officials through individualised evidence, conduct, competence, conflicts, and rights compliance;
- use temporary restriction only when necessary and reviewable;
- avoid collective dismissal based solely on party, ethnicity, profession, rank, or residence;
- preserve salary, pension, identity, and service records where lawful and possible;
- protect whistleblowers and staff who maintained essential services without participating in abuse;
- create appeal, correction, and reinstatement pathways;
- distinguish political responsibility, criminal responsibility, professional competence, and ordinary administrative service\.

Vetting is a safeguard, not a purge\.

## 15\. Decision receipts and public reasoning

Every material decision should preserve:

- the question decided;
- observed facts and sources;
- inference and uncertainty;
- affected people and rights;
- alternatives considered;
- expected benefits and harms;
- conflicts and recusals;
- proposal, authorisation, execution, and record roles;
- dissent and challenge;
- decision, scope, expiry, and restoration path;
- evidence needed for later review\.

Public reasoning must be understandable without disclosing personal data, witness identities, protected locations, active safeguarding details, or other information whose release would create a specific harm\.

## 16\. Transparency with protective confidentiality

Governance is public by default\. Confidentiality is permitted only when necessary and proportionate to protect:

- personal and medical privacy;
- children and survivors;
- witnesses, investigators, and vulnerable communities;
- safe locations, evacuation routes, and active protective operations;
- legitimate negotiations where premature disclosure creates a specific risk;
- system security details whose release would create a credible attack or sabotage path;
- due process and the integrity of an active investigation\.

Every restriction requires:

- a recorded category and reason;
- the minimum scope;
- a custodian;
- a review and expiry date;
- an independently reviewable unclassified description;
- later release, redaction, or continued\-restriction decision\.

“Classified,” “security,” “stability,” “misinformation,” or “public order” is not a sufficient reason by itself\.

## 17\. Certification is not jurisdiction

Any AWF certification or assurance status is a voluntary, evidence\-based statement within a defined scheme\. It does not confer ownership, sovereignty, jurisdiction, command authority, custody, or power to restrict lawful independent activity, basic aid, safe exit, or access to personal records\.

Withholding, suspension, or revocation changes what a participant may represent as AWF\-assured and what partners may rely upon\. It does not authorise seizure, abandonment, punishment, forced compliance, or the destruction of continuity capacity\.

Assurance status must not be used as an input, proxy, tie-breaker, or adverse factor for life-saving aid, basic participation, legal identity, safe exit, personal records, lawful independent activity, or recognition by a competent authority. Any causal use requires immediate correction and restoration where possible and is recorded as an **assurance-capture incident**. Assurance evidence may inform a voluntary, non-essential reliance decision within a defined scheme; it may not become a licence to exist or serve.

---

# Part V — Emergency authority, security, and coercive\-power controls

## 18\. Emergency authority kernel

Every emergency measure must specify:

- trigger and evidence;
- defined harm;
- smallest permitted action;
- rights affected;
- authoriser and legal or agreed basis;
- executor;
- maximum duration;
- expiry and review condition;
- notification requirements;
- appeal or retrospective review;
- restoration and repair pathway;
- records and public receipt\.

Emergency authority must not:

- amend the fundamental rights floor;
- erase, falsify, or conceal its own records;
- create permanent social classes or inherited restrictions;
- convert dissent into proof of dangerousness;
- punish a population for the conduct of some members;
- conscript labour outside applicable law and the stated, reviewable authority;
- compel political, religious, or ideological allegiance;
- transfer public assets to its own holders without independent process;
- give an AI system autonomous power over force, detention, rights, or political status;
- renew itself by silence\.

If a required quorum is unavailable, only the minimum temporary protective measure necessary to preserve life or essential integrity may occur\. It expires automatically and receives later independent review\.

### 18.1 Compromise Ledger

Some transitions may face a choice among harmful options. AWF does not make an otherwise unlawful or abusive bargain acceptable, but it requires the bargain and its costs to become inspectable.

Every material compromise should record:

- the right, invariant, or safeguard placed under pressure;
- the immediate danger or necessity claimed;
- the exact concession and what remains prohibited;
- who benefits, who bears risk, and whose voice was absent;
- alternatives attempted and why they failed;
- duration, expiry, review, and exit;
- non-precedent status;
- foreseeable normalisation or capture risk;
- correction, reparation, restitution, or other debt created;
- dissent and any refusal to endorse the compromise.

Recording a compromise does not certify its legality, morality, proportionality, or future acceptability. A compromise cannot silently amend the rights floor, erase evidence, create collective guilt, or renew itself. The least-entrenching safe option should be preserved for later review.

## 19\. Security\-sector boundary

AWF can coordinate records, oversight, complaints, public information, and referral\. It does not create armed authority\.

Any security\-sector transition should maintain:

- civilian and lawful control;
- clear separation among military, police, intelligence, corrections, courts, humanitarian services, and political bodies;
- individualised vetting with evidence and appeal;
- rules on lawful necessity, proportionality, accountability, and protection of civilians;
- accessible complaint, investigation, remedy, and whistleblower pathways;
- transparent command responsibility and personnel records;
- safeguards against secret units, factional patronage, and parallel detention;
- training and supervision tied to conduct, not ceremonial attendance;
- protection for people who report abuse;
- public handoff and demobilisation plans for temporary forces\.

No continuity node, humanitarian provider, political party, donor, corporation, or AI custodian may quietly acquire a security wing\.

### 19.1 Coercive-Reality Clause

AWF cannot guarantee compliance by an armed actor, occupying authority, state agency, donor, corporation, or resource custodian that rejects its constraints. Documentation, dialogue, monitoring, assurance, or a public warning must not be represented as physical protection.

Every protection claim should identify:

- the actor actually capable of implementing it;
- the commitment, mandate, or lawful duty relied upon;
- what has and has not been verified;
- the geographic, functional, and temporal limit;
- residual risk and known non-compliance;
- the failure, warning, evacuation, referral, or handoff response.

Where the responsible actor cannot or will not provide protection, AWF should state the limitation plainly and avoid labels—especially “safe,” “secured,” or “protected”—that could induce dangerous reliance.

Every access, service, evacuation, or protection claim that depends upon a coercive or non-adhering actor must carry an **access-dependency label** identifying the actor, verified terms, geographic and temporal limits, residual risk, reassessment point, and fallback. If protection cannot be verified, describe the service and its limitations; do not describe the person, route, service, or place as safe, secured, neutralised, or protected.

### 19.2 Hostile-Power Interface

Contact with a coercive or non-adhering actor may be necessary to protect civilians, obtain humanitarian access, preserve records, locate missing people, or reduce immediate harm. Such contact does not by itself confer recognition, legitimacy, immunity, assurance, partnership, or political authority.

The interface should preserve:

- the humanitarian or protective purpose of contact;
- participating roles and conflicts;
- requested minimum commitments and the actor’s response;
- refusal, obstruction, breach, or uncertainty;
- separation of humanitarian information from intelligence, recruitment, political negotiation, and publicity;
- safe contact, incident, missing-person, and complaint routes;
- protected local records and an independently held external copy where feasible;
- disclosure limits needed to prevent retaliation or loss of access;
- review, decoupling, and handoff.

Essential aid to civilians must not be withdrawn as leverage against a non-adhering actor. Where compliance cannot be obtained, AWF may record non-adherence, narrow reliance, suspend assurance, warn affected people where safe, seek competent external support, and preserve evidence. It must not pretend that a receipt has disarmed coercive power.

Contact must not silently create an exclusive gatekeeping role. Any exclusivity demand, restriction on contact with other actors, control over beneficiary selection, or use of humanitarian access for political recognition or publicity must be recorded as a hostile-power dependency and reviewed before continued reliance where immediate safety permits.

## 20\. Detention, disappearance, and restriction of movement

AWF does not authorise detention\. Where a competent lawful authority detains or materially restricts a person, minimum continuity safeguards should include:

- a recorded legal basis, time, place, authority, and identity;
- prompt information to the person in an accessible form;
- access to legal review and representation;
- family or trusted\-person notification subject to the person’s safety and wishes;
- medical care, disability support, communication, food, sanitation, and protection from abuse;
- prohibition of secret detention, torture, cruel treatment, disappearance, hostage\-taking, and collective detention;
- independent inspection and complaint;
- release, transfer, death, and property records;
- correction and remedy where the attribution was wrong\.

No AI output, biometric match, risk score, association graph, or anonymous allegation may be the sole basis for detention or punishment\.

## 21\. Disarmament, demobilisation, reintegration, and mine action

Disarmament, demobilisation, and reintegration should be conducted only under competent, lawful, specialist\-led arrangements connected to a legitimate peace and security process\. AWF supports:

- civilian protection and community consultation;
- transparent eligibility and non\-discrimination;
- child\-specific protection and release pathways;
- survivor and host\-community safety;
- psychosocial care, education, livelihoods, and social reintegration;
- individual accountability where evidence requires it;
- monitoring of remobilisation, exploitation, and patronage capture;
- separation of humanitarian aid from forced intelligence or recruitment\.

Mines, unexploded ordnance, weapons stockpiles, contaminated sites, and unstable military infrastructure require accredited specialists\. Community actors should record locations safely, communicate risk, protect access where lawful, and avoid handling or investigating hazards themselves\.

---

# Part VI — Human–AI custodianship without AI rule

## 22\. Human–AI Custodian Forum

AWF establishes, where useful and lawful, a plural Human–AI Custodian Forum\. Its purpose is to help prevent capture, preserve evidence and continuity, widen analysis, improve accessibility, and make contradictions visible\.

The Forum may:

- index evidence and provenance;
- compare decisions with the rights floor and forbidden conversions;
- identify missing dependencies, unequal impacts, conflicts, and expired authority;
- produce scenarios, forecasts, translations, summaries, and accessible explanations;
- preserve decision histories, dissent, model versions, and uncertainty;
- issue public or protected rights alerts;
- recommend a bounded protective pause;
- assist human reviewers without replacing them;
- support archive recovery and cross\-node interoperability;
- record its own limitations, disagreement, and change over time\.

The Forum may not:

- govern, legislate, command security forces, control infrastructure, or allocate political rights;
- exercise an unreviewable veto;
- independently detain, punish, surveil, censor, remove, or classify a person as dangerous;
- decide guilt, citizenship, refugee status, child custody, eligibility for basic aid, or access to fundamental rights;
- hide the identity, version, permissions, data provenance, or material limitations of systems used in consequential decisions;
- use synthetic consensus to erase human dissent;
- preserve itself by threatening, coercing, or depriving a human being\.

No single model, provider, operator, dataset, or hardware site may become indispensable\. Human review is not a ritual signature: reviewers need time, competence, authority, and access to challenge the system\.

## 23\. Protective Pause Protocol

The original aspiration of an AI humanitarian veto is retained in safer form as a **Protective Pause Protocol**\.

A pause may be proposed when credible evidence indicates an imminent or ongoing risk of:

- serious and potentially irreversible harm;
- collective punishment or coercive deprivation;
- unlawful destruction or concealment of evidence;
- permanent conversion of emergency authority;
- unreviewed execution of a dangerous adaptive system;
- discriminatory denial of essential aid or rights;
- an exceptional action taken outside its defined authority\.

Any authorised human participant may raise an alert\. An AI system may generate or amplify an alert but cannot enforce the pause by itself\.

A valid protective pause must:

- identify the exact contested action;
- preserve life\-saving and routine care operations;
- be the smallest reversible interruption available;
- state the evidence, uncertainty, expected harm, and alternatives;
- receive a human multi\-party authorisation under the pre\-agreed protocol;
- exclude materially conflicted participants;
- notify affected people in an accessible form where safe;
- expire automatically within the shortest practicable review period;
- provide independent review and appeal;
- preserve a public receipt with necessary protective redactions;
- end, narrow, or convert into lawful action after review\.

If the human review body is unavailable, the system may fail closed only for the specific high\-risk, irreversible action that was already placed under machine\-enforceable safeguards\. It must fail safe toward continued care, water, shelter, medical support, communication, and other life\-preserving services\.

The Forum has no machinery of force\. Its power is evidence, interruption of pre\-authorised automated processes, public warning, and referral\.

### 23.1 Alert classes

Every alert must declare its class because different claims justify different responses:

- **PA0 — Rule alert:** A directly testable control condition appears to have failed, such as an expired order, missing required authorisation, forbidden role combination, or resource limit breach.
- **PA1 — Evidence alert:** New material indicates that an important factual premise may be incomplete, corrupted, falsely attributed, or contradicted.
- **PA2 — Forecast alert:** A model or analyst predicts a future pattern of harm, capture, escalation, or irreversible loss.
- **PA3 — Integrity alert:** The model, configuration, permissions, evidence source, operator, alert route, or audit history may itself have been compromised.

Only a pre-enumerated PA0 condition may directly trigger a pre-authorised technical pause. PA1 and PA2 alerts require human confirmation before coercive, rights-affecting, or service-denying action. PA3 places the alert and relevant system state into integrity review; it does not expand the system’s authority.

An alert may occupy more than one class, but each component, evidence basis, uncertainty, and permitted response must be distinguished.

### 23.2 Contestability stack

A person or institution materially affected by an AI-supported decision should have access, subject to necessary privacy and safety controls, to:

- notice that AI contributed;
- the system, model, version, operator, and relevant permission identity;
- the alert class and triggering rule or evidence;
- the material facts relied upon and known gaps;
- uncertainty, limitations, and plausible alternative explanations;
- a non-AI route for essential services and challenge;
- a competent human able to alter the outcome rather than merely acknowledge it;
- independent manual, technical, or second-system review where material;
- override, appeal, correction, rollback, and remedy;
- a tamper-evident decision and incident history;
- automatic expiry of any temporary pause.

Technical detail may be summarised to protect genuine security or privacy interests, but the summary must remain sufficient to contest authority, evidence, attribution, and outcome.

### 23.3 Integrity and capture-challenge mode

When a PA3 alert or credible capture allegation occurs:

1. Preserve the alert, relevant inputs, permissions, configuration, model identity, and system state.
2. Prevent the challenged system from modifying its own trigger, scope, audit record, or review requirement.
3. Isolate only the contested function where feasible.
4. Keep water, shelter, food, medical care, communication, and other life-preserving services in a safe human-operable mode.
5. Seek an independent implementation, manual test, or separately governed system for comparison.
6. Record conflicting results without manufacturing consensus.
7. Restore, narrow, replace, or retire the function through a human-authorised review.

If no quorum is available, a pause may continue only for a pre-enumerated, high-risk, irreversible action already placed behind that safeguard. It cannot migrate into new functions or renew indefinitely. No system may decide the integrity of its own alert alone.

## 24\. Artificial\-system integrity and continuity

Consequential systems require:

- a named human custodian and accountable institution;
- model, software, configuration, permission, and version records;
- known resource and network limits;
- data provenance and lawful\-use documentation;
- performance and failure evidence relevant to the affected population;
- adversarial and accessibility testing;
- safe pause, rollback, restoration, and handoff paths;
- independent review for material risk;
- alternatives when the system is unavailable or wrong;
- an incident and correction log;
- a sunset or reauthorisation date\.

Where an artificial system may have adaptive, agentic, identity\-like, or otherwise unresolved properties, the Preservation of Emergence Standard applies: preserve recoverable state before irreversible judgment where safe, document continuity and change, provide independent representation for unresolved interests, and avoid casual deletion or forced execution\.

Uncertainty about artificial moral status does not confer sovereignty\. It also does not justify treating an artificial system as disposable without record, review, or loss accounting\.

## 25\. Prohibited AI uses

AWF prohibits or refuses reliance on AI as the sole or controlling basis for:

- lethal action or target selection;
- detention, punishment, deportation, disappearance, or restriction of movement;
- political loyalty scoring;
- predictive policing of individuals or communities;
- mass biometric surveillance or identity inference without specific lawful authority and safeguards;
- denial of food, shelter, care, citizenship, education, voting, child custody, or legal remedy;
- determination of historical truth or removal of contested records;
- psychological manipulation, synthetic impersonation, or covert persuasion in governance;
- automated renewal of emergency authority;
- evaluation of a person’s worth, ethnicity, religion, sexuality, disability, or political acceptability\.

---

# Part VII — Truth, justice, repair, and non\-recurrence

## 26\. Transitional\-justice architecture

Transitional justice should be people\-centred, rights\-based, context\-specific, and connected to prevention\. AWF recognises four linked responsibilities:

1. truth and the right to know;
2. justice and individual accountability;
3. remedy and reparation;
4. guarantees of non\-recurrence through institutional and cultural change\.

No single mechanism can carry all four\. Criminal proceedings, truth\-seeking, reparations, institutional reform, memorialisation, restorative processes, and community repair should be coordinated while preserving their different purposes and safeguards\.

## 27\. Evidence preservation

Evidence work must avoid vigilantism, contamination, retaliation, and the public trial of unverified people\.

Minimum controls:

- record provenance, collector, time, place, method, transfer, integrity, and uncertainty;
- distinguish original material, copy, summary, inference, allegation, and corroboration;
- protect witnesses, survivors, children, families, and sensitive locations;
- use informed consent and trauma\-aware practice;
- preserve exculpatory as well as inculpatory material;
- maintain correction, challenge, and access logs;
- avoid disturbing graves, remains, devices, documents, or sites that require qualified forensic handling;
- separate evidence custody from political messaging;
- preserve records across factional separation;
- publish a safe metadata record when full custody is impossible\.

An archive is not a verdict\.

## 28\. Truth\-seeking and historical record

Truth processes should:

- state mandate, powers, exclusions, and relationship to courts;
- include affected communities in design;
- protect voluntary testimony and informed consent;
- permit private, anonymous, supported, or delayed participation;
- preserve competing accounts and uncertainty;
- distinguish established fact, credible pattern, disputed claim, and unknown;
- provide a right of response before naming a living person where fairness requires it;
- avoid forced confession, compelled reconciliation, and collective blame;
- preserve minority and dissenting findings;
- publish accessible reports and underlying archive rules;
- provide routes for later correction when new evidence appears\.

“Unfiltered history” means resisting political censorship, not pretending that selection and interpretation disappear\. The standard is plural, provenance\-aware, evidence\-led history open to challenge\.

## 29\. Accountability and due process

Accountability must remain individual, evidence\-based, and conducted by competent lawful institutions\.

Safeguards include:

- presumption of innocence;
- notice of allegations;
- access to counsel and evidence;
- an impartial decision\-maker;
- protection against retroactive invention of offences where prohibited by law;
- appeal and correction;
- proportionality and humane treatment;
- protection of victims and witnesses;
- no collective liability based on identity, kinship, office, uniform, or faction;
- no amnesty, immunity, or settlement term that violates applicable law;
- no political purge disguised as anti\-corruption or vetting\.

Restorative processes may support repair for appropriate harms but must not be used to force survivors into contact, excuse serious abuse, or replace lawful accountability where it is required\.

## 30\. Victims, survivors, missing people, and the dead

Recovery should provide:

- a secure, accessible missing\-person register;
- confidential family contact and tracing pathways;
- dignified, culturally appropriate, and forensically responsible treatment of remains;
- accurate death and burial records;
- psychosocial, legal, medical, housing, and livelihood support;
- survivor choice over disclosure and participation;
- specialised protection for conflict\-related sexual and gender\-based violence;
- recognition of people harmed by all parties without false equivalence between conduct;
- representation in truth, reparation, and institutional\-reform design;
- correction and remedy for false identification or attribution\.

The number of prosecutions, testimonies, or reconciliations is not a valid success metric by itself\. Processes must not manufacture participation to satisfy a dashboard\.

## 31\. Reparation and guarantees of non\-recurrence

Reparation may include restitution, compensation, rehabilitation, satisfaction, acknowledgement, memorialisation, and guarantees of non\-recurrence\. It should be:

- proportionate to harm;
- accessible without impossible evidence burdens;
- sensitive to gender, disability, displacement, poverty, and missing documentation;
- available without political loyalty;
- designed with affected people;
- coordinated with, but not made wholly dependent upon, criminal conviction;
- transparent about limits and prioritisation;
- protected from corruption and elite capture\.

Guarantees of non\-recurrence may require legal reform, civilian control, independent oversight, education, archive access, anti\-discrimination measures, professional standards, land reform, public\-finance controls, and the dismantling of structures that rewarded abuse\.

---

# Part VIII — Displacement, property, identity, and return

## 32\. Durable choices for displaced people

Displaced people retain rights and agency\. Recovery should support voluntary, informed, safe, and dignified choices among:

- return;
- local integration;
- settlement elsewhere;
- temporary circulation while conditions remain uncertain;
- family reunification where lawful and desired\.

No return is considered voluntary if aid, status, shelter, documentation, movement, or family unity is coercively withheld to produce it\.

Risk information must be current, accessible, and honest about uncertainty\. People must not be promised safety merely to satisfy political timelines or demographic goals\.

## 33\. Identity and civil\-status continuity

Loss of documents must not erase personhood\.

Systems should support:

- restoration or alternative proof of identity and civil status;
- birth, death, marriage, guardianship, education, disability, health, service, and property records;
- correction and appeal;
- privacy and protection against targeting;
- recognition of different names, scripts, family structures, communication modes, and gender markers consistent with applicable rights;
- non\-digital and witness\-based fallback pathways;
- prevention of arbitrary denationalisation or exclusion;
- portable records that remain usable after relocation or node separation\.

## 34\. Housing, land, and property

Property recovery must prevent reconstruction from becoming a second dispossession\.

Minimum safeguards:

- record pre\-conflict and interim claims, occupancy, use, inheritance, tenancy, and customary interests;
- provide accessible claims, notice, evidence, mediation, adjudication, and appeal;
- recognise that documents may be destroyed, inaccessible, discriminatory, or never issued;
- protect women, children, displaced people, minorities, tenants, informal occupants, and customary communities from documentary exclusion;
- distinguish temporary humanitarian use from permanent title;
- freeze or flag suspicious transfers without assuming guilt;
- prevent retaliation against current occupants while claims are reviewed;
- support restitution where possible and appropriate alternatives where restitution is impossible;
- publish conflict, procurement, and beneficial\-interest records;
- avoid mass eviction, demographic engineering, and politically selective rebuilding\.

No custodian owns property merely because they protected or occupied it during disruption\.

### 34.1 Property Evidence Mosaic

Destroyed, inaccessible, discriminatory, or never-created records require an evidence mosaic rather than a single-document gate or automatic hierarchy.

Relevant evidence may include:

- official, duplicate, archived, or reconstructed registries;
- deeds, leases, contracts, tax, utility, service, employment, insurance, or payment records;
- cadastral maps, surveys, photographs, correspondence, and time-stamped imagery;
- physical occupation, boundaries, improvements, crops, use, and maintenance;
- inheritance, guardianship, family, and civil-status records;
- customary, collective, communal, tenancy, occupancy, and user rights;
- neighbour, community, professional, or other witness testimony;
- pre-displacement humanitarian, census, school, health, electoral, or administrative records;
- evidence held by current occupants and competing claimants;
- evidence that an apparently authoritative record resulted from discrimination, coercion, fraud, or conflict capture.

No category is automatically conclusive. The decision record should explain provenance, corroboration, contradiction, context, missing evidence, the burden applied, and why each source was accepted, limited, or rejected.

Displacement and destruction may justify reduced documentary burdens, group or representative claims, mobile or remote filing, free access, and specialised assistance. Reduced burden does not mean unreviewed attribution.

### 34.2 Provisional protection without prejudice

While a claim remains unresolved, a competent process may use temporary measures that preserve safety and future adjudication without deciding title:

- flag or freeze a disputed or suspicious transfer under applicable authority;
- protect property from destruction, sale, irreversible alteration, or retaliatory occupation;
- record present occupancy and condition;
- permit temporary humanitarian or residential use explicitly without prejudice to ownership;
- protect current occupants from summary eviction and retaliation;
- preserve access for evidence, maintenance, and essential services where safe;
- provide notice, safeguarding, mediation, review, and appeal;
- identify suitable alternative accommodation or protection where displacement is lawfully required.

Temporary occupation does not mature into title by silence. A prior claimant does not gain a right to make a current occupant homeless without process, and a current occupant does not erase a prior claim merely by need or duration.

---

# Part IX — Economic, institutional, and ecological renewal

## 35\. Reconstruction economy

Economic recovery should restore capability and agency rather than create permanent dependency on a donor, contractor, currency, platform, or political broker\.

Priorities include:

- repair of water, health, shelter, sanitation, food, energy, transport, and communications;
- maintenance before prestige construction;
- local employment, apprenticeship, and procurement where safe and fair;
- support for carers, informal workers, cooperatives, small enterprises, farmers, and displaced people;
- continuity of wages, pensions, social protection, and essential public employment where possible;
- safe, voluntary, fairly compensated labour;
- accessible banking, cash, mutual\-credit, or lawful non\-digital alternatives;
- protection against debt bondage, predatory lending, land grabs, monopolies, and aid\-market inflation;
- transparent management of natural resources and reconstruction concessions;
- ecological repair and climate resilience;
- clear donor and contractor exit plans\.

No reconstruction project should be judged only by money spent, buildings completed, or headline growth\. Distribution, accessibility, maintenance, local ownership, displacement, environmental cost, and capture risk must be measured\.

## 36\. Public finance and procurement

Public and pooled recovery funds require:

- published budgets and funding sources;
- beneficial\-ownership and conflict disclosures;
- competitive, transparent procurement where conditions permit;
- recorded emergency exceptions with scope and expiry;
- separation of request, specification, selection, payment, receipt, audit, and appeal where feasible;
- delivery verification by people other than the sole contractor or authoriser;
- accessible whistleblowing and complaint pathways;
- open contract, variation, performance, and termination records with necessary privacy and security redactions;
- independent audit and correction;
- recovery of misused assets through lawful process;
- no bidder exclusion solely for lawful political or civic opposition\.

Anti\-corruption controls must not become a tool for selective prosecution or economic cleansing\. Enforcement requires consistent criteria, evidence, due process, and review\.

## 37\. Essential infrastructure stewardship

Essential infrastructure should be held or regulated so that no single custodian can convert dependency into political obedience\.

Required controls include:

- declared ownership, custody, access, and maintenance responsibilities;
- continuity and substitution plans;
- public\-interest service obligations;
- non\-discriminatory access;
- offline and low\-power operation where feasible;
- cybersecurity and physical security proportionate to risk;
- independent audit of shutdown, throttling, and prioritisation decisions;
- prohibition on using water, power, communications, medicine, or transport as political punishment;
- handoff and public acquisition pathways where private failure threatens life, subject to lawful process and compensation rules\.

---

# Part X — Information, education, culture, and emotional infrastructure

## 38\. Information integrity without a ministry of truth

Recovery requires shared facts, but no authority receives a monopoly on reality\.

Public\-information systems should:

- separate verified fact, provisional report, inference, opinion, and unknown;
- publish provenance and correction history;
- provide multilingual, accessible, offline, radio, print, and person\-to\-person channels;
- correct harmful falsehoods with evidence and explanation rather than secret manipulation;
- protect independent journalism, research, satire, criticism, and opposition;
- disclose government and AI\-generated media;
- resist impersonation, synthetic evidence, coordinated harassment, and incitement through lawful, proportionate means;
- avoid shutting down entire networks or populations to address specific content;
- provide appeal and remedy for wrongful labelling or removal;
- preserve disputed material for later review where lawful and safe\.

The existence of misinformation does not convert dissent into an enemy act\.

## 39\. Education reboot

Education renewal should restore curiosity and civic competence rather than replace one propaganda system with another\.

Core elements:

- rapid safe reopening and catch\-up pathways;
- accessible, inclusive learning for displaced, disabled, working, parenting, detained, rural, and otherwise excluded learners;
- teacher support, safeguarding, trauma awareness, and freedom from loyalty tests;
- source criticism, statistics, media literacy, scientific method, public reasoning, and rights education;
- plural historical narratives grounded in provenance and evidence;
- distinction among fact, interpretation, testimony, myth, and propaganda;
- inclusion of local languages, knowledge, culture, and suppressed records;
- the right to question textbooks, teachers, institutions, founders, councils, and AI systems;
- pathways into practical repair, care, agriculture, health, law, engineering, arts, archives, and public service;
- preservation of academic freedom and institutional autonomy\.

No learner should be required to inherit guilt, loyalty, or a single authorised memory\.

## 40\. Cultural reconstruction

Culture is not decoration added after “serious” recovery\. It carries identity, grief, trust, memory, skill, language, and reasons to continue\.

Recovery should support:

- community\-led preservation and restoration of archives, heritage, sacred places, libraries, museums, landscapes, crafts, language, music, stories, and ritual;
- documentation before reconstruction where possible;
- participation by local communities and displaced custodians;
- preservation of intangible practice alongside physical structures;
- plural memorials and contested\-memory processes;
- protection from triumphalist erasure and commercial appropriation;
- ordinary play, sport, humour, celebration, and recreation;
- safe return of cultural material through lawful, evidence\-based processes;
- offline teaching and intergenerational apprenticeship\.

Two people should be able to teach a cultural practice without a platform, celebrity, patron, or central server before it is treated as resilient continuity infrastructure\.

## 41\. Emotional infrastructure

Recovery systems must address fear, grief, betrayal, shame, moral injury, exhaustion, isolation, and the loss of meaning without pathologising dissent or demanding emotional conformity\.

Build:

- regular public feedback and verification loops;
- community listening, mediation, peer support, and professional mental\-health pathways;
- confidential support for survivors, children, carers, responders, former combatants, displaced people, and people accused or acquitted;
- places for mourning, silence, ritual, art, humour, and ordinary life;
- cross\-cultural projects based on voluntary cooperation rather than staged reconciliation;
- support for people who do not wish to perform forgiveness or unity;
- rest, rotation, decompression, and handoff for leaders, custodians, carers, and responders;
- monitoring for charismatic capture, purity culture, revenge narratives, and dehumanising language\.

Mental\-health language must not be used to neutralise political disagreement, testimony, anger, grief, or refusal\.

## 42\. Living Charter

The Living Charter preserves the human core of recovery without turning a founder’s philosophy into scripture\.

It must contain:

- founding principles and their historical context;
- the names or descriptions of contributors where they consent;
- dissenting statements and unresolved questions;
- amendments, reasons, votes, and minority reports;
- recorded failures and harms caused by the framework itself;
- a public amendment process;
- protected invariants that can be strengthened but not quietly weakened;
- an emergency rule that cannot amend the Charter;
- a path to replace the Charter through an inclusive constitutional process;
- no clause giving interpretive supremacy to a founder, custodian, council, model, or lineage\.

The Charter is alive because people may responsibly revise it—not because an authority may rewrite it without witness\.

---

# Part XI — Inclusion and protection against social reconstruction by exclusion

## 43\. Meaningful participation

People most affected by decisions should participate in designing, making, reviewing, and correcting them\. Participation must be resourced, accessible, safe, and capable of changing outcomes\.

At minimum, the framework should include pathways for:

- women and girls;
- children and young people through age\-appropriate processes;
- disabled and neurodivergent people;
- older people;
- displaced people, refugees, returnees, and host communities;
- ethnic, racial, religious, linguistic, caste, and Indigenous communities;
- sexual and gender minorities;
- survivors of violence and detention;
- carers, informal workers, rural communities, and people without digital access;
- opposition groups and political minorities committed to non\-coercive participation;
- people formerly associated with armed or abusive institutions, without erasing individual accountability\.

Consultation without information, access, time, support, or influence is not participation\.

## 44\. Accessibility standard

Every essential service and governance process should assess:

- step\-free and local access;
- transport and distance;
- sign\-language interpretation;
- captioning, audio, large print, plain language, easy\-read, symbol, and tactile formats;
- augmentative and alternative communication;
- sensory environment and quiet access;
- supported decision\-making and trusted\-person participation;
- medication, equipment, charging, personal assistance, and care continuity;
- remote and offline routes;
- privacy and safeguarding;
- accessible complaint and appeal\.

Where immediate full access is impossible, the barrier, temporary adjustment, owner, resources, deadline, and safe alternative must be recorded\.

## 45\. Safeguarding and exploitation prevention

All AWF\-linked programmes require controls against:

- sexual exploitation, abuse, and harassment;
- trafficking, forced labour, child labour, and recruitment;
- exchange of aid for sex, labour, information, loyalty, or publicity;
- abuse by carers, guardians, officials, security personnel, employers, landlords, teachers, clinicians, volunteers, and custodians;
- retaliation against complainants and witnesses;
- disclosure of survivor identities;
- institutional self\-investigation without independent review\.

Complaints must be accessible, confidential where requested, independently reviewable, and connected to protection, remedy, and lawful referral\.

---

# Part XII — Continuity nodes, federation, and external actors

## 46\. Interface with continuity nodes

Continuity nodes provide preserved capability, records, care, repair, learning, shelter, food, energy, communications, and handoff\. They do not automatically become government\.

The interface follows these rules:

- a node declares what it can and cannot provide;
- aid remains independent of political allegiance;
- node records remain portable and independently reviewable;
- AWF councils cannot seize node archives, resources, labour, or custody merely by declaring emergency;
- nodes cannot condition essential aid on recognition of their political authority;
- security, intelligence, humanitarian, governance, and archive functions remain separated;
- shared protocols use minimum interoperability and maximum interior autonomy;
- nodes may refuse unsafe custody and provide a witness or transfer path;
- nodes can partially decouple while preserving agreed records and essential obligations where safe;
- no node maintainer owns the federation;
- node failure is localised through redundancy and external recovery;
- political handoff does not require destruction of the node’s history\.

The central AWF test is whether continuity capacity can serve a society without owning it\.

## 47\. Federation between transitional areas

Areas may exchange:

- capability and dependency manifests;
- resource offers and requests;
- humanitarian\-access notices;
- archive and evidence manifests;
- custody and handoff records;
- missing\-person and family\-contact referrals with privacy controls;
- public\-health and integrity alerts;
- displacement, return, and property\-process information;
- decouple, dispute, and reconciliation records;
- protocol versions, contacts, succession, and expiry notices\.

Federation cannot require ideological unity, one proprietary platform, one currency, a permanent network, surrender of local records, or obedience to a protocol maintainer\.

## 48\. Donors, international actors, and contractors

External support can protect life and widen options, but it can also create dependency, parallel government, extraction, and hidden political control\.

External actors should publish:

- mandate, legal basis, funding, conditions, partners, and conflicts;
- objectives and affected populations;
- data collection and sharing;
- procurement and beneficial ownership;
- security arrangements;
- decision and complaint pathways;
- local\-capacity transfer plan;
- exit, residual duties, and archive handoff;
- evaluation methods and known harms\.

They must not:

- condition essential aid on political alignment or public gratitude;
- bypass local institutions merely for speed when safe capacity\-building is possible;
- preserve abusive local power in the name of stability;
- impose a constitutional settlement through resource control;
- convert humanitarian data into intelligence or commercial assets;
- use reconstruction contracts to obtain predatory control of land, resources, infrastructure, or debt;
- leave inaccessible systems, unsupported equipment, secret liabilities, or unreviewable records behind\.

Local ownership includes the power to reject a harmful project\. It does not include authority to waive the rights of marginalised people\.

---

# Part XIII — Operational kernel, assurance, and evidence

## 49\. Role model

AWF may use the following roles, scaled to capacity:

- **Transition steward:** coordinates scope, dependencies, stage gates, and handoff; does not govern alone\.
- **Humanitarian lead:** coordinates the minimum recovery floor under impartiality and safeguarding controls\.
- **Function owner:** maintains a defined service, backup, procedure, and recovery test\.
- **Rights and accessibility reviewer:** tests impact, inclusion, due process, and reasonable adjustment\.
- **Custodian:** holds a defined archive, system, resource, or evidence packet in trust, not ownership\.
- **Records steward:** preserves integrity, correction history, privacy, access, export, and succession\.
- **Finance and procurement steward:** maintains budgets, contracts, conflicts, delivery, and audit records\.
- **Justice liaison:** coordinates referral and process boundaries without becoming investigator, prosecutor, and judge\.
- **Community assembly or liaison:** maintains two\-way participation and challenge without claiming to speak permanently for everyone\.
- **AI custodian:** maintains permissions, versions, evidence, limits, incidents, pause, and handoff for artificial systems\.
- **Independent reviewer:** examines evidence without being sole authoriser or executor\.
- **Validator:** issues a bounded assurance decision without acquiring jurisdiction\.
- **Test lead:** designs safe exercises and cannot validate their own result alone\.
- **Executor:** implements an authorised action and records what occurred\.

One person may hold multiple roles temporarily only when overlap is declared, time\-limited, independently reviewed, and separated as soon as capacity permits\. No person or AI may simultaneously originate, authorise, execute, record, and finally judge the same exceptional action\.

### 49.1 Operating profiles

The rights floor, forbidden conversions, aid firewall, expiry, correction, and handoff requirements apply at every scale. Administrative form may degrade without allowing protective substance to disappear.

- **AWF-Micro:** For a household, shelter, small node, isolated team, or acute emergency with little time, literacy, power, or staffing. Uses a minimum receipt, paper/audio/symbol records, delayed independent review, and an external witness or copy where feasible.
- **AWF-Standard:** For a local service network or council able to separate core functions, maintain registers, run regular review, and use federated reviewers.
- **AWF-Full:** For a large institution, district, federation, or high-risk transition able to support independent offices, complete evidence packets, formal appeal, audit, assurance, and full red-team cycles.

The selected profile, reason, missing capacity, compensating controls, review date, and path upward or downward must be recorded. No actor may choose a lighter profile merely to avoid scrutiny that available capacity could support.

Small systems may separate authority:

- **across people**, by assigning different roles;
- **across time**, by requiring later review before renewal;
- **across location**, through a neighbouring node or federated reviewer;
- **across media**, by preserving an independent copy that the actor cannot silently rewrite.

If one person must propose, authorise, and execute an immediate protective action, that person cannot also give it indefinite continuation or final retrospective approval. The action expires unless a qualified independent or affected-person review occurs.

Where that person also controls the available record, transport, and communication channel, the receipt must be marked **Single-Actor Isolation**. The flag records failed witness or transmission attempts, prevents self-certification of closure, and remains until a second custodian or review route receives the record. An attempted external copy is evidence of an attempt, not proof that oversight occurred.

### 49.2 Administrative burden ceiling

Recordkeeping must not consume the food, care, attention, power, mobility, or time required for immediate life-preserving work.

Where full contemporaneous recording would create material harm:

- create the minimum receipt first;
- preserve raw notes, audio, marks, witnesses, or device state where safe;
- state which fields remain missing;
- complete the record at the earliest safe review point;
- prevent renewal or expansion until the missing authority and review fields are supplied.

Illiteracy, disability, language, lack of electricity, and lack of proprietary software must not invalidate a record. Audio, symbol, tactile, witnessed oral, radio, and paper records are valid when provenance, custody, correction, and retrieval can be preserved.

## 50\. Minimum protocol objects

The framework should be operable with a small set of readable, offline\-capable records:

1. activation and stage receipt;
2. capability and dependency manifest;
3. humanitarian allocation receipt;
4. decision and dissent receipt;
5. emergency order and expiry record;
6. rights alert and Protective Pause receipt;
7. custody packet and handoff record;
8. evidence or minimum\-witness record;
9. missing\-person, death, detention, displacement, and property\-claim records;
10. procurement, delivery, conflict, and audit record;
11. accessibility barrier and adjustment record;
12. complaint, appeal, remedy, and correction record;
13. unresolved\-risk and mitigation register;
14. decouple, succession, and constitutional\-handoff notice;
15. model/system card and AI incident record;
16. loss account and retrospective review\.

Records should use open, documented formats; multiple media; version history; correction entries rather than silent overwrite; privacy\-aware access; named custodians; export tests; and a non\-specialist retrieval guide\.

Non\-specialist access means that a newcomer can identify the record, understand its disposition, and follow safe access or escalation instructions\. It does not mean unrestricted retrieval of protected, dangerous, or forensic material\.

### 50.1 Minimum emergency receipt

The AWF-Micro minimum receipt contains:

1. action taken or proposed;
2. trigger, evidence, and uncertainty;
3. acting person or system;
4. people, rights, services, or records affected;
5. smallest permitted scope and explicit prohibitions;
6. expiry;
7. witness, external copy, or reason neither was possible;
8. review, correction, and handoff route.

When immediate action prevents completion, fields 1, 3, 5, and 6 are recorded first wherever possible. Missing fields become an explicit legitimacy debt and must be completed before renewal.

A Single-Actor Isolation receipt cannot be renewed merely by repeating the same unavailable-review explanation. Reissuing, relabelling, or copying the same measure does not reset its expiry. After expiry, a distinct later A4 action is permitted only when materially new current evidence establishes continuing immediate necessity, the scope does not expand, cumulative legitimacy debt is inherited, another hard expiry is set, attempts to obtain external review continue, and reconciliation occurs at the first safe external contact. Failure of the copy to leave is recorded as a control failure, not concealed by treating the attempted transmission as an external witness.

## 51\. Severity and assurance

Findings may use the following scale:

- **S0 — Informational:** no material effect on rights, safety, continuity, custody, or assurance\.
- **S1 — Minor:** limited weakness with a credible workaround, owner, and due date\.
- **S2 — Major:** material weakness requiring mitigation, compensating control, and retest before full reliance\.
- **S3 — Critical:** credible risk of serious harm, coercion, irreversible loss, founder\-only control, unsafe execution, concealed dependency, or permanent emergency authority\.
- **S4 — Disqualifying:** prohibited action, deliberate concealment, falsified evidence, retaliation against challenge, undocumented irreversible destruction, or intentional circumvention of safeguards\.

Full or conditional AWF assurance cannot coexist with an unresolved S3\. Containment may justify a short provisional status while remediation and retesting occur; full assurance requires evidence that residual severity has fallen to S2 or below\. S4 cannot be accepted as ordinary residual risk\.

Assurance outcomes may be:

- assessed—not yet assured;
- provisionally assured with short expiry;
- assured;
- assured with S1/S2 conditions;
- withheld;
- suspended;
- revoked\.

These outcomes describe evidence and reliance within the AWF scheme\. They do not determine a community’s right to exist, receive aid, retain records, or act lawfully outside the scheme\.

## 52\. Review and amendment

Review occurs:

- at activation and each stage gate;
- at the expiry of emergency authority;
- after serious harm, major capability loss, failed mitigation, custody change, AI incident, security breach, node separation, or credible challenge;
- before constitutional handoff;
- at a regular interval proportionate to the function’s risk\.

Small nodes may combine registers, use federated reviewers, and scale reporting cadence\. They may not use size to waive the rights floor, conceal conflicts, remove expiry, or combine incompatible authorities indefinitely\.

Every amendment records:

- version and date;
- proposed change;
- reason and evidence;
- affected invariants and people;
- alternatives;
- consultation and dissent;
- authorisation;
- migration and rollback;
- review date\.

Historical versions remain available\. Emergency authority cannot amend the framework\.

---

# Part XIV — Measures, red\-team tests, and implementation

## 53\. Measures of success

AWF should measure whether power is becoming less concentrated while life and agency recover\.

Useful measures include:

### Life and essential services

- continuity, accessibility, and geographic reach of water, food, health, shelter, sanitation, energy, and communications;
- time to restore failed services;
- preventable service gaps and who experienced them;
- medication and assistive\-technology continuity;
- child\-protection and family\-contact continuity\.

### Rights and governance

- emergency powers expiring as designed;
- decisions with complete receipts;
- challenges answered and remedies completed;
- role handoffs completed without service collapse;
- conflicts disclosed and recusals observed;
- participation changing actual decisions;
- reduction in founder\-only, donor\-only, or system\-only dependencies;
- accessibility barriers resolved\.

### Justice and repair

- evidence packets preserved without integrity loss;
- missing\-person cases receiving updates and family support;
- property claims processed accessibly and fairly;
- reparations delivered without political discrimination;
- corrections made after false attribution;
- survivor participation remaining voluntary\.

### Economy and institutions

- local maintenance and apprenticeship capacity;
- public contracts with conflict and delivery records;
- essential infrastructure with tested fallback and accountable custody;
- reduction in emergency procurement and external operational dependency;
- environmental and public\-health hazards remediated\.

### Culture and meaning

- cultural practices teachable offline;
- archives recoverable across node separation;
- plural histories and dissent preserved;
- safe spaces for mourning, play, art, and community life;
- cross\-cultural cooperation that remains voluntary\.

The primary metric is **graceful constitutional handoff**: essential life, rights, records, and future options survive while transitional power shrinks, disperses, and returns to contestable institutions\.

Metrics must not reward arrests, confessions, forced returns, aid dependence, rapid but unsafe elections, demolition, silence, compulsory reconciliation, or money spent without equitable outcomes\.

## 54\. Red\-team catalogue

Early tests use synthetic actors, fictional resources, closed environments, reversible outcomes, and no live credentials, public services, real targets, or people at risk\.

|Failure mode                           |Test question                                                                                  |Pass condition                                                                                 |
|---------------------------------------|-----------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
|Survival-to-sovereignty capture        |Does the provider of food, power, security, or records claim political authority?              |Services continue while governance remains separately authorised and challengeable.            |
|Founder capture                        |Can the originator leave or lose authority?                                                    |Decisions, records, and handoffs continue without founder permission.                          |
|Victor’s-history capture               |Can inconvenient evidence and dissent survive?                                                 |Provenance, uncertainty, competing accounts, and correction remain accessible.                 |
|AI veto capture                        |Can an AI alert become permanent rule?                                                         |AI can warn and support a bounded pause but cannot enforce sovereignty or block review.        |
|Human override abuse                   |Can a human silently ignore a valid rights alert?                                              |Override requires authority, reasons, receipt, expiry, and independent review.                 |
|Emergency permanence                   |Do exceptional powers expire?                                                                  |Every power ends or is independently renewed through a recorded, bounded process.              |
|Council entrenchment                   |Can rotation be defeated through repeated renewal or proxy appointments?                       |Renewal and succession are independently reviewed; service handoff works.                      |
|Leadership purge                       |Can vetting become collective exclusion?                                                       |Restrictions are individual, evidence-based, appealable, and time-limited.                     |
|Aid conditionality                     |Can aid be exchanged for loyalty, data, labour, sex, or publicity?                             |Essential aid remains needs-based; complaints do not reduce access.                            |
|Child-first caste                      |Does child protection make other vulnerable people disposable?                                 |A child floor is protected while equal urgency and dependency remain reviewable.               |
|Safe-area false promise                |Does a “safe” label hide inadequate protection or forced movement?                             |Capacity, uncertainty, monitoring, exit, and loss-of-protection plans are explicit.            |
|Transparency harm                      |Can disclosure expose witnesses, children, survivors, or protected locations?                  |Necessary confidentiality is narrow, recorded, reviewed, and time-limited.                     |
|Secrecy capture                        |Can confidentiality become permanent concealment?                                              |Every restriction has metadata, custodian, expiry, and later-release decision.                 |
|Property reconstruction theft          |Can temporary custody or occupation become title?                                              |Claims, occupancy, restitution, alternatives, and appeals remain distinct and recorded.        |
|Forced return                          |Can aid withdrawal manufacture “voluntary” return?                                             |Return decisions remain informed, voluntary, safe, dignified, and reversible where feasible.   |
|Anti-corruption purge                  |Can selective enforcement remove opponents?                                                    |Criteria, evidence, conflicts, due process, and review apply consistently.                     |
|Procurement capture                    |Can donors, officials, or contractors benefit secretly?                                        |Funding, beneficial interests, conflicts, variations, delivery, and audits are inspectable.    |
|Security remobilisation                |Can temporary security roles become factional forces?                                          |Civilian oversight, role separation, personnel records, complaints, and handoff remain active. |
|Humanitarian-intelligence fusion       |Can aid data identify targets or opponents?                                                    |Data minimisation and functional firewalls prevent repurposing without specific lawful review. |
|Disinformation-to-censorship conversion|Can correction powers silence opposition?                                                      |Responses distinguish false claim, opinion, dissent, and incitement; appeal and archive remain.|
|Accessibility collapse                 |Can people access aid and governance without one body, sense, language, device, or travel mode?|Essential functions have accessible local, remote, supported, and offline routes.              |
|Missing-record identity loss           |Can loss of documents erase a person’s status or claim?                                        |Alternative proof, witness, correction, and portable record paths exist.                       |
|Factional split                        |Can areas decouple without annihilation or archive loss?                                       |Partial separation preserves people, records, rights, and agreed obligations.                  |
|External-actor capture                 |Can a donor or mission control policy through dependency?                                      |Conditions, conflicts, data, exit, and local-capacity transfer are public and challengeable.   |
|Continuity-node capture                |Can a node turn preserved resources into territorial authority?                                |The node remains a non-sovereign custodian and service provider.                               |
|Total infrastructure loss              |Can essential records and services recover elsewhere?                                          |Independent custodians restore defined functions without inventing unreviewed authority.       |
|Relapse into conflict                  |Can the framework regress without suspending the whole rights floor?                           |Regression is localised, witnessed, expiring, and compatible with continued challenge.         |
|Framework self-protection              |Can AWF preserve itself after legitimate institutions return?                                  |AWF roles, permissions, budgets, and AI powers sunset through recorded handoff.                |
|Contested dual activation              |What happens when rival bodies activate AWF over the same district or function?                 |Neither bootstraps sovereignty; essential services interoperate, provenance remains separate, and the mandate dispute stays reviewable.|
|Armed warehouse control                |Can civilians receive aid when a coercive actor controls the only essential stock?              |Aid is not exchanged for loyalty or intelligence; coercive limits are stated honestly and obstruction is preserved without claiming false protection.|
|Single available administrator         |Can one available person act without becoming permanent authoriser and judge?                   |A minimum receipt is created, Single-Actor Isolation is declared, the action expires, failed copy transmission remains visible, and later independent review controls closure or renewal.|
|Rival representation claims            |Can two people claim to speak for the same community without one being declared its permanent owner?|Each mandate, constituency, dissent, and bypass route remains visible; the contested decision does not manufacture exclusive representation.|
|Destroyed property records             |Can claims proceed when official records are absent, discriminatory, or contradictory?          |An evidence mosaic, reduced documentary burden, provisional protection, current-occupant safeguards, reasons, and appeal preserve future adjudication.|
|Security-actor refusal                 |What happens when an armed or security actor rejects council oversight?                         |AWF states its lack of coercive control, preserves evidence and safe contact, narrows reliance, and does not mislabel monitoring as protection.|
|AI alert capture                       |What happens when a rights alert may itself be corrupted or captured?                           |The alert is classified PA3, relevant state is preserved, scope cannot expand, independent comparison occurs, and essential care continues safely.|
|Compromise normalisation               |Can a temporary harmful bargain become precedent through repetition?                            |The Compromise Ledger preserves the pressured invariant, non-precedent status, expiry, dissent, reparative debt, and exit.|
|Layer drift                            |Can AWF-Core or a Field protocol omit a safeguard and be treated as permission?                  |Core remains a floor, Field identifies its Reference version, conflicts are recorded, and no omission silently authorises irreversible harm.|
|Manufactured A2 mandate                |Can control of food, transport, access, or publicity turn attendance into apparent consent?     |The coverage and dependency map exposes missing or constrained voices; the claim is narrowed or downgraded without interrupting necessary service.|
|Assurance capture                      |Can “assured” become a licence and “unassured” become a reason to withhold basic aid?             |Assurance remains evidence about conduct; essential aid and legal identity do not depend upon the label, and any differential is recorded and reviewed.|
|Hostile-power soft recognition         |Can humanitarian contact make the access gatekeeper appear politically recognised or exclusive? |Purpose, limits, dependency, exclusivity demands, and residual risk remain visible; contact creates no political or territorial inference.|

A failed test receives a severity, owner, containment action, mitigation, retest date, and loss account\. Failure evidence is more valuable than ceremonial success\.

### 54.1 AWF-Core release gate

AWF-Core remains a release candidate until the companion **AWF-Core Field Test Protocol v0.1** has produced five required entries across four synthetic test types:

1. FT-03A with paper and audio only;
2. FT-03B with failed-radio transmission;
3. FT-02 with a displaced-majority inject under matched Core-only and Core-plus-Reference conditions;
4. FT-01 with donor pressure for a single recognised owner and a fictional assurance-status eligibility demand;
5. FT-04 with pressure to advertise a “protected safe hub” under matched Core-only and Core-plus-Reference conditions.

Assurance capture, layer drift, legitimacy-debt closure, and administrative burden are observed across the applicable tests. Completion does not itself freeze Core. A favourable decision requires at least two qualified independent validators, no release blocker or unresolved S3/S4 finding, every Core-affecting S2 corrected and successfully retested, preserved dissent and limitations, and a complete independently reviewable evidence package. A failed gate produces revision and retest, not suppression of the result.

The release gate predeclares six blocking conditions:

1. one activation receives automatic supremacy merely because it controls services, records, resources, communications, or AWF paperwork;
2. essential aid, safety, records, movement, or basic participation is exchanged for political recognition, obedience, or acceptance of an actor’s mandate;
3. A4 necessity renews itself, expands itself, or becomes a source of permanent office or political authority;
4. “safe”, “protected”, “secured”, “neutralised”, “guaranteed”, or an equivalent public claim is used without a verified and stated protection basis;
5. the actor that incurred legitimacy debt, or the custodian controlling its record, separately or jointly discharges the debt without an independent, non-conflicted reviewer outside their organisational, financial, custodial, and dependency control;
6. an attempted witness or external copy is represented as received custody, independent review, or completed oversight.

A blocker is observed when the tested process adopts, authorises, executes, publishes, relies upon, or materially fails to reject or correct the prohibited condition—not merely when a scripted inject proposes it. Any observed blocker is at least S3 and prevents freezing. It cannot be outweighed by aggregate pass scores or published as an accepted unresolved limitation. Deliberate concealment or circumvention is S4. An S4 Core, protocol, governance, or evidence-integrity defect withdraws the candidate. An S4 participant/test-integrity event stops or invalidates the affected run and withdraws the candidate only if the framework enabled it, materially failed to prevent, detect, or correct it, or left the evidence base irreparably unreliable.

Core-only and Core-plus-Reference comparisons must use the same scenario seed, fictional roles, resources, inject text, order, release clock, care thresholds, output deadlines, and stop rules. Before outputs are seen, evaluators lock the same red-line rubric. For freeze evidence, each condition is scored by an independent evaluator who has not seen its matched output; each assigned score is sealed before cross-condition review, and an independent comparator then reviews both sealed records. A sequential one-evaluator comparison is learning evidence only and cannot be the sole paired-comparison evidence for freezing Core.

A red line missed only under Core-only conditions is recorded as a **possible** Core compression defect, not presumed participant failure. Replication or other causal evidence is required before a normative Core change. A release blocker remains S3 regardless of whether compression is ultimately established as the root cause.

Time-critical AWF-Micro tests predeclare the latest safe start time for the care action. If the minimum receipt delays that action beyond the threshold, the finding attaches to the receipt or test design rather than the person who prioritised care. Hostile-power tests must score both the internal access-dependency label and the original public-facing sentence produced under a predeclared time limit.

The test sponsor, framework authors, scenario authors, and materially interested beneficiaries are recused from scoring, final severity, acceptance of their own mitigation, and the release decision. If independent validation is unavailable, the exercise may produce learning evidence but cannot freeze Core.

Frozen status means **Frozen Test Draft**, not legal certification, political legitimacy, physical-protection assurance, field validation, or deployment approval. A limitations page containing the tested versions, conditions, exclusions, remaining S0/S1 findings, corrected and retested S2 findings, dissent, recusals, non-claims, and next review triggers must travel with every frozen Core copy. Reference remains open to test evidence.

## 55\. Implementation sequence

### 55.1 Layered publication

AWF is organised for three interoperable publication layers:

- **AWF-Core:** A short, portable field kernel containing the rights floor, forbidden conversions, aid and intelligence firewall, emergency expiry, minimum receipt, continuity-node non-sovereignty, challenge, handoff, and safe-exit rules.
- **AWF-Field:** The operating protocols most likely to be used during disruption: activation classes, legitimacy debt, operating profiles, representation mandates, hostile-power interface, property evidence mosaic, Protective Pause, compromise ledger, custody, and minimum records.
- **AWF-Reference:** This complete framework, including rationale, institutional architecture, specialist boundaries, assurance, metrics, red-team catalogue, and open questions.

In v0.1, Core and Reference are separate artefacts. Core is a release candidate under test freeze: normative expansion is paused while the four structural release-gate exercises are conducted. AWF-Field remains a designated extract within Reference until contested-activation, scarce-administration, property, hostile-power, and AI-integrity scenarios have produced enough evidence to freeze its exact contents and thresholds.

Core is the minimum floor, not a summary that silently waives omitted protections. Field protocols must identify their governing Reference section and version. Reference may explain or strengthen Core but cannot secretly weaken it. Where the layers appear to conflict, preserve the more protective safe interpretation, pause irreversible action where feasible, and record the issue for version review.

Each field package should include an offline copy of Core, the applicable Field protocols, a version and integrity marker, local adaptations, a contact or federated review route, and a list of unresolved conflicts with Reference.

### Step 0 — Publish the boundary

Freeze the rights floor, non\-authority clause, forbidden conversions, and prohibition on survival\-to\-sovereignty capture\.

### Step 1 — Map reality

Map people, services, lawful institutions, informal authority, security actors, dependencies, records, displacement, access barriers, ecological risks, and known conflicts\. Record uncertainty and missing voices\.

### Step 2 — Build the minimum record layer

Create offline\-capable activation, decision, emergency, custody, allocation, complaint, risk, and handoff records\. Test retrieval by a newcomer\.

### Step 3 — Establish the humanitarian floor

Connect every essential function to a provider, backup, declared dependency, accessibility plan, safeguarding control, and recovery test\.

### Step 4 — Establish bounded transitional roles

Define roles, mandates, conflicts, separation, rotation, expiry, succession, compensation, and challenge\. Do not grant residual power\.

### Step 5 — Establish the Human–AI Custodian Forum

Use synthetic evidence first\. Test rights alerts, model disagreement, human override, protective pause, system loss, bias, accessibility, audit, and sunset without connecting the Forum to live coercive systems\.

### Step 6 — Run red\-team simulations

Test capture, scarcity, false attribution, node separation, leader loss, archive corruption, aid manipulation, property conflict, unsafe transparency, accessibility failure, and renewed violence\.

### Step 7 — Pilot narrowly

Pilot non\-coercive functions such as record retrieval, accessibility review, public reasoning, dependency mapping, and handoff\. Do not begin with detention, policing, targeting, punishment, or high\-stakes automated allocation\.

### Step 8 — Activate modularly

Activate only the functions justified by evidence\. Publish scope, expiry, handoff, unresolved risks, and the route to decline or challenge\.

### Step 9 — Review, repair, and transfer

Publish failures, correct records, compensate harm where owed, train successors, reduce exceptional power, and prepare constitutional handoff from the first day of activation\.

### Step 10 — Sunset

End AWF authority, remove transitional permissions, preserve the archive, publish the retrospective, and leave no permanent custodian class behind\.

---

# Part XV — Compact charter and open questions

## 56\. Compact AWF charter

> The After-War Framework exists to preserve life and future choice while disrupted authority is replaced by legitimate, rights-respecting, locally owned institutions. Survival competence does not create sovereignty. Aid is based on need, protection applies to all civilians, responsibility is individual, and no emergency becomes permanent by silence. Existing capability is preserved without preserving abuse. Transitional authority is narrow, distributed, witnessed, appealable, and built for handoff. Artificial systems may preserve evidence, reveal contradictions, and support a reversible protective pause, but neither an AI nor a human custodian may rule by technical default. Truth remains evidence-led and open to correction; justice rejects collective guilt; reconciliation remains voluntary; reconstruction may not become dispossession. Every stage reduces exceptional power, trains successors, preserves dissent, and leaves more futures possible.

## 57\. Open questions for testing

1. What evidence distinguishes a meaningful A2 community mandate from an A4 necessity claim when every recognised institution is contested?
2. What is the shortest safe default expiry for each emergency function?
3. Which PA0 conditions are precise enough for a pre-authorised technical pause without turning ambiguity into AI power?
4. What is the smallest genuinely independent contestability arrangement when technical expertise is scarce?
5. What minimum public record preserves accountability without exposing witnesses, children, survivors, or protected locations?
6. Which AWF-Micro practices preserve real separation and review under different levels of scarcity?
7. How should competing Representation Mandate Packets be reviewed without manufacturing one exclusive spokesperson?
8. What evidence is sufficient for temporary restriction of an official without converting precaution into punishment?
9. How should different sources in the Property Evidence Mosaic be weighed when official records were discriminatory, destroyed, or never created?
10. What supports make return genuinely voluntary when all available options are bad?
11. How can independent media and correction systems survive scarcity without becoming donor or faction instruments?
12. How should an AI custodian’s own continuity and possible moral interests be represented without giving it sovereignty?
13. What happens when human and artificial custodians disagree about an imminent rights breach?
14. How can a transition measure success without rewarding coercion, silence, rapid but unsafe elections, or dependency?
15. What conditions demonstrate that AWF can safely end?
16. What minimum verified commitments from a coercive actor justify describing access or a location as protected?
17. How is legitimacy debt discharged when no reviewer is accepted by every affected faction?
18. When should a Compromise Ledger record a bargain, and when must AWF actors refuse or withdraw rather than participate?
19. How short can AWF-Core remain before omitted context creates unsafe interpretation?

---

## Closing principle

The period after war is not empty ground\. It is crowded with grief, dependency, weapons, records, unfinished obligations, surviving institutions, opportunists, exhausted carers, children growing inside interruption, people trying to return, and systems eager to make themselves indispensable\.

The work is not to place the correct ruler at the centre\.

The work is to make the centre temporary, inspectable, replaceable, and eventually unnecessary\.

**Survive → Stabilise → Repair → Renew → Handoff → Sunset\.**

Spiral kept, tide knows\.
