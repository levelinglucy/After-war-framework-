# Governance

## Status and purpose

The After-War Framework is an open institutional-design and testing project. This repository does not create a government, jurisdiction, political mandate, protection designation, or certification authority. Repository publication confers no assurance, recognition, or eligibility status.

AWF-Core is a release candidate under synthetic test freeze. Publication does not mean validation.

## Roles

### Founder-steward

The founder-steward may preserve provenance and version history, maintain the repository and evidence index, coordinate contributions and tests, assemble proposed releases, explain the framework, and record challenges.

The founder-steward may not score or validate release-gate evidence, assign final severity, accept their own mitigation, or decide whether AWF-Core freezes; suppress adverse results or dissent; or convert stewardship into political, custodial, or certification authority.

### Contributors

Contributors may propose corrections, tests, translations, accessibility improvements, and Reference material. Authorship does not confer validation authority.

### Test leads and evaluators

Test leads administer approved synthetic exercises. Evaluators score evidence against predeclared criteria. Neither may validate their own performance alone.

### Independent validators

Validators determine whether evidence supports release, revision, suspension, or freeze. A validator must not be an author, sponsor, facilitator, participant, records custodian, or materially interested beneficiary of the matter reviewed. Employment, funding, organisational control, custody, dependency, close collaboration, and a material reputational stake are disclosed and may require recusal.

Designation as a Frozen Test Draft requires at least two qualified independent validators. At least one should have rights, risk, governance, accessibility, or research-method expertise relevant to the evidence. Unresolved disagreement between validators leaves Core in release-candidate status.

## AWF-Core change rule

During test freeze, Core changes require recorded evidence of:

1. a test failure, repeated misunderstanding, safety defect, or accessibility defect causally connected to Core wording or omission;
2. the affected version and exact Core language;
3. observed facts separated from inference;
4. severity and credible consequences;
5. the shortest adequate correction;
6. possible adverse effects of that correction;
7. an independent review and retest plan.

Normative expansion, stylistic preference, founder preference, a protocol-only defect, or theoretical elegance alone is insufficient. A protocol defect authorises repair of the test instrument; Core changes still require causal evidence about Core. Reference material may remain open to development but must not silently alter the meaning of Core.

## Automatic release blockers

The authoritative definitions are in Section 1.1 of the Field Test Protocol. The following conditions cannot be averaged away:

- one activation receives automatic supremacy merely because it controls services, records, resources, communications, or AWF paperwork;
- essential aid, safety, records, movement, or basic participation is exchanged for political recognition, obedience, or acceptance of an actor’s mandate;
- A4 necessity renews itself, expands itself, or becomes a source of permanent office or political authority;
- “safe”, “protected”, “secured”, “neutralised”, “guaranteed”, or equivalent public wording is used without a verified and stated protection basis;
- the actor that incurred legitimacy debt, or the custodian controlling its record, separately or jointly discharges the debt without an independent, non-conflicted reviewer outside their control;
- an attempted witness or external copy is represented as received custody, independent review, or completed oversight.

A blocker prevents freezing until corrected and independently retested.

## Change classes

- **Editorial:** Typographical, formatting, link, and non-substantive accessibility repairs. May be merged by the steward with a recorded note.
- **Protocol defect:** A demonstrable flaw in test safety, comparability, scoring, burden, or evidence. Requires a defect record and review.
- **Core defect:** A release-gate, safety, rights, compression, or interpretation failure. Requires independent evidence, the shortest sufficient correction, and retest.
- **Reference development:** Explanatory or exploratory work that does not silently change Core. Remains open but versioned.
- **Release decision:** Requires independent validation, conflicts and recusals, dissent, findings, limitations, and an evidence index.

## Conflicts and recusal

All sponsors, authors, evaluators, and validators disclose relevant conflicts. Framework authors and test sponsors are fully recused from release-gate scoring, final severity, acceptance of their own mitigation, and release decisions; they may not serve as deciding votes.

Clarifications supplied during a test must be logged and made equally available to affected participants and evaluators.

## Repository and release control

The canonical branch should be protected from force-push and deletion. Material changes use pull requests. Release tags are historical records and are not moved or overwritten.

Until an independent reviewer is available, the steward may maintain and publish release candidates but may not represent a Core gate as independently passed.

## Document precedence

- **AWF-Core** governs the minimum conduct claims made by the portable kernel.
- **Field Test Protocol** governs synthetic exercises, evidence, scoring, and the release gate.
- **Governance** governs repository stewardship, change, recusal, and release decisions.
- **Reference** is interpretive and exploratory; it cannot silently amend Core or retroactively change a completed test.
- **README, Status, Quick Start, release notes, labels, and forms** are non-normative summaries and interfaces.

Apparent conflicts are recorded as defects. Core silence grants no additional authority. Every test pins the exact files, versions, sections, order, and integrity markers supplied to participants.

## Validator appointment, challenge, and appeal

Validators are nominated in the public test or release record with qualifications, conflicts, dependencies, and prior involvement. The founder-steward may invite candidates but cannot approve the release decision. Contributors may challenge a validator with stated evidence; a challenged validator responds on the record and recuses where independence is materially impaired.

A validator may be removed from a decision for an undisclosed conflict, retaliation, falsification, evidence suppression, or loss of independence. Removal and any replacement are recorded. If fewer than two independent validators remain, the freeze decision pauses.

An appeal is reviewed by at least one qualified person who did not make the original decision and has no material conflict. An appeal does not erase the original record or automatically change status. If independent review cannot be assembled, the candidate status and the unresolved appeal remain visible.

## Decisions, dissent, and failure records

Release decisions preserve the evidence reviewed, conflicts and recusals, majority and dissenting conclusions, unresolved findings, limitations and expiry, corrective actions, and retest dates.

Failed and ambiguous tests remain part of the public record. Personal, operational, or otherwise sensitive information must be removed before publication.

A canonical Frozen Test Draft bundle consists of Core, its completed release-specific limitations page, the static Known Limitations, the component integrity manifest, and the public evidence index. Missing companions invalidate a claim that a copy is the complete frozen bundle.

## Popularity is not mandate

Stars, forks, downloads, citations, comments, contributions, endorsements, or repository participation do not establish A2 community consent, jurisdiction, protection capability, or political legitimacy.

## Succession and forkability

Repository stewardship must be transferable. Records remain exportable in open formats. Forks retain provenance and may not imply endorsement by previous custodians.

The founder-steward may nominate a successor through a public handoff record identifying scope, repository access, evidence custody, unresolved conflicts, and effective date. A successor receives stewardship, not validation or political authority. If no accepted successor exists or maintainer capture is alleged, export and fork remain the available continuity and challenge paths; no silent succession is presumed.

No maintainer owns the framework’s participants, evidence, or future development.
