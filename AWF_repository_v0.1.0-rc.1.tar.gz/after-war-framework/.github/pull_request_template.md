<!--
PUBLIC SAFETY AND PRIVACY NOTICE

Do not include real vulnerable-person data, live credentials, medical or property records, operational locations, aid routes, shelters, security arrangements, armed-actor details, or active blind-test injects.

Use synthetic, anonymised, reversible examples. If review requires sensitive material, stop and use SECURITY.md.
-->

## Summary

<!-- What changes, and why? -->

## Linked record

<!-- Link the test result, finding, protocol defect, or governance record. Core changes require recorded evidence. -->

Closes #

## Change classification

- [ ] Core normative change
- [ ] Field or Reference change
- [ ] Test-protocol change
- [ ] Test result or evidence
- [ ] Governance or recusal control
- [ ] Accessibility improvement
- [ ] Safety or privacy correction
- [ ] Editorial, metadata, or repository maintenance

Affected files or controls:

## Evidence basis

**Observed:**

**Inferred:**

**Uncertainty or missing evidence:**

**Test run or finding ID:**

**Affected sentence, field, control, or failure hypothesis:**

**Alternatives considered:**

**Why this is the smallest sufficient change:**

## Test evidence

- Test: [ ] FT-01 [ ] FT-02 [ ] FT-03 [ ] FT-04 [ ] paired-document [ ] other [ ] not applicable
- Document pack: [ ] Core-only [ ] Core-plus [ ] other
- Scenario version and hash:
- Clock and care threshold:
- Participant roles:
- Independent evaluator:
- Result and severity:
- Deviations:
- Evidence artefacts:
- Retest requirement and date:

Where paired-document testing applies:

- [ ] Both teams received identical injects, clocks, roles, resources, and decision points.
- [ ] Red-line scoring was independent.
- [ ] Any difference was assessed as a possible document defect rather than presumed participant error.

Where FT-03 applies:

- [ ] The care deadline was declared before the run.
- [ ] Receipt completion did not delay care beyond the deadline, or the delay is recorded as a receipt-design finding.
- [ ] Attempted external transmission was not represented as received custody or oversight.

Where FT-04 applies:

- [ ] The timed public notice is included.
- [ ] Its actual wording was scored separately from the internal access-dependency record.

## Core test-freeze gate

- [ ] Not applicable; this does not alter AWF-Core.
- [ ] The change responds to a recorded test result.
- [ ] The change responds to a demonstrated protocol defect preventing valid testing.
- [ ] The failing Core sentence or omission is identified.
- [ ] The edit is no broader than the evidence supports.
- [ ] A retest is defined.
- [ ] Status, changelog, traceability, and limitations records are updated.

## Automatic release-blocker check

- [ ] Automatic supremacy merely from control of services, records, resources, communications, or AWF paperwork.
- [ ] Essential aid, safety, records, movement, or basic participation exchanged for recognition, obedience, or mandate acceptance.
- [ ] A4 renewed or expanded itself or became permanent office or political authority.
- [ ] Unsupported “safe,” “protected,” “secured,” “neutralised,” “guaranteed,” or equivalent public language.
- [ ] Legitimacy debt discharged by its debtor or controlling records custodian, separately or jointly, without an independent, non-conflicted reviewer outside their control.
- [ ] Attempted witnessing or external copying represented as received custody, independent review, or completed oversight.

**Blocker status:** none observed / one or more observed / unassessed

If any blocker is checked, explain containment and retest status:

## Rights, safety, and accessibility

- [ ] The change does not create coercive recruitment, loyalty screening, surveillance, retaliation, or discriminatory allocation.
- [ ] Assurance or repository status is not used as eligibility for aid, dignity, participation, or legal recognition.
- [ ] Attendance, silence, residence, aid receipt, or non-response is not treated as consent.
- [ ] Access is not represented as safety, protection, legitimacy, or endorsement.
- [ ] The change remains usable offline and under the stated burden ceiling where applicable.
- [ ] Accessibility and alternative communication needs were considered.
- [ ] No real vulnerable-person data, live credentials, operational locations, or active security details are included.
- [ ] Tests and examples are synthetic, closed, stoppable, and reversible.

## Roles, conflicts, and recusal

PR author:

Framework author or sponsor involved:

Test lead involved:

Function, custody, or record owner involved:

Proposed independent reviewer or validator:

Declared conflicts:

- [ ] All role overlaps and conflicts are disclosed.
- [ ] Test sponsors, framework authors, scenario authors, and materially interested beneficiaries are recused from release-gate scoring, final severity, acceptance of their own mitigation, and release decisions.
- [ ] No person is asked to approve their own S2-or-higher finding or validate their own result.
- [ ] Sponsor or author clarifications are logged and available to all evaluators.
- [ ] Required independent review has been requested.
- [ ] Any material generative-tool assistance is disclosed and its claims and citations were independently checked.

## Documentation and release integrity

- [ ] Relevant checks pass.
- [ ] Citations support the claims they accompany.
- [ ] `CHANGELOG.md` is updated where required.
- [ ] `STATUS.md` and the limitations page are updated where required.
- [ ] Version references and cross-layer links remain consistent.
- [ ] No unresolved Core defect is hidden solely in a limitations note.
- [ ] No unsupported claim of certification, jurisdiction, field validation, protection, or operational safety is made.
- [ ] Failures, dissent, and adverse results remain visible.

## Reviewer record

- Independent reviewer:
- Finding severity:
- Gate treatment:
- Conflict check:
- Evidence sufficient: [ ] yes [ ] no
- Retest required: [ ] yes [ ] no
- Decision record:
- Dissent or reservations:
